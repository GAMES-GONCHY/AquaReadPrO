<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-09 09:02:46 --> Config Class Initialized
INFO - 2024-08-09 09:02:46 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:02:46 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:02:46 --> Utf8 Class Initialized
INFO - 2024-08-09 09:02:46 --> URI Class Initialized
INFO - 2024-08-09 09:02:46 --> Router Class Initialized
INFO - 2024-08-09 09:02:46 --> Output Class Initialized
INFO - 2024-08-09 09:02:46 --> Security Class Initialized
DEBUG - 2024-08-09 09:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:02:46 --> Input Class Initialized
INFO - 2024-08-09 09:02:46 --> Language Class Initialized
INFO - 2024-08-09 09:02:46 --> Loader Class Initialized
INFO - 2024-08-09 09:02:46 --> Helper loaded: url_helper
INFO - 2024-08-09 09:02:46 --> Helper loaded: form_helper
INFO - 2024-08-09 09:02:46 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:02:46 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:02:46 --> Email Class Initialized
INFO - 2024-08-09 09:02:46 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:02:46 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:02:46 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:02:46 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:02:46 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:02:46 --> Controller Class Initialized
INFO - 2024-08-09 09:02:46 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:02:46 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:02:46 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 09:02:46 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:02:46 --> Final output sent to browser
DEBUG - 2024-08-09 09:02:46 --> Total execution time: 0.0975
INFO - 2024-08-09 09:02:48 --> Config Class Initialized
INFO - 2024-08-09 09:02:48 --> Hooks Class Initialized
INFO - 2024-08-09 09:02:48 --> Config Class Initialized
INFO - 2024-08-09 09:02:48 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:02:48 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:02:48 --> Utf8 Class Initialized
DEBUG - 2024-08-09 09:02:48 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:02:48 --> Utf8 Class Initialized
INFO - 2024-08-09 09:02:48 --> URI Class Initialized
INFO - 2024-08-09 09:02:48 --> Router Class Initialized
INFO - 2024-08-09 09:02:48 --> Output Class Initialized
INFO - 2024-08-09 09:02:48 --> Security Class Initialized
DEBUG - 2024-08-09 09:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:02:48 --> Input Class Initialized
INFO - 2024-08-09 09:02:48 --> Language Class Initialized
INFO - 2024-08-09 09:02:48 --> Loader Class Initialized
INFO - 2024-08-09 09:02:48 --> Helper loaded: url_helper
INFO - 2024-08-09 09:02:48 --> Helper loaded: form_helper
INFO - 2024-08-09 09:02:48 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:02:48 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:02:48 --> Email Class Initialized
INFO - 2024-08-09 09:02:48 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:02:48 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:02:48 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:02:48 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:02:48 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:02:48 --> Controller Class Initialized
INFO - 2024-08-09 09:02:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:02:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:02:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 09:02:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:02:48 --> Final output sent to browser
DEBUG - 2024-08-09 09:02:48 --> Total execution time: 0.1102
INFO - 2024-08-09 09:02:50 --> Config Class Initialized
INFO - 2024-08-09 09:02:50 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:02:50 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:02:50 --> Utf8 Class Initialized
INFO - 2024-08-09 09:02:50 --> URI Class Initialized
INFO - 2024-08-09 09:02:50 --> Router Class Initialized
INFO - 2024-08-09 09:02:50 --> Output Class Initialized
INFO - 2024-08-09 09:02:50 --> Security Class Initialized
DEBUG - 2024-08-09 09:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:02:50 --> Input Class Initialized
INFO - 2024-08-09 09:02:50 --> Language Class Initialized
INFO - 2024-08-09 09:02:50 --> Loader Class Initialized
INFO - 2024-08-09 09:02:50 --> Helper loaded: url_helper
INFO - 2024-08-09 09:02:50 --> Helper loaded: form_helper
INFO - 2024-08-09 09:02:50 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:02:50 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:02:50 --> Email Class Initialized
INFO - 2024-08-09 09:02:50 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:02:50 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:02:50 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:02:50 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:02:50 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:02:50 --> Controller Class Initialized
INFO - 2024-08-09 09:02:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:02:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:02:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:02:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:02:50 --> Final output sent to browser
DEBUG - 2024-08-09 09:02:50 --> Total execution time: 0.0935
INFO - 2024-08-09 09:02:51 --> Config Class Initialized
INFO - 2024-08-09 09:02:51 --> Hooks Class Initialized
INFO - 2024-08-09 09:02:51 --> Config Class Initialized
INFO - 2024-08-09 09:02:51 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:02:51 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:02:51 --> Utf8 Class Initialized
DEBUG - 2024-08-09 09:02:51 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:02:51 --> Utf8 Class Initialized
INFO - 2024-08-09 09:02:51 --> URI Class Initialized
INFO - 2024-08-09 09:02:51 --> Router Class Initialized
INFO - 2024-08-09 09:02:51 --> Output Class Initialized
INFO - 2024-08-09 09:02:51 --> Security Class Initialized
DEBUG - 2024-08-09 09:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:02:51 --> Input Class Initialized
INFO - 2024-08-09 09:02:51 --> Language Class Initialized
INFO - 2024-08-09 09:02:51 --> Loader Class Initialized
INFO - 2024-08-09 09:02:51 --> Helper loaded: url_helper
INFO - 2024-08-09 09:02:51 --> Helper loaded: form_helper
INFO - 2024-08-09 09:02:51 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:02:51 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:02:51 --> Email Class Initialized
INFO - 2024-08-09 09:02:51 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:02:51 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:02:51 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:02:51 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:02:51 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:02:51 --> Controller Class Initialized
ERROR - 2024-08-09 09:02:51 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 72
INFO - 2024-08-09 09:02:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:02:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:02:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:02:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:02:51 --> Final output sent to browser
DEBUG - 2024-08-09 09:02:51 --> Total execution time: 0.1439
INFO - 2024-08-09 09:02:57 --> Config Class Initialized
INFO - 2024-08-09 09:02:57 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:02:57 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:02:57 --> Utf8 Class Initialized
INFO - 2024-08-09 09:02:57 --> URI Class Initialized
INFO - 2024-08-09 09:02:57 --> Router Class Initialized
INFO - 2024-08-09 09:02:57 --> Output Class Initialized
INFO - 2024-08-09 09:02:57 --> Security Class Initialized
DEBUG - 2024-08-09 09:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:02:57 --> Input Class Initialized
INFO - 2024-08-09 09:02:57 --> Language Class Initialized
INFO - 2024-08-09 09:02:57 --> Loader Class Initialized
INFO - 2024-08-09 09:02:57 --> Helper loaded: url_helper
INFO - 2024-08-09 09:02:57 --> Helper loaded: form_helper
INFO - 2024-08-09 09:02:57 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:02:57 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:02:57 --> Email Class Initialized
INFO - 2024-08-09 09:02:57 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:02:57 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:02:57 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:02:57 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:02:57 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:02:57 --> Controller Class Initialized
INFO - 2024-08-09 09:02:57 --> Config Class Initialized
INFO - 2024-08-09 09:02:57 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:02:57 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:02:57 --> Utf8 Class Initialized
INFO - 2024-08-09 09:02:57 --> URI Class Initialized
INFO - 2024-08-09 09:02:57 --> Router Class Initialized
INFO - 2024-08-09 09:02:57 --> Output Class Initialized
INFO - 2024-08-09 09:02:57 --> Security Class Initialized
DEBUG - 2024-08-09 09:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:02:57 --> Input Class Initialized
INFO - 2024-08-09 09:02:57 --> Language Class Initialized
INFO - 2024-08-09 09:02:57 --> Loader Class Initialized
INFO - 2024-08-09 09:02:57 --> Helper loaded: url_helper
INFO - 2024-08-09 09:02:57 --> Helper loaded: form_helper
INFO - 2024-08-09 09:02:57 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:02:57 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:02:57 --> Email Class Initialized
INFO - 2024-08-09 09:02:57 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:02:57 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:02:57 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:02:57 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:02:57 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:02:57 --> Controller Class Initialized
ERROR - 2024-08-09 09:02:57 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 72
INFO - 2024-08-09 09:02:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:02:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:02:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:02:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:02:57 --> Final output sent to browser
DEBUG - 2024-08-09 09:02:57 --> Total execution time: 0.0964
INFO - 2024-08-09 09:02:57 --> Config Class Initialized
INFO - 2024-08-09 09:02:57 --> Config Class Initialized
INFO - 2024-08-09 09:02:57 --> Hooks Class Initialized
INFO - 2024-08-09 09:02:57 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:02:57 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 09:02:57 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:02:57 --> Utf8 Class Initialized
INFO - 2024-08-09 09:02:57 --> Utf8 Class Initialized
INFO - 2024-08-09 09:02:57 --> URI Class Initialized
INFO - 2024-08-09 09:02:57 --> Router Class Initialized
INFO - 2024-08-09 09:02:57 --> Output Class Initialized
INFO - 2024-08-09 09:02:57 --> Security Class Initialized
DEBUG - 2024-08-09 09:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:02:57 --> Input Class Initialized
INFO - 2024-08-09 09:02:57 --> Language Class Initialized
INFO - 2024-08-09 09:02:57 --> Loader Class Initialized
INFO - 2024-08-09 09:02:57 --> Helper loaded: url_helper
INFO - 2024-08-09 09:02:57 --> Helper loaded: form_helper
INFO - 2024-08-09 09:02:57 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:02:57 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:02:57 --> Email Class Initialized
INFO - 2024-08-09 09:02:57 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:02:57 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:02:57 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:02:57 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:02:57 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:02:57 --> Controller Class Initialized
ERROR - 2024-08-09 09:02:57 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 72
INFO - 2024-08-09 09:02:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:02:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:02:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:02:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:02:57 --> Final output sent to browser
DEBUG - 2024-08-09 09:02:57 --> Total execution time: 0.1448
INFO - 2024-08-09 09:51:00 --> Config Class Initialized
INFO - 2024-08-09 09:51:00 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:51:00 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:51:00 --> Utf8 Class Initialized
INFO - 2024-08-09 09:51:00 --> URI Class Initialized
INFO - 2024-08-09 09:51:00 --> Router Class Initialized
INFO - 2024-08-09 09:51:00 --> Output Class Initialized
INFO - 2024-08-09 09:51:00 --> Security Class Initialized
DEBUG - 2024-08-09 09:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:51:00 --> Input Class Initialized
INFO - 2024-08-09 09:51:00 --> Language Class Initialized
INFO - 2024-08-09 09:51:00 --> Loader Class Initialized
INFO - 2024-08-09 09:51:00 --> Helper loaded: url_helper
INFO - 2024-08-09 09:51:00 --> Helper loaded: form_helper
INFO - 2024-08-09 09:51:00 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:51:00 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:51:00 --> Email Class Initialized
INFO - 2024-08-09 09:51:00 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:51:00 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:51:00 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:51:01 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:51:01 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:51:01 --> Controller Class Initialized
INFO - 2024-08-09 09:51:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:51:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:51:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:51:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:51:01 --> Final output sent to browser
DEBUG - 2024-08-09 09:51:01 --> Total execution time: 0.1680
INFO - 2024-08-09 09:51:01 --> Config Class Initialized
INFO - 2024-08-09 09:51:01 --> Config Class Initialized
INFO - 2024-08-09 09:51:01 --> Hooks Class Initialized
INFO - 2024-08-09 09:51:01 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:51:01 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 09:51:01 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:51:01 --> Utf8 Class Initialized
INFO - 2024-08-09 09:51:01 --> Utf8 Class Initialized
INFO - 2024-08-09 09:51:01 --> URI Class Initialized
INFO - 2024-08-09 09:51:01 --> Router Class Initialized
INFO - 2024-08-09 09:51:01 --> Output Class Initialized
INFO - 2024-08-09 09:51:01 --> Security Class Initialized
DEBUG - 2024-08-09 09:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:51:01 --> Input Class Initialized
INFO - 2024-08-09 09:51:01 --> Language Class Initialized
INFO - 2024-08-09 09:51:01 --> Loader Class Initialized
INFO - 2024-08-09 09:51:01 --> Helper loaded: url_helper
INFO - 2024-08-09 09:51:01 --> Helper loaded: form_helper
INFO - 2024-08-09 09:51:01 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:51:01 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:51:01 --> Email Class Initialized
INFO - 2024-08-09 09:51:01 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:51:01 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:51:01 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:51:01 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:51:01 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:51:01 --> Controller Class Initialized
INFO - 2024-08-09 09:51:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:51:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:51:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:51:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:51:01 --> Final output sent to browser
DEBUG - 2024-08-09 09:51:01 --> Total execution time: 0.1108
INFO - 2024-08-09 09:51:03 --> Config Class Initialized
INFO - 2024-08-09 09:51:03 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:51:03 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:51:03 --> Utf8 Class Initialized
INFO - 2024-08-09 09:51:03 --> URI Class Initialized
INFO - 2024-08-09 09:51:03 --> Router Class Initialized
INFO - 2024-08-09 09:51:03 --> Output Class Initialized
INFO - 2024-08-09 09:51:03 --> Security Class Initialized
DEBUG - 2024-08-09 09:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:51:03 --> Input Class Initialized
INFO - 2024-08-09 09:51:03 --> Language Class Initialized
INFO - 2024-08-09 09:51:03 --> Loader Class Initialized
INFO - 2024-08-09 09:51:03 --> Helper loaded: url_helper
INFO - 2024-08-09 09:51:03 --> Helper loaded: form_helper
INFO - 2024-08-09 09:51:03 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:51:03 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:51:03 --> Email Class Initialized
INFO - 2024-08-09 09:51:03 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:51:03 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:51:03 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:51:03 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:51:03 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:51:03 --> Controller Class Initialized
INFO - 2024-08-09 09:51:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:51:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:51:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:51:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:51:03 --> Final output sent to browser
DEBUG - 2024-08-09 09:51:03 --> Total execution time: 0.0872
INFO - 2024-08-09 09:51:03 --> Config Class Initialized
INFO - 2024-08-09 09:51:03 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:51:03 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:51:03 --> Config Class Initialized
INFO - 2024-08-09 09:51:03 --> Utf8 Class Initialized
INFO - 2024-08-09 09:51:03 --> Hooks Class Initialized
INFO - 2024-08-09 09:51:03 --> URI Class Initialized
DEBUG - 2024-08-09 09:51:03 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:51:03 --> Utf8 Class Initialized
INFO - 2024-08-09 09:51:03 --> Router Class Initialized
INFO - 2024-08-09 09:51:03 --> Output Class Initialized
INFO - 2024-08-09 09:51:03 --> Security Class Initialized
DEBUG - 2024-08-09 09:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:51:03 --> Input Class Initialized
INFO - 2024-08-09 09:51:03 --> Language Class Initialized
INFO - 2024-08-09 09:51:03 --> Loader Class Initialized
INFO - 2024-08-09 09:51:03 --> Helper loaded: url_helper
INFO - 2024-08-09 09:51:03 --> Helper loaded: form_helper
INFO - 2024-08-09 09:51:03 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:51:03 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:51:03 --> Email Class Initialized
INFO - 2024-08-09 09:51:03 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:51:03 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:51:03 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:51:03 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:51:03 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:51:03 --> Controller Class Initialized
INFO - 2024-08-09 09:51:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:51:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:51:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:51:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:51:03 --> Final output sent to browser
DEBUG - 2024-08-09 09:51:03 --> Total execution time: 0.1137
INFO - 2024-08-09 09:51:07 --> Config Class Initialized
INFO - 2024-08-09 09:51:07 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:51:07 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:51:07 --> Utf8 Class Initialized
INFO - 2024-08-09 09:51:07 --> URI Class Initialized
INFO - 2024-08-09 09:51:07 --> Router Class Initialized
INFO - 2024-08-09 09:51:07 --> Output Class Initialized
INFO - 2024-08-09 09:51:07 --> Security Class Initialized
DEBUG - 2024-08-09 09:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:51:07 --> Input Class Initialized
INFO - 2024-08-09 09:51:07 --> Language Class Initialized
INFO - 2024-08-09 09:51:07 --> Loader Class Initialized
INFO - 2024-08-09 09:51:07 --> Helper loaded: url_helper
INFO - 2024-08-09 09:51:07 --> Helper loaded: form_helper
INFO - 2024-08-09 09:51:07 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:51:07 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:51:07 --> Email Class Initialized
INFO - 2024-08-09 09:51:07 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:51:07 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:51:07 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:51:07 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:51:07 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:51:07 --> Controller Class Initialized
INFO - 2024-08-09 09:51:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:51:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:51:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 09:51:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:51:07 --> Final output sent to browser
DEBUG - 2024-08-09 09:51:07 --> Total execution time: 0.1171
INFO - 2024-08-09 09:51:07 --> Config Class Initialized
INFO - 2024-08-09 09:51:07 --> Hooks Class Initialized
INFO - 2024-08-09 09:51:07 --> Config Class Initialized
INFO - 2024-08-09 09:51:07 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:51:07 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:51:07 --> Utf8 Class Initialized
DEBUG - 2024-08-09 09:51:07 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:51:07 --> Utf8 Class Initialized
INFO - 2024-08-09 09:51:07 --> URI Class Initialized
INFO - 2024-08-09 09:51:07 --> Router Class Initialized
INFO - 2024-08-09 09:51:07 --> Output Class Initialized
INFO - 2024-08-09 09:51:07 --> Security Class Initialized
DEBUG - 2024-08-09 09:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:51:07 --> Input Class Initialized
INFO - 2024-08-09 09:51:07 --> Language Class Initialized
INFO - 2024-08-09 09:51:07 --> Loader Class Initialized
INFO - 2024-08-09 09:51:07 --> Helper loaded: url_helper
INFO - 2024-08-09 09:51:07 --> Helper loaded: form_helper
INFO - 2024-08-09 09:51:07 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:51:07 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:51:07 --> Email Class Initialized
INFO - 2024-08-09 09:51:07 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:51:07 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:51:07 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:51:07 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:51:07 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:51:07 --> Controller Class Initialized
INFO - 2024-08-09 09:51:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:51:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:51:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 09:51:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:51:07 --> Final output sent to browser
DEBUG - 2024-08-09 09:51:07 --> Total execution time: 0.1304
INFO - 2024-08-09 09:51:10 --> Config Class Initialized
INFO - 2024-08-09 09:51:10 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:51:10 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:51:10 --> Utf8 Class Initialized
INFO - 2024-08-09 09:51:10 --> URI Class Initialized
INFO - 2024-08-09 09:51:10 --> Router Class Initialized
INFO - 2024-08-09 09:51:10 --> Output Class Initialized
INFO - 2024-08-09 09:51:10 --> Security Class Initialized
DEBUG - 2024-08-09 09:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:51:10 --> Input Class Initialized
INFO - 2024-08-09 09:51:10 --> Language Class Initialized
INFO - 2024-08-09 09:51:10 --> Loader Class Initialized
INFO - 2024-08-09 09:51:10 --> Helper loaded: url_helper
INFO - 2024-08-09 09:51:10 --> Helper loaded: form_helper
INFO - 2024-08-09 09:51:10 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:51:10 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:51:10 --> Email Class Initialized
INFO - 2024-08-09 09:51:10 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:51:10 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:51:10 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:51:10 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:51:10 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:51:10 --> Controller Class Initialized
INFO - 2024-08-09 09:51:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:51:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:51:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:51:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:51:10 --> Final output sent to browser
DEBUG - 2024-08-09 09:51:10 --> Total execution time: 0.1116
INFO - 2024-08-09 09:51:10 --> Config Class Initialized
INFO - 2024-08-09 09:51:10 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:51:10 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:51:10 --> Utf8 Class Initialized
INFO - 2024-08-09 09:51:10 --> Config Class Initialized
INFO - 2024-08-09 09:51:10 --> Hooks Class Initialized
INFO - 2024-08-09 09:51:10 --> URI Class Initialized
INFO - 2024-08-09 09:51:10 --> Router Class Initialized
INFO - 2024-08-09 09:51:10 --> Output Class Initialized
DEBUG - 2024-08-09 09:51:10 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:51:10 --> Utf8 Class Initialized
INFO - 2024-08-09 09:51:10 --> Security Class Initialized
DEBUG - 2024-08-09 09:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:51:10 --> Input Class Initialized
INFO - 2024-08-09 09:51:10 --> Language Class Initialized
INFO - 2024-08-09 09:51:10 --> Loader Class Initialized
INFO - 2024-08-09 09:51:10 --> Helper loaded: url_helper
INFO - 2024-08-09 09:51:10 --> Helper loaded: form_helper
INFO - 2024-08-09 09:51:10 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:51:10 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:51:10 --> Email Class Initialized
INFO - 2024-08-09 09:51:10 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:51:10 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:51:10 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:51:10 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:51:10 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:51:10 --> Controller Class Initialized
INFO - 2024-08-09 09:51:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:51:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:51:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:51:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:51:10 --> Final output sent to browser
DEBUG - 2024-08-09 09:51:10 --> Total execution time: 0.1168
INFO - 2024-08-09 09:51:14 --> Config Class Initialized
INFO - 2024-08-09 09:51:14 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:51:14 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:51:14 --> Utf8 Class Initialized
INFO - 2024-08-09 09:51:14 --> URI Class Initialized
INFO - 2024-08-09 09:51:14 --> Router Class Initialized
INFO - 2024-08-09 09:51:14 --> Output Class Initialized
INFO - 2024-08-09 09:51:14 --> Security Class Initialized
DEBUG - 2024-08-09 09:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:51:14 --> Input Class Initialized
INFO - 2024-08-09 09:51:14 --> Language Class Initialized
INFO - 2024-08-09 09:51:14 --> Loader Class Initialized
INFO - 2024-08-09 09:51:14 --> Helper loaded: url_helper
INFO - 2024-08-09 09:51:14 --> Helper loaded: form_helper
INFO - 2024-08-09 09:51:14 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:51:14 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:51:14 --> Email Class Initialized
INFO - 2024-08-09 09:51:14 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:51:14 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:51:14 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:51:14 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:51:14 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:51:14 --> Controller Class Initialized
INFO - 2024-08-09 09:51:14 --> Config Class Initialized
INFO - 2024-08-09 09:51:14 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:51:14 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:51:14 --> Utf8 Class Initialized
INFO - 2024-08-09 09:51:14 --> URI Class Initialized
INFO - 2024-08-09 09:51:14 --> Router Class Initialized
INFO - 2024-08-09 09:51:14 --> Output Class Initialized
INFO - 2024-08-09 09:51:14 --> Security Class Initialized
DEBUG - 2024-08-09 09:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:51:14 --> Input Class Initialized
INFO - 2024-08-09 09:51:14 --> Language Class Initialized
INFO - 2024-08-09 09:51:14 --> Loader Class Initialized
INFO - 2024-08-09 09:51:14 --> Helper loaded: url_helper
INFO - 2024-08-09 09:51:14 --> Helper loaded: form_helper
INFO - 2024-08-09 09:51:14 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:51:14 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:51:14 --> Email Class Initialized
INFO - 2024-08-09 09:51:14 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:51:14 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:51:14 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:51:14 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:51:14 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:51:14 --> Controller Class Initialized
INFO - 2024-08-09 09:51:14 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:51:14 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:51:14 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:51:14 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:51:14 --> Final output sent to browser
DEBUG - 2024-08-09 09:51:14 --> Total execution time: 0.0817
INFO - 2024-08-09 09:51:15 --> Config Class Initialized
INFO - 2024-08-09 09:51:15 --> Config Class Initialized
INFO - 2024-08-09 09:51:15 --> Hooks Class Initialized
INFO - 2024-08-09 09:51:15 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:51:15 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:51:15 --> Utf8 Class Initialized
DEBUG - 2024-08-09 09:51:15 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:51:15 --> Utf8 Class Initialized
INFO - 2024-08-09 09:51:15 --> URI Class Initialized
INFO - 2024-08-09 09:51:15 --> Router Class Initialized
INFO - 2024-08-09 09:51:15 --> Output Class Initialized
INFO - 2024-08-09 09:51:15 --> Security Class Initialized
DEBUG - 2024-08-09 09:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:51:15 --> Input Class Initialized
INFO - 2024-08-09 09:51:15 --> Language Class Initialized
INFO - 2024-08-09 09:51:15 --> Loader Class Initialized
INFO - 2024-08-09 09:51:15 --> Helper loaded: url_helper
INFO - 2024-08-09 09:51:15 --> Helper loaded: form_helper
INFO - 2024-08-09 09:51:15 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:51:15 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:51:15 --> Email Class Initialized
INFO - 2024-08-09 09:51:15 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:51:15 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:51:15 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:51:15 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:51:15 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:51:15 --> Controller Class Initialized
INFO - 2024-08-09 09:51:15 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:51:15 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:51:15 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:51:15 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:51:15 --> Final output sent to browser
DEBUG - 2024-08-09 09:51:15 --> Total execution time: 0.1314
INFO - 2024-08-09 09:52:58 --> Config Class Initialized
INFO - 2024-08-09 09:52:58 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:52:58 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:52:58 --> Utf8 Class Initialized
INFO - 2024-08-09 09:52:58 --> URI Class Initialized
INFO - 2024-08-09 09:52:58 --> Router Class Initialized
INFO - 2024-08-09 09:52:58 --> Output Class Initialized
INFO - 2024-08-09 09:52:58 --> Security Class Initialized
DEBUG - 2024-08-09 09:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:52:58 --> Input Class Initialized
INFO - 2024-08-09 09:52:58 --> Language Class Initialized
INFO - 2024-08-09 09:52:58 --> Loader Class Initialized
INFO - 2024-08-09 09:52:58 --> Helper loaded: url_helper
INFO - 2024-08-09 09:52:58 --> Helper loaded: form_helper
INFO - 2024-08-09 09:52:58 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:52:58 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:52:58 --> Email Class Initialized
INFO - 2024-08-09 09:52:58 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:52:58 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:52:58 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:52:58 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:52:58 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:52:58 --> Controller Class Initialized
INFO - 2024-08-09 09:52:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:52:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:52:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:52:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:52:58 --> Final output sent to browser
DEBUG - 2024-08-09 09:52:58 --> Total execution time: 0.1537
INFO - 2024-08-09 09:52:59 --> Config Class Initialized
INFO - 2024-08-09 09:52:59 --> Hooks Class Initialized
INFO - 2024-08-09 09:52:59 --> Config Class Initialized
INFO - 2024-08-09 09:52:59 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:52:59 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:52:59 --> Utf8 Class Initialized
DEBUG - 2024-08-09 09:52:59 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:52:59 --> Utf8 Class Initialized
INFO - 2024-08-09 09:52:59 --> URI Class Initialized
INFO - 2024-08-09 09:52:59 --> Router Class Initialized
INFO - 2024-08-09 09:52:59 --> Output Class Initialized
INFO - 2024-08-09 09:52:59 --> Security Class Initialized
DEBUG - 2024-08-09 09:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:52:59 --> Input Class Initialized
INFO - 2024-08-09 09:52:59 --> Language Class Initialized
INFO - 2024-08-09 09:52:59 --> Loader Class Initialized
INFO - 2024-08-09 09:52:59 --> Helper loaded: url_helper
INFO - 2024-08-09 09:52:59 --> Helper loaded: form_helper
INFO - 2024-08-09 09:52:59 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:52:59 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:52:59 --> Email Class Initialized
INFO - 2024-08-09 09:52:59 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:52:59 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:52:59 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:52:59 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:52:59 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:52:59 --> Controller Class Initialized
INFO - 2024-08-09 09:52:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:52:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:52:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:52:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:52:59 --> Final output sent to browser
DEBUG - 2024-08-09 09:52:59 --> Total execution time: 0.1261
INFO - 2024-08-09 09:53:01 --> Config Class Initialized
INFO - 2024-08-09 09:53:01 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:53:01 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:53:01 --> Utf8 Class Initialized
INFO - 2024-08-09 09:53:01 --> URI Class Initialized
INFO - 2024-08-09 09:53:01 --> Router Class Initialized
INFO - 2024-08-09 09:53:01 --> Output Class Initialized
INFO - 2024-08-09 09:53:01 --> Security Class Initialized
DEBUG - 2024-08-09 09:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:53:01 --> Input Class Initialized
INFO - 2024-08-09 09:53:01 --> Language Class Initialized
INFO - 2024-08-09 09:53:01 --> Loader Class Initialized
INFO - 2024-08-09 09:53:01 --> Helper loaded: url_helper
INFO - 2024-08-09 09:53:01 --> Helper loaded: form_helper
INFO - 2024-08-09 09:53:01 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:53:01 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:53:01 --> Email Class Initialized
INFO - 2024-08-09 09:53:01 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:53:01 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:53:01 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:53:01 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:53:01 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:53:01 --> Controller Class Initialized
INFO - 2024-08-09 09:53:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:53:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:53:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 09:53:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:53:02 --> Final output sent to browser
DEBUG - 2024-08-09 09:53:02 --> Total execution time: 0.0983
INFO - 2024-08-09 09:53:02 --> Config Class Initialized
INFO - 2024-08-09 09:53:02 --> Hooks Class Initialized
INFO - 2024-08-09 09:53:02 --> Config Class Initialized
INFO - 2024-08-09 09:53:02 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:53:02 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:53:02 --> Utf8 Class Initialized
DEBUG - 2024-08-09 09:53:02 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:53:02 --> Utf8 Class Initialized
INFO - 2024-08-09 09:53:02 --> URI Class Initialized
INFO - 2024-08-09 09:53:02 --> Router Class Initialized
INFO - 2024-08-09 09:53:02 --> Output Class Initialized
INFO - 2024-08-09 09:53:02 --> Security Class Initialized
DEBUG - 2024-08-09 09:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:53:02 --> Input Class Initialized
INFO - 2024-08-09 09:53:02 --> Language Class Initialized
INFO - 2024-08-09 09:53:02 --> Loader Class Initialized
INFO - 2024-08-09 09:53:02 --> Helper loaded: url_helper
INFO - 2024-08-09 09:53:02 --> Helper loaded: form_helper
INFO - 2024-08-09 09:53:02 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:53:02 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:53:02 --> Email Class Initialized
INFO - 2024-08-09 09:53:02 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:53:02 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:53:02 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:53:02 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:53:02 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:53:02 --> Controller Class Initialized
INFO - 2024-08-09 09:53:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:53:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:53:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 09:53:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:53:02 --> Final output sent to browser
DEBUG - 2024-08-09 09:53:02 --> Total execution time: 0.1361
INFO - 2024-08-09 09:53:03 --> Config Class Initialized
INFO - 2024-08-09 09:53:03 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:53:03 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:53:03 --> Utf8 Class Initialized
INFO - 2024-08-09 09:53:03 --> URI Class Initialized
INFO - 2024-08-09 09:53:03 --> Router Class Initialized
INFO - 2024-08-09 09:53:03 --> Output Class Initialized
INFO - 2024-08-09 09:53:03 --> Security Class Initialized
DEBUG - 2024-08-09 09:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:53:03 --> Input Class Initialized
INFO - 2024-08-09 09:53:03 --> Language Class Initialized
INFO - 2024-08-09 09:53:03 --> Loader Class Initialized
INFO - 2024-08-09 09:53:03 --> Helper loaded: url_helper
INFO - 2024-08-09 09:53:03 --> Helper loaded: form_helper
INFO - 2024-08-09 09:53:03 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:53:03 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:53:03 --> Email Class Initialized
INFO - 2024-08-09 09:53:03 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:53:03 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:53:03 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:53:03 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:53:03 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:53:03 --> Controller Class Initialized
INFO - 2024-08-09 09:53:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:53:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:53:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 09:53:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:53:03 --> Final output sent to browser
DEBUG - 2024-08-09 09:53:03 --> Total execution time: 0.1006
INFO - 2024-08-09 09:53:04 --> Config Class Initialized
INFO - 2024-08-09 09:53:04 --> Hooks Class Initialized
INFO - 2024-08-09 09:53:04 --> Config Class Initialized
INFO - 2024-08-09 09:53:04 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:53:04 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:53:04 --> Utf8 Class Initialized
DEBUG - 2024-08-09 09:53:04 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:53:04 --> Utf8 Class Initialized
INFO - 2024-08-09 09:53:04 --> URI Class Initialized
INFO - 2024-08-09 09:53:04 --> Router Class Initialized
INFO - 2024-08-09 09:53:04 --> Output Class Initialized
INFO - 2024-08-09 09:53:04 --> Security Class Initialized
DEBUG - 2024-08-09 09:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:53:04 --> Input Class Initialized
INFO - 2024-08-09 09:53:04 --> Language Class Initialized
INFO - 2024-08-09 09:53:04 --> Loader Class Initialized
INFO - 2024-08-09 09:53:04 --> Helper loaded: url_helper
INFO - 2024-08-09 09:53:04 --> Helper loaded: form_helper
INFO - 2024-08-09 09:53:04 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:53:04 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:53:04 --> Email Class Initialized
INFO - 2024-08-09 09:53:04 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:53:04 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:53:04 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:53:04 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:53:04 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:53:04 --> Controller Class Initialized
INFO - 2024-08-09 09:53:04 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:53:04 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:53:04 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 09:53:04 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:53:04 --> Final output sent to browser
DEBUG - 2024-08-09 09:53:04 --> Total execution time: 0.1791
INFO - 2024-08-09 09:53:06 --> Config Class Initialized
INFO - 2024-08-09 09:53:06 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:53:06 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:53:06 --> Utf8 Class Initialized
INFO - 2024-08-09 09:53:06 --> URI Class Initialized
INFO - 2024-08-09 09:53:06 --> Router Class Initialized
INFO - 2024-08-09 09:53:06 --> Output Class Initialized
INFO - 2024-08-09 09:53:06 --> Security Class Initialized
DEBUG - 2024-08-09 09:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:53:06 --> Input Class Initialized
INFO - 2024-08-09 09:53:06 --> Language Class Initialized
INFO - 2024-08-09 09:53:06 --> Loader Class Initialized
INFO - 2024-08-09 09:53:06 --> Helper loaded: url_helper
INFO - 2024-08-09 09:53:06 --> Helper loaded: form_helper
INFO - 2024-08-09 09:53:06 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:53:06 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:53:06 --> Email Class Initialized
INFO - 2024-08-09 09:53:06 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:53:06 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:53:06 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:53:06 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:53:06 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:53:06 --> Controller Class Initialized
INFO - 2024-08-09 09:53:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:53:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:53:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:53:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:53:06 --> Final output sent to browser
DEBUG - 2024-08-09 09:53:06 --> Total execution time: 0.1172
INFO - 2024-08-09 09:53:07 --> Config Class Initialized
INFO - 2024-08-09 09:53:07 --> Hooks Class Initialized
INFO - 2024-08-09 09:53:07 --> Config Class Initialized
INFO - 2024-08-09 09:53:07 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:53:07 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:53:07 --> Utf8 Class Initialized
INFO - 2024-08-09 09:53:07 --> URI Class Initialized
DEBUG - 2024-08-09 09:53:07 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:53:07 --> Router Class Initialized
INFO - 2024-08-09 09:53:07 --> Utf8 Class Initialized
INFO - 2024-08-09 09:53:07 --> Output Class Initialized
INFO - 2024-08-09 09:53:07 --> Security Class Initialized
DEBUG - 2024-08-09 09:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:53:07 --> Input Class Initialized
INFO - 2024-08-09 09:53:07 --> Language Class Initialized
INFO - 2024-08-09 09:53:07 --> Loader Class Initialized
INFO - 2024-08-09 09:53:07 --> Helper loaded: url_helper
INFO - 2024-08-09 09:53:07 --> Helper loaded: form_helper
INFO - 2024-08-09 09:53:07 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:53:07 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:53:07 --> Email Class Initialized
INFO - 2024-08-09 09:53:07 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:53:07 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:53:07 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:53:07 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:53:07 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:53:07 --> Controller Class Initialized
INFO - 2024-08-09 09:53:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:53:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:53:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:53:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:53:07 --> Final output sent to browser
DEBUG - 2024-08-09 09:53:07 --> Total execution time: 0.1197
INFO - 2024-08-09 09:53:11 --> Config Class Initialized
INFO - 2024-08-09 09:53:11 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:53:11 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:53:11 --> Utf8 Class Initialized
INFO - 2024-08-09 09:53:11 --> URI Class Initialized
INFO - 2024-08-09 09:53:11 --> Router Class Initialized
INFO - 2024-08-09 09:53:11 --> Output Class Initialized
INFO - 2024-08-09 09:53:11 --> Security Class Initialized
DEBUG - 2024-08-09 09:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:53:11 --> Input Class Initialized
INFO - 2024-08-09 09:53:11 --> Language Class Initialized
INFO - 2024-08-09 09:53:11 --> Loader Class Initialized
INFO - 2024-08-09 09:53:11 --> Helper loaded: url_helper
INFO - 2024-08-09 09:53:11 --> Helper loaded: form_helper
INFO - 2024-08-09 09:53:11 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:53:11 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:53:11 --> Email Class Initialized
INFO - 2024-08-09 09:53:11 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:53:11 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:53:11 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:53:11 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:53:11 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:53:11 --> Controller Class Initialized
INFO - 2024-08-09 09:53:11 --> Config Class Initialized
INFO - 2024-08-09 09:53:11 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:53:11 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:53:11 --> Utf8 Class Initialized
INFO - 2024-08-09 09:53:11 --> URI Class Initialized
INFO - 2024-08-09 09:53:11 --> Router Class Initialized
INFO - 2024-08-09 09:53:11 --> Output Class Initialized
INFO - 2024-08-09 09:53:11 --> Security Class Initialized
DEBUG - 2024-08-09 09:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:53:11 --> Input Class Initialized
INFO - 2024-08-09 09:53:11 --> Language Class Initialized
INFO - 2024-08-09 09:53:11 --> Loader Class Initialized
INFO - 2024-08-09 09:53:11 --> Helper loaded: url_helper
INFO - 2024-08-09 09:53:11 --> Helper loaded: form_helper
INFO - 2024-08-09 09:53:11 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:53:11 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:53:11 --> Email Class Initialized
INFO - 2024-08-09 09:53:11 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:53:11 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:53:11 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:53:11 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:53:11 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:53:11 --> Controller Class Initialized
INFO - 2024-08-09 09:53:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:53:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:53:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:53:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:53:11 --> Final output sent to browser
DEBUG - 2024-08-09 09:53:11 --> Total execution time: 0.0808
INFO - 2024-08-09 09:53:11 --> Config Class Initialized
INFO - 2024-08-09 09:53:11 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:53:11 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:53:11 --> Utf8 Class Initialized
INFO - 2024-08-09 09:53:11 --> URI Class Initialized
INFO - 2024-08-09 09:53:11 --> Config Class Initialized
INFO - 2024-08-09 09:53:11 --> Router Class Initialized
INFO - 2024-08-09 09:53:11 --> Hooks Class Initialized
INFO - 2024-08-09 09:53:11 --> Output Class Initialized
DEBUG - 2024-08-09 09:53:11 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:53:11 --> Utf8 Class Initialized
INFO - 2024-08-09 09:53:11 --> Security Class Initialized
DEBUG - 2024-08-09 09:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:53:11 --> Input Class Initialized
INFO - 2024-08-09 09:53:11 --> Language Class Initialized
INFO - 2024-08-09 09:53:11 --> Loader Class Initialized
INFO - 2024-08-09 09:53:11 --> Helper loaded: url_helper
INFO - 2024-08-09 09:53:11 --> Helper loaded: form_helper
INFO - 2024-08-09 09:53:11 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:53:12 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:53:12 --> Email Class Initialized
INFO - 2024-08-09 09:53:12 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:53:12 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:53:12 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:53:12 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:53:12 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:53:12 --> Controller Class Initialized
INFO - 2024-08-09 09:53:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:53:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:53:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:53:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:53:12 --> Final output sent to browser
DEBUG - 2024-08-09 09:53:12 --> Total execution time: 0.1255
INFO - 2024-08-09 09:55:09 --> Config Class Initialized
INFO - 2024-08-09 09:55:09 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:55:09 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:09 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:09 --> URI Class Initialized
INFO - 2024-08-09 09:55:09 --> Router Class Initialized
INFO - 2024-08-09 09:55:09 --> Output Class Initialized
INFO - 2024-08-09 09:55:09 --> Security Class Initialized
DEBUG - 2024-08-09 09:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:55:09 --> Input Class Initialized
INFO - 2024-08-09 09:55:09 --> Language Class Initialized
INFO - 2024-08-09 09:55:09 --> Loader Class Initialized
INFO - 2024-08-09 09:55:09 --> Helper loaded: url_helper
INFO - 2024-08-09 09:55:09 --> Helper loaded: form_helper
INFO - 2024-08-09 09:55:09 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:55:09 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:55:09 --> Email Class Initialized
INFO - 2024-08-09 09:55:09 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:55:09 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:55:09 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:55:09 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:55:09 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:55:09 --> Controller Class Initialized
INFO - 2024-08-09 09:55:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:55:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:55:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 09:55:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:55:09 --> Final output sent to browser
DEBUG - 2024-08-09 09:55:09 --> Total execution time: 0.1530
INFO - 2024-08-09 09:55:10 --> Config Class Initialized
INFO - 2024-08-09 09:55:10 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:55:10 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:10 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:10 --> URI Class Initialized
INFO - 2024-08-09 09:55:10 --> Router Class Initialized
INFO - 2024-08-09 09:55:10 --> Config Class Initialized
INFO - 2024-08-09 09:55:10 --> Hooks Class Initialized
INFO - 2024-08-09 09:55:10 --> Output Class Initialized
INFO - 2024-08-09 09:55:10 --> Security Class Initialized
DEBUG - 2024-08-09 09:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:55:10 --> Input Class Initialized
INFO - 2024-08-09 09:55:10 --> Language Class Initialized
DEBUG - 2024-08-09 09:55:10 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:10 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:10 --> Loader Class Initialized
INFO - 2024-08-09 09:55:10 --> Helper loaded: url_helper
INFO - 2024-08-09 09:55:10 --> Helper loaded: form_helper
INFO - 2024-08-09 09:55:10 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:55:10 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:55:10 --> Email Class Initialized
INFO - 2024-08-09 09:55:10 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:55:10 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:55:10 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:55:10 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:55:10 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:55:10 --> Controller Class Initialized
INFO - 2024-08-09 09:55:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:55:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:55:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 09:55:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:55:10 --> Final output sent to browser
DEBUG - 2024-08-09 09:55:10 --> Total execution time: 0.1241
INFO - 2024-08-09 09:55:12 --> Config Class Initialized
INFO - 2024-08-09 09:55:12 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:55:12 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:12 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:12 --> URI Class Initialized
INFO - 2024-08-09 09:55:12 --> Router Class Initialized
INFO - 2024-08-09 09:55:12 --> Output Class Initialized
INFO - 2024-08-09 09:55:12 --> Security Class Initialized
DEBUG - 2024-08-09 09:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:55:12 --> Input Class Initialized
INFO - 2024-08-09 09:55:12 --> Language Class Initialized
INFO - 2024-08-09 09:55:12 --> Loader Class Initialized
INFO - 2024-08-09 09:55:12 --> Helper loaded: url_helper
INFO - 2024-08-09 09:55:12 --> Helper loaded: form_helper
INFO - 2024-08-09 09:55:12 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:55:12 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:55:12 --> Email Class Initialized
INFO - 2024-08-09 09:55:12 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:55:12 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:55:12 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:55:12 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:55:12 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:55:12 --> Controller Class Initialized
INFO - 2024-08-09 09:55:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:55:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:55:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:55:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:55:12 --> Final output sent to browser
DEBUG - 2024-08-09 09:55:12 --> Total execution time: 0.1081
INFO - 2024-08-09 09:55:13 --> Config Class Initialized
INFO - 2024-08-09 09:55:13 --> Hooks Class Initialized
INFO - 2024-08-09 09:55:13 --> Config Class Initialized
INFO - 2024-08-09 09:55:13 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:55:13 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:13 --> Utf8 Class Initialized
DEBUG - 2024-08-09 09:55:13 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:13 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:13 --> URI Class Initialized
INFO - 2024-08-09 09:55:13 --> Router Class Initialized
INFO - 2024-08-09 09:55:13 --> Output Class Initialized
INFO - 2024-08-09 09:55:13 --> Security Class Initialized
DEBUG - 2024-08-09 09:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:55:13 --> Input Class Initialized
INFO - 2024-08-09 09:55:13 --> Language Class Initialized
INFO - 2024-08-09 09:55:13 --> Loader Class Initialized
INFO - 2024-08-09 09:55:13 --> Helper loaded: url_helper
INFO - 2024-08-09 09:55:13 --> Helper loaded: form_helper
INFO - 2024-08-09 09:55:13 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:55:13 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:55:13 --> Email Class Initialized
INFO - 2024-08-09 09:55:13 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:55:13 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:55:13 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:55:13 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:55:13 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:55:13 --> Controller Class Initialized
INFO - 2024-08-09 09:55:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:55:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:55:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:55:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:55:13 --> Final output sent to browser
DEBUG - 2024-08-09 09:55:13 --> Total execution time: 0.1376
INFO - 2024-08-09 09:55:17 --> Config Class Initialized
INFO - 2024-08-09 09:55:17 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:55:17 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:17 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:17 --> URI Class Initialized
INFO - 2024-08-09 09:55:17 --> Router Class Initialized
INFO - 2024-08-09 09:55:17 --> Output Class Initialized
INFO - 2024-08-09 09:55:17 --> Security Class Initialized
DEBUG - 2024-08-09 09:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:55:17 --> Input Class Initialized
INFO - 2024-08-09 09:55:17 --> Language Class Initialized
INFO - 2024-08-09 09:55:17 --> Loader Class Initialized
INFO - 2024-08-09 09:55:17 --> Helper loaded: url_helper
INFO - 2024-08-09 09:55:17 --> Helper loaded: form_helper
INFO - 2024-08-09 09:55:17 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:55:17 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:55:17 --> Email Class Initialized
INFO - 2024-08-09 09:55:17 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:55:17 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:55:17 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:55:17 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:55:17 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:55:17 --> Controller Class Initialized
INFO - 2024-08-09 09:55:18 --> Config Class Initialized
INFO - 2024-08-09 09:55:18 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:55:18 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:18 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:18 --> URI Class Initialized
INFO - 2024-08-09 09:55:18 --> Router Class Initialized
INFO - 2024-08-09 09:55:18 --> Output Class Initialized
INFO - 2024-08-09 09:55:18 --> Security Class Initialized
DEBUG - 2024-08-09 09:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:55:18 --> Input Class Initialized
INFO - 2024-08-09 09:55:18 --> Language Class Initialized
INFO - 2024-08-09 09:55:18 --> Loader Class Initialized
INFO - 2024-08-09 09:55:18 --> Helper loaded: url_helper
INFO - 2024-08-09 09:55:18 --> Helper loaded: form_helper
INFO - 2024-08-09 09:55:18 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:55:18 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:55:18 --> Email Class Initialized
INFO - 2024-08-09 09:55:18 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:55:18 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:55:18 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:55:18 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:55:18 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:55:18 --> Controller Class Initialized
INFO - 2024-08-09 09:55:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:55:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:55:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 09:55:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:55:18 --> Final output sent to browser
DEBUG - 2024-08-09 09:55:18 --> Total execution time: 0.0912
INFO - 2024-08-09 09:55:18 --> Config Class Initialized
INFO - 2024-08-09 09:55:18 --> Hooks Class Initialized
INFO - 2024-08-09 09:55:18 --> Config Class Initialized
INFO - 2024-08-09 09:55:18 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:55:18 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:18 --> Utf8 Class Initialized
DEBUG - 2024-08-09 09:55:18 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:18 --> URI Class Initialized
INFO - 2024-08-09 09:55:18 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:18 --> Router Class Initialized
INFO - 2024-08-09 09:55:18 --> Output Class Initialized
INFO - 2024-08-09 09:55:18 --> Security Class Initialized
DEBUG - 2024-08-09 09:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:55:18 --> Input Class Initialized
INFO - 2024-08-09 09:55:18 --> Language Class Initialized
INFO - 2024-08-09 09:55:18 --> Loader Class Initialized
INFO - 2024-08-09 09:55:18 --> Helper loaded: url_helper
INFO - 2024-08-09 09:55:18 --> Helper loaded: form_helper
INFO - 2024-08-09 09:55:18 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:55:18 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:55:18 --> Email Class Initialized
INFO - 2024-08-09 09:55:18 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:55:18 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:55:18 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:55:18 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:55:18 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:55:18 --> Controller Class Initialized
INFO - 2024-08-09 09:55:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:55:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:55:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 09:55:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:55:18 --> Final output sent to browser
DEBUG - 2024-08-09 09:55:18 --> Total execution time: 0.1159
INFO - 2024-08-09 09:55:22 --> Config Class Initialized
INFO - 2024-08-09 09:55:22 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:55:22 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:22 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:22 --> URI Class Initialized
INFO - 2024-08-09 09:55:22 --> Router Class Initialized
INFO - 2024-08-09 09:55:22 --> Output Class Initialized
INFO - 2024-08-09 09:55:22 --> Security Class Initialized
DEBUG - 2024-08-09 09:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:55:22 --> Input Class Initialized
INFO - 2024-08-09 09:55:22 --> Language Class Initialized
INFO - 2024-08-09 09:55:22 --> Loader Class Initialized
INFO - 2024-08-09 09:55:22 --> Helper loaded: url_helper
INFO - 2024-08-09 09:55:22 --> Helper loaded: form_helper
INFO - 2024-08-09 09:55:22 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:55:22 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:55:22 --> Email Class Initialized
INFO - 2024-08-09 09:55:22 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:55:22 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:55:22 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:55:22 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:55:22 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:55:22 --> Controller Class Initialized
INFO - 2024-08-09 09:55:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:55:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:55:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:55:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:55:22 --> Final output sent to browser
DEBUG - 2024-08-09 09:55:22 --> Total execution time: 0.1031
INFO - 2024-08-09 09:55:22 --> Config Class Initialized
INFO - 2024-08-09 09:55:22 --> Hooks Class Initialized
INFO - 2024-08-09 09:55:22 --> Config Class Initialized
INFO - 2024-08-09 09:55:22 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:55:22 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:22 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:22 --> URI Class Initialized
INFO - 2024-08-09 09:55:22 --> Router Class Initialized
INFO - 2024-08-09 09:55:22 --> Output Class Initialized
INFO - 2024-08-09 09:55:22 --> Security Class Initialized
DEBUG - 2024-08-09 09:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:55:22 --> Input Class Initialized
INFO - 2024-08-09 09:55:22 --> Language Class Initialized
DEBUG - 2024-08-09 09:55:22 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:22 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:22 --> Loader Class Initialized
INFO - 2024-08-09 09:55:22 --> Helper loaded: url_helper
INFO - 2024-08-09 09:55:22 --> Helper loaded: form_helper
INFO - 2024-08-09 09:55:22 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:55:22 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:55:22 --> Email Class Initialized
INFO - 2024-08-09 09:55:22 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:55:22 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:55:22 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:55:22 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:55:22 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:55:22 --> Controller Class Initialized
INFO - 2024-08-09 09:55:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:55:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:55:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:55:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:55:22 --> Final output sent to browser
DEBUG - 2024-08-09 09:55:22 --> Total execution time: 0.1154
INFO - 2024-08-09 09:55:29 --> Config Class Initialized
INFO - 2024-08-09 09:55:29 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:55:29 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:29 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:29 --> URI Class Initialized
INFO - 2024-08-09 09:55:29 --> Router Class Initialized
INFO - 2024-08-09 09:55:29 --> Output Class Initialized
INFO - 2024-08-09 09:55:29 --> Security Class Initialized
DEBUG - 2024-08-09 09:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:55:29 --> Input Class Initialized
INFO - 2024-08-09 09:55:29 --> Language Class Initialized
INFO - 2024-08-09 09:55:29 --> Loader Class Initialized
INFO - 2024-08-09 09:55:29 --> Helper loaded: url_helper
INFO - 2024-08-09 09:55:29 --> Helper loaded: form_helper
INFO - 2024-08-09 09:55:29 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:55:29 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:55:29 --> Email Class Initialized
INFO - 2024-08-09 09:55:29 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:55:29 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:55:29 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:55:29 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:55:29 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:55:29 --> Controller Class Initialized
INFO - 2024-08-09 09:55:30 --> Config Class Initialized
INFO - 2024-08-09 09:55:30 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:55:30 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:30 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:30 --> URI Class Initialized
INFO - 2024-08-09 09:55:30 --> Router Class Initialized
INFO - 2024-08-09 09:55:30 --> Output Class Initialized
INFO - 2024-08-09 09:55:30 --> Security Class Initialized
DEBUG - 2024-08-09 09:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:55:30 --> Input Class Initialized
INFO - 2024-08-09 09:55:30 --> Language Class Initialized
INFO - 2024-08-09 09:55:30 --> Loader Class Initialized
INFO - 2024-08-09 09:55:30 --> Helper loaded: url_helper
INFO - 2024-08-09 09:55:30 --> Helper loaded: form_helper
INFO - 2024-08-09 09:55:30 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:55:30 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:55:30 --> Email Class Initialized
INFO - 2024-08-09 09:55:30 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:55:30 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:55:30 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:55:30 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:55:30 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:55:30 --> Controller Class Initialized
INFO - 2024-08-09 09:55:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:55:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:55:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 09:55:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:55:30 --> Final output sent to browser
DEBUG - 2024-08-09 09:55:30 --> Total execution time: 0.1070
INFO - 2024-08-09 09:55:30 --> Config Class Initialized
INFO - 2024-08-09 09:55:30 --> Hooks Class Initialized
INFO - 2024-08-09 09:55:30 --> Config Class Initialized
INFO - 2024-08-09 09:55:30 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:55:30 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:30 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:30 --> URI Class Initialized
DEBUG - 2024-08-09 09:55:30 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:30 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:30 --> Router Class Initialized
INFO - 2024-08-09 09:55:30 --> Output Class Initialized
INFO - 2024-08-09 09:55:30 --> Security Class Initialized
DEBUG - 2024-08-09 09:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:55:30 --> Input Class Initialized
INFO - 2024-08-09 09:55:30 --> Language Class Initialized
INFO - 2024-08-09 09:55:30 --> Loader Class Initialized
INFO - 2024-08-09 09:55:30 --> Helper loaded: url_helper
INFO - 2024-08-09 09:55:30 --> Helper loaded: form_helper
INFO - 2024-08-09 09:55:30 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:55:30 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:55:30 --> Email Class Initialized
INFO - 2024-08-09 09:55:30 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:55:30 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:55:30 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:55:30 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:55:30 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:55:30 --> Controller Class Initialized
INFO - 2024-08-09 09:55:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:55:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:55:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 09:55:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:55:30 --> Final output sent to browser
DEBUG - 2024-08-09 09:55:30 --> Total execution time: 0.1135
INFO - 2024-08-09 09:55:48 --> Config Class Initialized
INFO - 2024-08-09 09:55:48 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:55:48 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:48 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:48 --> URI Class Initialized
INFO - 2024-08-09 09:55:48 --> Router Class Initialized
INFO - 2024-08-09 09:55:48 --> Output Class Initialized
INFO - 2024-08-09 09:55:48 --> Security Class Initialized
DEBUG - 2024-08-09 09:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:55:48 --> Input Class Initialized
INFO - 2024-08-09 09:55:48 --> Language Class Initialized
INFO - 2024-08-09 09:55:48 --> Loader Class Initialized
INFO - 2024-08-09 09:55:48 --> Helper loaded: url_helper
INFO - 2024-08-09 09:55:48 --> Helper loaded: form_helper
INFO - 2024-08-09 09:55:48 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:55:48 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:55:48 --> Email Class Initialized
INFO - 2024-08-09 09:55:48 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:55:48 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:55:48 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:55:48 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:55:48 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:55:48 --> Controller Class Initialized
INFO - 2024-08-09 09:55:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:55:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:55:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 09:55:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:55:48 --> Final output sent to browser
DEBUG - 2024-08-09 09:55:48 --> Total execution time: 0.1308
INFO - 2024-08-09 09:55:49 --> Config Class Initialized
INFO - 2024-08-09 09:55:49 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:55:49 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:49 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:49 --> Config Class Initialized
INFO - 2024-08-09 09:55:49 --> Hooks Class Initialized
INFO - 2024-08-09 09:55:49 --> URI Class Initialized
INFO - 2024-08-09 09:55:49 --> Router Class Initialized
DEBUG - 2024-08-09 09:55:49 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:49 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:49 --> Output Class Initialized
INFO - 2024-08-09 09:55:49 --> Security Class Initialized
DEBUG - 2024-08-09 09:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:55:49 --> Input Class Initialized
INFO - 2024-08-09 09:55:49 --> Language Class Initialized
INFO - 2024-08-09 09:55:49 --> Loader Class Initialized
INFO - 2024-08-09 09:55:49 --> Helper loaded: url_helper
INFO - 2024-08-09 09:55:49 --> Helper loaded: form_helper
INFO - 2024-08-09 09:55:49 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:55:49 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:55:49 --> Email Class Initialized
INFO - 2024-08-09 09:55:49 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:55:49 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:55:49 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:55:49 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:55:49 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:55:49 --> Controller Class Initialized
INFO - 2024-08-09 09:55:49 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:55:49 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:55:49 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 09:55:49 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:55:49 --> Final output sent to browser
DEBUG - 2024-08-09 09:55:49 --> Total execution time: 0.1357
INFO - 2024-08-09 09:55:51 --> Config Class Initialized
INFO - 2024-08-09 09:55:51 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:55:51 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:51 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:51 --> URI Class Initialized
INFO - 2024-08-09 09:55:51 --> Router Class Initialized
INFO - 2024-08-09 09:55:51 --> Output Class Initialized
INFO - 2024-08-09 09:55:51 --> Security Class Initialized
DEBUG - 2024-08-09 09:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:55:51 --> Input Class Initialized
INFO - 2024-08-09 09:55:51 --> Language Class Initialized
INFO - 2024-08-09 09:55:51 --> Loader Class Initialized
INFO - 2024-08-09 09:55:51 --> Helper loaded: url_helper
INFO - 2024-08-09 09:55:51 --> Helper loaded: form_helper
INFO - 2024-08-09 09:55:51 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:55:51 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:55:51 --> Email Class Initialized
INFO - 2024-08-09 09:55:51 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:55:51 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:55:51 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:55:51 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:55:51 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:55:51 --> Controller Class Initialized
INFO - 2024-08-09 09:55:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:55:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:55:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:55:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:55:51 --> Final output sent to browser
DEBUG - 2024-08-09 09:55:51 --> Total execution time: 0.1138
INFO - 2024-08-09 09:55:51 --> Config Class Initialized
INFO - 2024-08-09 09:55:51 --> Config Class Initialized
INFO - 2024-08-09 09:55:51 --> Hooks Class Initialized
INFO - 2024-08-09 09:55:51 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:55:51 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 09:55:51 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:51 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:51 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:51 --> URI Class Initialized
INFO - 2024-08-09 09:55:51 --> Router Class Initialized
INFO - 2024-08-09 09:55:51 --> Output Class Initialized
INFO - 2024-08-09 09:55:51 --> Security Class Initialized
DEBUG - 2024-08-09 09:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:55:51 --> Input Class Initialized
INFO - 2024-08-09 09:55:51 --> Language Class Initialized
INFO - 2024-08-09 09:55:51 --> Loader Class Initialized
INFO - 2024-08-09 09:55:51 --> Helper loaded: url_helper
INFO - 2024-08-09 09:55:51 --> Helper loaded: form_helper
INFO - 2024-08-09 09:55:51 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:55:51 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:55:52 --> Email Class Initialized
INFO - 2024-08-09 09:55:52 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:55:52 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:55:52 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:55:52 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:55:52 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:55:52 --> Controller Class Initialized
INFO - 2024-08-09 09:55:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:55:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:55:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:55:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:55:52 --> Final output sent to browser
DEBUG - 2024-08-09 09:55:52 --> Total execution time: 0.1278
INFO - 2024-08-09 09:55:55 --> Config Class Initialized
INFO - 2024-08-09 09:55:55 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:55:55 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:55:55 --> Utf8 Class Initialized
INFO - 2024-08-09 09:55:55 --> URI Class Initialized
INFO - 2024-08-09 09:55:55 --> Router Class Initialized
INFO - 2024-08-09 09:55:55 --> Output Class Initialized
INFO - 2024-08-09 09:55:55 --> Security Class Initialized
DEBUG - 2024-08-09 09:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:55:55 --> Input Class Initialized
INFO - 2024-08-09 09:55:55 --> Language Class Initialized
INFO - 2024-08-09 09:55:55 --> Loader Class Initialized
INFO - 2024-08-09 09:55:55 --> Helper loaded: url_helper
INFO - 2024-08-09 09:55:55 --> Helper loaded: form_helper
INFO - 2024-08-09 09:55:55 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:55:55 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:55:55 --> Email Class Initialized
INFO - 2024-08-09 09:55:55 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:55:55 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:55:55 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:55:55 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:55:55 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:55:55 --> Controller Class Initialized
INFO - 2024-08-09 09:55:55 --> Final output sent to browser
DEBUG - 2024-08-09 09:55:55 --> Total execution time: 0.1085
INFO - 2024-08-09 09:56:12 --> Config Class Initialized
INFO - 2024-08-09 09:56:12 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:56:12 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:56:12 --> Utf8 Class Initialized
INFO - 2024-08-09 09:56:12 --> URI Class Initialized
INFO - 2024-08-09 09:56:12 --> Router Class Initialized
INFO - 2024-08-09 09:56:12 --> Output Class Initialized
INFO - 2024-08-09 09:56:12 --> Security Class Initialized
DEBUG - 2024-08-09 09:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:56:12 --> Input Class Initialized
INFO - 2024-08-09 09:56:12 --> Language Class Initialized
INFO - 2024-08-09 09:56:12 --> Loader Class Initialized
INFO - 2024-08-09 09:56:12 --> Helper loaded: url_helper
INFO - 2024-08-09 09:56:12 --> Helper loaded: form_helper
INFO - 2024-08-09 09:56:12 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:56:12 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:56:13 --> Email Class Initialized
INFO - 2024-08-09 09:56:13 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:56:13 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:56:13 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:56:13 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:56:13 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:56:13 --> Controller Class Initialized
INFO - 2024-08-09 09:56:13 --> Config Class Initialized
INFO - 2024-08-09 09:56:13 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:56:13 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:56:13 --> Utf8 Class Initialized
INFO - 2024-08-09 09:56:13 --> URI Class Initialized
INFO - 2024-08-09 09:56:13 --> Router Class Initialized
INFO - 2024-08-09 09:56:13 --> Output Class Initialized
INFO - 2024-08-09 09:56:13 --> Security Class Initialized
DEBUG - 2024-08-09 09:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:56:13 --> Input Class Initialized
INFO - 2024-08-09 09:56:13 --> Language Class Initialized
INFO - 2024-08-09 09:56:13 --> Loader Class Initialized
INFO - 2024-08-09 09:56:13 --> Helper loaded: url_helper
INFO - 2024-08-09 09:56:13 --> Helper loaded: form_helper
INFO - 2024-08-09 09:56:13 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:56:13 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:56:13 --> Email Class Initialized
INFO - 2024-08-09 09:56:13 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:56:13 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:56:13 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:56:13 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:56:13 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:56:13 --> Controller Class Initialized
INFO - 2024-08-09 09:56:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:56:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:56:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:56:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:56:13 --> Final output sent to browser
DEBUG - 2024-08-09 09:56:13 --> Total execution time: 0.0906
INFO - 2024-08-09 09:56:13 --> Config Class Initialized
INFO - 2024-08-09 09:56:13 --> Hooks Class Initialized
INFO - 2024-08-09 09:56:13 --> Config Class Initialized
INFO - 2024-08-09 09:56:13 --> Hooks Class Initialized
DEBUG - 2024-08-09 09:56:13 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 09:56:13 --> UTF-8 Support Enabled
INFO - 2024-08-09 09:56:13 --> Utf8 Class Initialized
INFO - 2024-08-09 09:56:13 --> Utf8 Class Initialized
INFO - 2024-08-09 09:56:13 --> URI Class Initialized
INFO - 2024-08-09 09:56:13 --> Router Class Initialized
INFO - 2024-08-09 09:56:13 --> Output Class Initialized
INFO - 2024-08-09 09:56:13 --> Security Class Initialized
DEBUG - 2024-08-09 09:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 09:56:13 --> Input Class Initialized
INFO - 2024-08-09 09:56:13 --> Language Class Initialized
INFO - 2024-08-09 09:56:13 --> Loader Class Initialized
INFO - 2024-08-09 09:56:13 --> Helper loaded: url_helper
INFO - 2024-08-09 09:56:13 --> Helper loaded: form_helper
INFO - 2024-08-09 09:56:13 --> Helper loaded: funciones_helper
INFO - 2024-08-09 09:56:13 --> Database Driver Class Initialized
DEBUG - 2024-08-09 09:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 09:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 09:56:13 --> Email Class Initialized
INFO - 2024-08-09 09:56:13 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 09:56:13 --> Model "Pais_model" initialized
INFO - 2024-08-09 09:56:13 --> Model "Libro_model" initialized
INFO - 2024-08-09 09:56:13 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 09:56:13 --> Model "Usuario_model" initialized
INFO - 2024-08-09 09:56:13 --> Controller Class Initialized
INFO - 2024-08-09 09:56:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 09:56:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 09:56:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 09:56:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 09:56:13 --> Final output sent to browser
DEBUG - 2024-08-09 09:56:13 --> Total execution time: 0.2496
INFO - 2024-08-09 10:01:31 --> Config Class Initialized
INFO - 2024-08-09 10:01:31 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:01:31 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:01:31 --> Utf8 Class Initialized
INFO - 2024-08-09 10:01:31 --> URI Class Initialized
INFO - 2024-08-09 10:01:31 --> Router Class Initialized
INFO - 2024-08-09 10:01:31 --> Output Class Initialized
INFO - 2024-08-09 10:01:31 --> Security Class Initialized
DEBUG - 2024-08-09 10:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:01:31 --> Input Class Initialized
INFO - 2024-08-09 10:01:31 --> Language Class Initialized
INFO - 2024-08-09 10:01:31 --> Loader Class Initialized
INFO - 2024-08-09 10:01:31 --> Helper loaded: url_helper
INFO - 2024-08-09 10:01:31 --> Helper loaded: form_helper
INFO - 2024-08-09 10:01:31 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:01:31 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:01:31 --> Email Class Initialized
INFO - 2024-08-09 10:01:31 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:01:31 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:01:31 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:01:31 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:01:31 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:01:31 --> Controller Class Initialized
INFO - 2024-08-09 10:01:31 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:01:31 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:01:31 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:01:31 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:01:31 --> Final output sent to browser
DEBUG - 2024-08-09 10:01:31 --> Total execution time: 0.1357
INFO - 2024-08-09 10:01:32 --> Config Class Initialized
INFO - 2024-08-09 10:01:32 --> Config Class Initialized
INFO - 2024-08-09 10:01:32 --> Hooks Class Initialized
INFO - 2024-08-09 10:01:32 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:01:32 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:01:32 --> Utf8 Class Initialized
DEBUG - 2024-08-09 10:01:32 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:01:32 --> Utf8 Class Initialized
INFO - 2024-08-09 10:01:32 --> URI Class Initialized
INFO - 2024-08-09 10:01:32 --> Router Class Initialized
INFO - 2024-08-09 10:01:32 --> Output Class Initialized
INFO - 2024-08-09 10:01:32 --> Security Class Initialized
DEBUG - 2024-08-09 10:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:01:32 --> Input Class Initialized
INFO - 2024-08-09 10:01:32 --> Language Class Initialized
INFO - 2024-08-09 10:01:32 --> Loader Class Initialized
INFO - 2024-08-09 10:01:32 --> Helper loaded: url_helper
INFO - 2024-08-09 10:01:32 --> Helper loaded: form_helper
INFO - 2024-08-09 10:01:32 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:01:32 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:01:32 --> Email Class Initialized
INFO - 2024-08-09 10:01:32 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:01:32 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:01:32 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:01:32 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:01:32 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:01:32 --> Controller Class Initialized
INFO - 2024-08-09 10:01:32 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:01:32 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:01:32 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:01:32 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:01:32 --> Final output sent to browser
DEBUG - 2024-08-09 10:01:32 --> Total execution time: 0.1648
INFO - 2024-08-09 10:01:34 --> Config Class Initialized
INFO - 2024-08-09 10:01:34 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:01:34 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:01:34 --> Utf8 Class Initialized
INFO - 2024-08-09 10:01:34 --> URI Class Initialized
INFO - 2024-08-09 10:01:34 --> Router Class Initialized
INFO - 2024-08-09 10:01:34 --> Output Class Initialized
INFO - 2024-08-09 10:01:34 --> Security Class Initialized
DEBUG - 2024-08-09 10:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:01:34 --> Input Class Initialized
INFO - 2024-08-09 10:01:34 --> Language Class Initialized
INFO - 2024-08-09 10:01:34 --> Loader Class Initialized
INFO - 2024-08-09 10:01:34 --> Helper loaded: url_helper
INFO - 2024-08-09 10:01:34 --> Helper loaded: form_helper
INFO - 2024-08-09 10:01:34 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:01:34 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:01:34 --> Email Class Initialized
INFO - 2024-08-09 10:01:34 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:01:34 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:01:34 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:01:34 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:01:34 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:01:34 --> Controller Class Initialized
INFO - 2024-08-09 10:01:34 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:01:34 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:01:34 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:01:34 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:01:34 --> Final output sent to browser
DEBUG - 2024-08-09 10:01:34 --> Total execution time: 0.1002
INFO - 2024-08-09 10:01:35 --> Config Class Initialized
INFO - 2024-08-09 10:01:35 --> Hooks Class Initialized
INFO - 2024-08-09 10:01:35 --> Config Class Initialized
INFO - 2024-08-09 10:01:35 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:01:35 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:01:35 --> Utf8 Class Initialized
INFO - 2024-08-09 10:01:35 --> URI Class Initialized
DEBUG - 2024-08-09 10:01:35 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:01:35 --> Router Class Initialized
INFO - 2024-08-09 10:01:35 --> Utf8 Class Initialized
INFO - 2024-08-09 10:01:35 --> Output Class Initialized
INFO - 2024-08-09 10:01:35 --> Security Class Initialized
DEBUG - 2024-08-09 10:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:01:35 --> Input Class Initialized
INFO - 2024-08-09 10:01:35 --> Language Class Initialized
INFO - 2024-08-09 10:01:35 --> Loader Class Initialized
INFO - 2024-08-09 10:01:35 --> Helper loaded: url_helper
INFO - 2024-08-09 10:01:35 --> Helper loaded: form_helper
INFO - 2024-08-09 10:01:35 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:01:35 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:01:35 --> Email Class Initialized
INFO - 2024-08-09 10:01:35 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:01:35 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:01:35 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:01:35 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:01:35 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:01:35 --> Controller Class Initialized
INFO - 2024-08-09 10:01:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:01:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:01:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:01:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:01:35 --> Final output sent to browser
DEBUG - 2024-08-09 10:01:35 --> Total execution time: 0.1195
INFO - 2024-08-09 10:01:37 --> Config Class Initialized
INFO - 2024-08-09 10:01:37 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:01:37 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:01:37 --> Utf8 Class Initialized
INFO - 2024-08-09 10:01:37 --> URI Class Initialized
INFO - 2024-08-09 10:01:37 --> Router Class Initialized
INFO - 2024-08-09 10:01:37 --> Output Class Initialized
INFO - 2024-08-09 10:01:37 --> Security Class Initialized
DEBUG - 2024-08-09 10:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:01:37 --> Input Class Initialized
INFO - 2024-08-09 10:01:37 --> Language Class Initialized
INFO - 2024-08-09 10:01:37 --> Loader Class Initialized
INFO - 2024-08-09 10:01:37 --> Helper loaded: url_helper
INFO - 2024-08-09 10:01:37 --> Helper loaded: form_helper
INFO - 2024-08-09 10:01:37 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:01:37 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:01:37 --> Email Class Initialized
INFO - 2024-08-09 10:01:37 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:01:37 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:01:37 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:01:37 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:01:37 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:01:37 --> Controller Class Initialized
INFO - 2024-08-09 10:01:37 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:01:37 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:01:37 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:01:37 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:01:37 --> Final output sent to browser
DEBUG - 2024-08-09 10:01:37 --> Total execution time: 0.1050
INFO - 2024-08-09 10:01:37 --> Config Class Initialized
INFO - 2024-08-09 10:01:37 --> Hooks Class Initialized
INFO - 2024-08-09 10:01:37 --> Config Class Initialized
INFO - 2024-08-09 10:01:37 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:01:37 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:01:37 --> Utf8 Class Initialized
DEBUG - 2024-08-09 10:01:37 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:01:37 --> Utf8 Class Initialized
INFO - 2024-08-09 10:01:37 --> URI Class Initialized
INFO - 2024-08-09 10:01:37 --> Router Class Initialized
INFO - 2024-08-09 10:01:37 --> Output Class Initialized
INFO - 2024-08-09 10:01:37 --> Security Class Initialized
DEBUG - 2024-08-09 10:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:01:37 --> Input Class Initialized
INFO - 2024-08-09 10:01:37 --> Language Class Initialized
INFO - 2024-08-09 10:01:37 --> Loader Class Initialized
INFO - 2024-08-09 10:01:38 --> Helper loaded: url_helper
INFO - 2024-08-09 10:01:38 --> Helper loaded: form_helper
INFO - 2024-08-09 10:01:38 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:01:38 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:01:38 --> Email Class Initialized
INFO - 2024-08-09 10:01:38 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:01:38 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:01:38 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:01:38 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:01:38 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:01:38 --> Controller Class Initialized
INFO - 2024-08-09 10:01:38 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:01:38 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:01:38 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:01:38 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:01:38 --> Final output sent to browser
DEBUG - 2024-08-09 10:01:38 --> Total execution time: 0.1378
INFO - 2024-08-09 10:01:40 --> Config Class Initialized
INFO - 2024-08-09 10:01:40 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:01:40 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:01:40 --> Utf8 Class Initialized
INFO - 2024-08-09 10:01:40 --> URI Class Initialized
INFO - 2024-08-09 10:01:40 --> Router Class Initialized
INFO - 2024-08-09 10:01:40 --> Output Class Initialized
INFO - 2024-08-09 10:01:40 --> Security Class Initialized
DEBUG - 2024-08-09 10:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:01:41 --> Input Class Initialized
INFO - 2024-08-09 10:01:41 --> Language Class Initialized
INFO - 2024-08-09 10:01:41 --> Loader Class Initialized
INFO - 2024-08-09 10:01:41 --> Helper loaded: url_helper
INFO - 2024-08-09 10:01:41 --> Helper loaded: form_helper
INFO - 2024-08-09 10:01:41 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:01:41 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:01:41 --> Email Class Initialized
INFO - 2024-08-09 10:01:41 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:01:41 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:01:41 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:01:41 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:01:41 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:01:41 --> Controller Class Initialized
INFO - 2024-08-09 10:01:41 --> Config Class Initialized
INFO - 2024-08-09 10:01:41 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:01:41 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:01:41 --> Utf8 Class Initialized
INFO - 2024-08-09 10:01:41 --> URI Class Initialized
INFO - 2024-08-09 10:01:41 --> Router Class Initialized
INFO - 2024-08-09 10:01:41 --> Output Class Initialized
INFO - 2024-08-09 10:01:41 --> Security Class Initialized
DEBUG - 2024-08-09 10:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:01:41 --> Input Class Initialized
INFO - 2024-08-09 10:01:41 --> Language Class Initialized
INFO - 2024-08-09 10:01:41 --> Loader Class Initialized
INFO - 2024-08-09 10:01:41 --> Helper loaded: url_helper
INFO - 2024-08-09 10:01:41 --> Helper loaded: form_helper
INFO - 2024-08-09 10:01:41 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:01:41 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:01:41 --> Email Class Initialized
INFO - 2024-08-09 10:01:41 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:01:41 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:01:41 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:01:41 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:01:41 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:01:41 --> Controller Class Initialized
INFO - 2024-08-09 10:01:41 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:01:41 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:01:41 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:01:41 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:01:41 --> Final output sent to browser
DEBUG - 2024-08-09 10:01:41 --> Total execution time: 0.0849
INFO - 2024-08-09 10:01:41 --> Config Class Initialized
INFO - 2024-08-09 10:01:41 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:01:41 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:01:41 --> Config Class Initialized
INFO - 2024-08-09 10:01:41 --> Utf8 Class Initialized
INFO - 2024-08-09 10:01:41 --> Hooks Class Initialized
INFO - 2024-08-09 10:01:41 --> URI Class Initialized
DEBUG - 2024-08-09 10:01:41 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:01:41 --> Router Class Initialized
INFO - 2024-08-09 10:01:41 --> Utf8 Class Initialized
INFO - 2024-08-09 10:01:41 --> Output Class Initialized
INFO - 2024-08-09 10:01:41 --> Security Class Initialized
DEBUG - 2024-08-09 10:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:01:41 --> Input Class Initialized
INFO - 2024-08-09 10:01:41 --> Language Class Initialized
INFO - 2024-08-09 10:01:41 --> Loader Class Initialized
INFO - 2024-08-09 10:01:41 --> Helper loaded: url_helper
INFO - 2024-08-09 10:01:41 --> Helper loaded: form_helper
INFO - 2024-08-09 10:01:41 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:01:41 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:01:41 --> Email Class Initialized
INFO - 2024-08-09 10:01:41 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:01:41 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:01:41 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:01:41 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:01:41 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:01:41 --> Controller Class Initialized
INFO - 2024-08-09 10:01:41 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:01:41 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:01:41 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:01:41 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:01:41 --> Final output sent to browser
DEBUG - 2024-08-09 10:01:41 --> Total execution time: 0.1056
INFO - 2024-08-09 10:03:47 --> Config Class Initialized
INFO - 2024-08-09 10:03:47 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:03:47 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:03:47 --> Utf8 Class Initialized
INFO - 2024-08-09 10:03:47 --> URI Class Initialized
INFO - 2024-08-09 10:03:47 --> Router Class Initialized
INFO - 2024-08-09 10:03:47 --> Output Class Initialized
INFO - 2024-08-09 10:03:47 --> Security Class Initialized
DEBUG - 2024-08-09 10:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:03:48 --> Input Class Initialized
INFO - 2024-08-09 10:03:48 --> Language Class Initialized
INFO - 2024-08-09 10:03:48 --> Loader Class Initialized
INFO - 2024-08-09 10:03:48 --> Helper loaded: url_helper
INFO - 2024-08-09 10:03:48 --> Helper loaded: form_helper
INFO - 2024-08-09 10:03:48 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:03:48 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:03:48 --> Email Class Initialized
INFO - 2024-08-09 10:03:48 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:03:48 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:03:48 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:03:48 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:03:48 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:03:48 --> Controller Class Initialized
INFO - 2024-08-09 10:03:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:03:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:03:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:03:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:03:48 --> Final output sent to browser
DEBUG - 2024-08-09 10:03:48 --> Total execution time: 0.1390
INFO - 2024-08-09 10:03:49 --> Config Class Initialized
INFO - 2024-08-09 10:03:49 --> Hooks Class Initialized
INFO - 2024-08-09 10:03:49 --> Config Class Initialized
INFO - 2024-08-09 10:03:49 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:03:49 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:03:49 --> Utf8 Class Initialized
DEBUG - 2024-08-09 10:03:49 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:03:49 --> URI Class Initialized
INFO - 2024-08-09 10:03:49 --> Utf8 Class Initialized
INFO - 2024-08-09 10:03:49 --> Router Class Initialized
INFO - 2024-08-09 10:03:49 --> Output Class Initialized
INFO - 2024-08-09 10:03:49 --> Security Class Initialized
DEBUG - 2024-08-09 10:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:03:49 --> Input Class Initialized
INFO - 2024-08-09 10:03:49 --> Language Class Initialized
INFO - 2024-08-09 10:03:49 --> Loader Class Initialized
INFO - 2024-08-09 10:03:49 --> Helper loaded: url_helper
INFO - 2024-08-09 10:03:49 --> Helper loaded: form_helper
INFO - 2024-08-09 10:03:49 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:03:49 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:03:49 --> Email Class Initialized
INFO - 2024-08-09 10:03:49 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:03:49 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:03:49 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:03:49 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:03:49 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:03:49 --> Controller Class Initialized
INFO - 2024-08-09 10:03:49 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:03:49 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:03:49 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:03:49 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:03:49 --> Final output sent to browser
DEBUG - 2024-08-09 10:03:49 --> Total execution time: 0.2259
INFO - 2024-08-09 10:03:50 --> Config Class Initialized
INFO - 2024-08-09 10:03:50 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:03:50 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:03:50 --> Utf8 Class Initialized
INFO - 2024-08-09 10:03:50 --> URI Class Initialized
INFO - 2024-08-09 10:03:50 --> Router Class Initialized
INFO - 2024-08-09 10:03:50 --> Output Class Initialized
INFO - 2024-08-09 10:03:50 --> Security Class Initialized
DEBUG - 2024-08-09 10:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:03:50 --> Input Class Initialized
INFO - 2024-08-09 10:03:50 --> Language Class Initialized
INFO - 2024-08-09 10:03:50 --> Loader Class Initialized
INFO - 2024-08-09 10:03:50 --> Helper loaded: url_helper
INFO - 2024-08-09 10:03:50 --> Helper loaded: form_helper
INFO - 2024-08-09 10:03:50 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:03:50 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:03:50 --> Email Class Initialized
INFO - 2024-08-09 10:03:50 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:03:50 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:03:50 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:03:50 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:03:50 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:03:50 --> Controller Class Initialized
INFO - 2024-08-09 10:03:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:03:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:03:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:03:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:03:50 --> Final output sent to browser
DEBUG - 2024-08-09 10:03:50 --> Total execution time: 0.1263
INFO - 2024-08-09 10:03:51 --> Config Class Initialized
INFO - 2024-08-09 10:03:51 --> Hooks Class Initialized
INFO - 2024-08-09 10:03:51 --> Config Class Initialized
INFO - 2024-08-09 10:03:51 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:03:51 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:03:51 --> Utf8 Class Initialized
DEBUG - 2024-08-09 10:03:51 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:03:51 --> Utf8 Class Initialized
INFO - 2024-08-09 10:03:51 --> URI Class Initialized
INFO - 2024-08-09 10:03:51 --> Router Class Initialized
INFO - 2024-08-09 10:03:51 --> Output Class Initialized
INFO - 2024-08-09 10:03:51 --> Security Class Initialized
DEBUG - 2024-08-09 10:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:03:51 --> Input Class Initialized
INFO - 2024-08-09 10:03:51 --> Language Class Initialized
INFO - 2024-08-09 10:03:51 --> Loader Class Initialized
INFO - 2024-08-09 10:03:51 --> Helper loaded: url_helper
INFO - 2024-08-09 10:03:51 --> Helper loaded: form_helper
INFO - 2024-08-09 10:03:51 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:03:51 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:03:51 --> Email Class Initialized
INFO - 2024-08-09 10:03:51 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:03:51 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:03:51 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:03:51 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:03:51 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:03:51 --> Controller Class Initialized
INFO - 2024-08-09 10:03:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:03:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:03:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:03:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:03:51 --> Final output sent to browser
DEBUG - 2024-08-09 10:03:51 --> Total execution time: 0.1202
INFO - 2024-08-09 10:03:53 --> Config Class Initialized
INFO - 2024-08-09 10:03:53 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:03:53 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:03:53 --> Utf8 Class Initialized
INFO - 2024-08-09 10:03:53 --> URI Class Initialized
INFO - 2024-08-09 10:03:53 --> Router Class Initialized
INFO - 2024-08-09 10:03:53 --> Output Class Initialized
INFO - 2024-08-09 10:03:53 --> Security Class Initialized
DEBUG - 2024-08-09 10:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:03:53 --> Input Class Initialized
INFO - 2024-08-09 10:03:53 --> Language Class Initialized
INFO - 2024-08-09 10:03:53 --> Loader Class Initialized
INFO - 2024-08-09 10:03:53 --> Helper loaded: url_helper
INFO - 2024-08-09 10:03:53 --> Helper loaded: form_helper
INFO - 2024-08-09 10:03:53 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:03:53 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:03:53 --> Email Class Initialized
INFO - 2024-08-09 10:03:53 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:03:53 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:03:53 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:03:53 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:03:53 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:03:53 --> Controller Class Initialized
INFO - 2024-08-09 10:03:53 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:03:53 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:03:53 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:03:53 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:03:53 --> Final output sent to browser
DEBUG - 2024-08-09 10:03:53 --> Total execution time: 0.1024
INFO - 2024-08-09 10:03:54 --> Config Class Initialized
INFO - 2024-08-09 10:03:54 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:03:54 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:03:54 --> Utf8 Class Initialized
INFO - 2024-08-09 10:03:54 --> Config Class Initialized
INFO - 2024-08-09 10:03:54 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:03:54 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:03:54 --> Utf8 Class Initialized
INFO - 2024-08-09 10:03:54 --> URI Class Initialized
INFO - 2024-08-09 10:03:54 --> Router Class Initialized
INFO - 2024-08-09 10:03:54 --> Output Class Initialized
INFO - 2024-08-09 10:03:54 --> Security Class Initialized
DEBUG - 2024-08-09 10:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:03:54 --> Input Class Initialized
INFO - 2024-08-09 10:03:54 --> Language Class Initialized
INFO - 2024-08-09 10:03:54 --> Loader Class Initialized
INFO - 2024-08-09 10:03:54 --> Helper loaded: url_helper
INFO - 2024-08-09 10:03:54 --> Helper loaded: form_helper
INFO - 2024-08-09 10:03:54 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:03:54 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:03:54 --> Email Class Initialized
INFO - 2024-08-09 10:03:54 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:03:54 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:03:54 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:03:54 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:03:54 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:03:54 --> Controller Class Initialized
INFO - 2024-08-09 10:03:54 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:03:54 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:03:54 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:03:54 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:03:54 --> Final output sent to browser
DEBUG - 2024-08-09 10:03:54 --> Total execution time: 0.1621
INFO - 2024-08-09 10:03:56 --> Config Class Initialized
INFO - 2024-08-09 10:03:56 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:03:56 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:03:56 --> Utf8 Class Initialized
INFO - 2024-08-09 10:03:56 --> URI Class Initialized
INFO - 2024-08-09 10:03:56 --> Router Class Initialized
INFO - 2024-08-09 10:03:56 --> Output Class Initialized
INFO - 2024-08-09 10:03:56 --> Security Class Initialized
DEBUG - 2024-08-09 10:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:03:56 --> Input Class Initialized
INFO - 2024-08-09 10:03:56 --> Language Class Initialized
INFO - 2024-08-09 10:03:56 --> Loader Class Initialized
INFO - 2024-08-09 10:03:56 --> Helper loaded: url_helper
INFO - 2024-08-09 10:03:56 --> Helper loaded: form_helper
INFO - 2024-08-09 10:03:56 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:03:56 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:03:56 --> Email Class Initialized
INFO - 2024-08-09 10:03:56 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:03:56 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:03:56 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:03:56 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:03:56 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:03:56 --> Controller Class Initialized
INFO - 2024-08-09 10:03:56 --> Config Class Initialized
INFO - 2024-08-09 10:03:56 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:03:56 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:03:56 --> Utf8 Class Initialized
INFO - 2024-08-09 10:03:56 --> URI Class Initialized
INFO - 2024-08-09 10:03:56 --> Router Class Initialized
INFO - 2024-08-09 10:03:56 --> Output Class Initialized
INFO - 2024-08-09 10:03:56 --> Security Class Initialized
DEBUG - 2024-08-09 10:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:03:56 --> Input Class Initialized
INFO - 2024-08-09 10:03:56 --> Language Class Initialized
INFO - 2024-08-09 10:03:56 --> Loader Class Initialized
INFO - 2024-08-09 10:03:56 --> Helper loaded: url_helper
INFO - 2024-08-09 10:03:56 --> Helper loaded: form_helper
INFO - 2024-08-09 10:03:56 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:03:56 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:03:56 --> Email Class Initialized
INFO - 2024-08-09 10:03:56 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:03:56 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:03:56 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:03:56 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:03:56 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:03:56 --> Controller Class Initialized
INFO - 2024-08-09 10:03:56 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:03:56 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:03:56 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:03:56 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:03:56 --> Final output sent to browser
DEBUG - 2024-08-09 10:03:56 --> Total execution time: 0.0973
INFO - 2024-08-09 10:03:57 --> Config Class Initialized
INFO - 2024-08-09 10:03:57 --> Hooks Class Initialized
INFO - 2024-08-09 10:03:57 --> Config Class Initialized
INFO - 2024-08-09 10:03:57 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:03:57 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 10:03:57 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:03:57 --> Utf8 Class Initialized
INFO - 2024-08-09 10:03:57 --> Utf8 Class Initialized
INFO - 2024-08-09 10:03:57 --> URI Class Initialized
INFO - 2024-08-09 10:03:57 --> Router Class Initialized
INFO - 2024-08-09 10:03:57 --> Output Class Initialized
INFO - 2024-08-09 10:03:57 --> Security Class Initialized
DEBUG - 2024-08-09 10:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:03:57 --> Input Class Initialized
INFO - 2024-08-09 10:03:57 --> Language Class Initialized
INFO - 2024-08-09 10:03:57 --> Loader Class Initialized
INFO - 2024-08-09 10:03:57 --> Helper loaded: url_helper
INFO - 2024-08-09 10:03:57 --> Helper loaded: form_helper
INFO - 2024-08-09 10:03:57 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:03:57 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:03:57 --> Email Class Initialized
INFO - 2024-08-09 10:03:57 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:03:57 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:03:57 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:03:57 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:03:57 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:03:57 --> Controller Class Initialized
INFO - 2024-08-09 10:03:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:03:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:03:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:03:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:03:57 --> Final output sent to browser
DEBUG - 2024-08-09 10:03:57 --> Total execution time: 0.1406
INFO - 2024-08-09 10:13:18 --> Config Class Initialized
INFO - 2024-08-09 10:13:18 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:13:18 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:13:18 --> Utf8 Class Initialized
INFO - 2024-08-09 10:13:18 --> URI Class Initialized
INFO - 2024-08-09 10:13:18 --> Router Class Initialized
INFO - 2024-08-09 10:13:18 --> Output Class Initialized
INFO - 2024-08-09 10:13:18 --> Security Class Initialized
DEBUG - 2024-08-09 10:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:13:18 --> Input Class Initialized
INFO - 2024-08-09 10:13:18 --> Language Class Initialized
INFO - 2024-08-09 10:13:18 --> Loader Class Initialized
INFO - 2024-08-09 10:13:18 --> Helper loaded: url_helper
INFO - 2024-08-09 10:13:18 --> Helper loaded: form_helper
INFO - 2024-08-09 10:13:18 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:13:18 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:13:18 --> Email Class Initialized
INFO - 2024-08-09 10:13:18 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:13:18 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:13:18 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:13:18 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:13:18 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:13:18 --> Controller Class Initialized
INFO - 2024-08-09 10:13:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:13:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 10:13:18 --> Severity: Warning --> Undefined array key "idUsuario" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 38
ERROR - 2024-08-09 10:13:18 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 43
ERROR - 2024-08-09 10:13:18 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 49
ERROR - 2024-08-09 10:13:18 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 55
ERROR - 2024-08-09 10:13:18 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 61
ERROR - 2024-08-09 10:13:18 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 67
ERROR - 2024-08-09 10:13:18 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 74
ERROR - 2024-08-09 10:13:18 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 75
ERROR - 2024-08-09 10:13:18 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 76
ERROR - 2024-08-09 10:13:18 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 83
ERROR - 2024-08-09 10:13:18 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 90
ERROR - 2024-08-09 10:13:18 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 94
INFO - 2024-08-09 10:13:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:13:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:13:18 --> Final output sent to browser
DEBUG - 2024-08-09 10:13:18 --> Total execution time: 0.1647
INFO - 2024-08-09 10:13:19 --> Config Class Initialized
INFO - 2024-08-09 10:13:19 --> Hooks Class Initialized
INFO - 2024-08-09 10:13:19 --> Config Class Initialized
INFO - 2024-08-09 10:13:19 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:13:19 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:13:19 --> Utf8 Class Initialized
INFO - 2024-08-09 10:13:19 --> URI Class Initialized
INFO - 2024-08-09 10:13:19 --> Router Class Initialized
INFO - 2024-08-09 10:13:19 --> Output Class Initialized
INFO - 2024-08-09 10:13:19 --> Security Class Initialized
DEBUG - 2024-08-09 10:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:13:19 --> Input Class Initialized
INFO - 2024-08-09 10:13:19 --> Language Class Initialized
INFO - 2024-08-09 10:13:19 --> Loader Class Initialized
DEBUG - 2024-08-09 10:13:19 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:13:19 --> Utf8 Class Initialized
INFO - 2024-08-09 10:13:19 --> Helper loaded: url_helper
INFO - 2024-08-09 10:13:19 --> Helper loaded: form_helper
INFO - 2024-08-09 10:13:19 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:13:19 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:13:19 --> Email Class Initialized
INFO - 2024-08-09 10:13:19 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:13:19 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:13:19 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:13:19 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:13:19 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:13:19 --> Controller Class Initialized
INFO - 2024-08-09 10:13:20 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:13:20 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 10:13:20 --> Severity: Warning --> Undefined array key "idUsuario" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 38
ERROR - 2024-08-09 10:13:20 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 43
ERROR - 2024-08-09 10:13:20 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 49
ERROR - 2024-08-09 10:13:20 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 55
ERROR - 2024-08-09 10:13:20 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 61
ERROR - 2024-08-09 10:13:20 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 67
ERROR - 2024-08-09 10:13:20 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 74
ERROR - 2024-08-09 10:13:20 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 75
ERROR - 2024-08-09 10:13:20 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 76
ERROR - 2024-08-09 10:13:20 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 83
ERROR - 2024-08-09 10:13:20 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 90
ERROR - 2024-08-09 10:13:20 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 94
INFO - 2024-08-09 10:13:20 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:13:20 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:13:20 --> Final output sent to browser
DEBUG - 2024-08-09 10:13:20 --> Total execution time: 0.1856
INFO - 2024-08-09 10:13:29 --> Config Class Initialized
INFO - 2024-08-09 10:13:29 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:13:29 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:13:29 --> Utf8 Class Initialized
INFO - 2024-08-09 10:13:29 --> URI Class Initialized
INFO - 2024-08-09 10:13:29 --> Router Class Initialized
INFO - 2024-08-09 10:13:29 --> Output Class Initialized
INFO - 2024-08-09 10:13:29 --> Security Class Initialized
DEBUG - 2024-08-09 10:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:13:29 --> Input Class Initialized
INFO - 2024-08-09 10:13:29 --> Language Class Initialized
INFO - 2024-08-09 10:13:29 --> Loader Class Initialized
INFO - 2024-08-09 10:13:29 --> Helper loaded: url_helper
INFO - 2024-08-09 10:13:29 --> Helper loaded: form_helper
INFO - 2024-08-09 10:13:29 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:13:29 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:13:29 --> Email Class Initialized
INFO - 2024-08-09 10:13:29 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:13:29 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:13:29 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:13:29 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:13:29 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:13:29 --> Controller Class Initialized
INFO - 2024-08-09 10:13:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:13:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:13:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:13:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:13:29 --> Final output sent to browser
DEBUG - 2024-08-09 10:13:29 --> Total execution time: 0.1014
INFO - 2024-08-09 10:13:29 --> Config Class Initialized
INFO - 2024-08-09 10:13:29 --> Hooks Class Initialized
INFO - 2024-08-09 10:13:29 --> Config Class Initialized
INFO - 2024-08-09 10:13:29 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:13:29 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:13:29 --> Utf8 Class Initialized
INFO - 2024-08-09 10:13:29 --> URI Class Initialized
DEBUG - 2024-08-09 10:13:29 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:13:29 --> Utf8 Class Initialized
INFO - 2024-08-09 10:13:29 --> Router Class Initialized
INFO - 2024-08-09 10:13:29 --> Output Class Initialized
INFO - 2024-08-09 10:13:29 --> Security Class Initialized
DEBUG - 2024-08-09 10:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:13:30 --> Input Class Initialized
INFO - 2024-08-09 10:13:30 --> Language Class Initialized
INFO - 2024-08-09 10:13:30 --> Loader Class Initialized
INFO - 2024-08-09 10:13:30 --> Helper loaded: url_helper
INFO - 2024-08-09 10:13:30 --> Helper loaded: form_helper
INFO - 2024-08-09 10:13:30 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:13:30 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:13:30 --> Email Class Initialized
INFO - 2024-08-09 10:13:30 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:13:30 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:13:30 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:13:30 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:13:30 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:13:30 --> Controller Class Initialized
INFO - 2024-08-09 10:13:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:13:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:13:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:13:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:13:30 --> Final output sent to browser
DEBUG - 2024-08-09 10:13:30 --> Total execution time: 0.1351
INFO - 2024-08-09 10:13:32 --> Config Class Initialized
INFO - 2024-08-09 10:13:32 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:13:32 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:13:32 --> Utf8 Class Initialized
INFO - 2024-08-09 10:13:32 --> URI Class Initialized
INFO - 2024-08-09 10:13:32 --> Router Class Initialized
INFO - 2024-08-09 10:13:32 --> Output Class Initialized
INFO - 2024-08-09 10:13:32 --> Security Class Initialized
DEBUG - 2024-08-09 10:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:13:32 --> Input Class Initialized
INFO - 2024-08-09 10:13:32 --> Language Class Initialized
INFO - 2024-08-09 10:13:32 --> Loader Class Initialized
INFO - 2024-08-09 10:13:32 --> Helper loaded: url_helper
INFO - 2024-08-09 10:13:32 --> Helper loaded: form_helper
INFO - 2024-08-09 10:13:32 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:13:32 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:13:32 --> Email Class Initialized
INFO - 2024-08-09 10:13:32 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:13:32 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:13:32 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:13:32 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:13:32 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:13:32 --> Controller Class Initialized
INFO - 2024-08-09 10:13:32 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:13:32 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "idUsuario" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 38
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 43
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 49
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 55
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 61
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 67
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 74
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 75
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 76
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 83
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 90
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 94
INFO - 2024-08-09 10:13:32 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:13:32 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:13:32 --> Final output sent to browser
DEBUG - 2024-08-09 10:13:32 --> Total execution time: 0.1303
INFO - 2024-08-09 10:13:32 --> Config Class Initialized
INFO - 2024-08-09 10:13:32 --> Hooks Class Initialized
INFO - 2024-08-09 10:13:32 --> Config Class Initialized
INFO - 2024-08-09 10:13:32 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:13:32 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:13:32 --> Utf8 Class Initialized
DEBUG - 2024-08-09 10:13:32 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:13:32 --> Utf8 Class Initialized
INFO - 2024-08-09 10:13:32 --> URI Class Initialized
INFO - 2024-08-09 10:13:32 --> Router Class Initialized
INFO - 2024-08-09 10:13:32 --> Output Class Initialized
INFO - 2024-08-09 10:13:32 --> Security Class Initialized
DEBUG - 2024-08-09 10:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:13:32 --> Input Class Initialized
INFO - 2024-08-09 10:13:32 --> Language Class Initialized
INFO - 2024-08-09 10:13:32 --> Loader Class Initialized
INFO - 2024-08-09 10:13:32 --> Helper loaded: url_helper
INFO - 2024-08-09 10:13:32 --> Helper loaded: form_helper
INFO - 2024-08-09 10:13:32 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:13:32 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:13:32 --> Email Class Initialized
INFO - 2024-08-09 10:13:32 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:13:32 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:13:32 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:13:32 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:13:32 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:13:32 --> Controller Class Initialized
INFO - 2024-08-09 10:13:32 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:13:32 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "idUsuario" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 38
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 43
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 49
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 55
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 61
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 67
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 74
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 75
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 76
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 83
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 90
ERROR - 2024-08-09 10:13:32 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 94
INFO - 2024-08-09 10:13:32 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:13:32 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:13:32 --> Final output sent to browser
DEBUG - 2024-08-09 10:13:32 --> Total execution time: 0.1543
INFO - 2024-08-09 10:17:08 --> Config Class Initialized
INFO - 2024-08-09 10:17:08 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:17:08 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:17:08 --> Utf8 Class Initialized
INFO - 2024-08-09 10:17:08 --> URI Class Initialized
INFO - 2024-08-09 10:17:08 --> Router Class Initialized
INFO - 2024-08-09 10:17:08 --> Output Class Initialized
INFO - 2024-08-09 10:17:08 --> Security Class Initialized
DEBUG - 2024-08-09 10:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:17:08 --> Input Class Initialized
INFO - 2024-08-09 10:17:08 --> Language Class Initialized
INFO - 2024-08-09 10:17:08 --> Loader Class Initialized
INFO - 2024-08-09 10:17:08 --> Helper loaded: url_helper
INFO - 2024-08-09 10:17:08 --> Helper loaded: form_helper
INFO - 2024-08-09 10:17:08 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:17:08 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:17:08 --> Email Class Initialized
INFO - 2024-08-09 10:17:08 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:17:08 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:17:08 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:17:08 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:17:08 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:17:08 --> Controller Class Initialized
INFO - 2024-08-09 10:17:08 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:17:08 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "idUsuario" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 38
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 43
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 49
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 55
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 61
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 67
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 74
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 75
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 76
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 83
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 90
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 94
INFO - 2024-08-09 10:17:08 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:17:08 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:17:08 --> Final output sent to browser
DEBUG - 2024-08-09 10:17:08 --> Total execution time: 0.1824
INFO - 2024-08-09 10:17:08 --> Config Class Initialized
INFO - 2024-08-09 10:17:08 --> Hooks Class Initialized
INFO - 2024-08-09 10:17:08 --> Config Class Initialized
INFO - 2024-08-09 10:17:08 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:17:08 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:17:08 --> Utf8 Class Initialized
INFO - 2024-08-09 10:17:08 --> URI Class Initialized
DEBUG - 2024-08-09 10:17:08 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:17:08 --> Router Class Initialized
INFO - 2024-08-09 10:17:08 --> Utf8 Class Initialized
INFO - 2024-08-09 10:17:08 --> Output Class Initialized
INFO - 2024-08-09 10:17:08 --> Security Class Initialized
DEBUG - 2024-08-09 10:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:17:08 --> Input Class Initialized
INFO - 2024-08-09 10:17:08 --> Language Class Initialized
INFO - 2024-08-09 10:17:08 --> Loader Class Initialized
INFO - 2024-08-09 10:17:08 --> Helper loaded: url_helper
INFO - 2024-08-09 10:17:08 --> Helper loaded: form_helper
INFO - 2024-08-09 10:17:08 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:17:08 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:17:08 --> Email Class Initialized
INFO - 2024-08-09 10:17:08 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:17:08 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:17:08 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:17:08 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:17:08 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:17:08 --> Controller Class Initialized
INFO - 2024-08-09 10:17:08 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:17:08 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "idUsuario" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 38
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 43
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 49
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 55
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 61
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 67
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 74
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 75
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 76
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 83
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 90
ERROR - 2024-08-09 10:17:08 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 94
INFO - 2024-08-09 10:17:08 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:17:08 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:17:08 --> Final output sent to browser
DEBUG - 2024-08-09 10:17:08 --> Total execution time: 0.1382
INFO - 2024-08-09 10:19:45 --> Config Class Initialized
INFO - 2024-08-09 10:19:45 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:19:45 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:19:45 --> Utf8 Class Initialized
INFO - 2024-08-09 10:19:45 --> URI Class Initialized
INFO - 2024-08-09 10:19:45 --> Router Class Initialized
INFO - 2024-08-09 10:19:45 --> Output Class Initialized
INFO - 2024-08-09 10:19:45 --> Security Class Initialized
DEBUG - 2024-08-09 10:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:19:45 --> Input Class Initialized
INFO - 2024-08-09 10:19:45 --> Language Class Initialized
INFO - 2024-08-09 10:19:45 --> Loader Class Initialized
INFO - 2024-08-09 10:19:45 --> Helper loaded: url_helper
INFO - 2024-08-09 10:19:45 --> Helper loaded: form_helper
INFO - 2024-08-09 10:19:45 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:19:45 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:19:45 --> Email Class Initialized
INFO - 2024-08-09 10:19:45 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:19:45 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:19:45 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:19:45 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:19:45 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:19:45 --> Controller Class Initialized
INFO - 2024-08-09 10:19:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:19:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:19:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:19:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:19:45 --> Final output sent to browser
DEBUG - 2024-08-09 10:19:45 --> Total execution time: 0.2233
INFO - 2024-08-09 10:19:46 --> Config Class Initialized
INFO - 2024-08-09 10:19:46 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:19:46 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:19:46 --> Utf8 Class Initialized
INFO - 2024-08-09 10:19:46 --> URI Class Initialized
INFO - 2024-08-09 10:19:46 --> Router Class Initialized
INFO - 2024-08-09 10:19:46 --> Config Class Initialized
INFO - 2024-08-09 10:19:46 --> Hooks Class Initialized
INFO - 2024-08-09 10:19:46 --> Output Class Initialized
INFO - 2024-08-09 10:19:46 --> Security Class Initialized
DEBUG - 2024-08-09 10:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:19:46 --> Input Class Initialized
DEBUG - 2024-08-09 10:19:46 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:19:46 --> Utf8 Class Initialized
INFO - 2024-08-09 10:19:46 --> Language Class Initialized
INFO - 2024-08-09 10:19:46 --> Loader Class Initialized
INFO - 2024-08-09 10:19:46 --> Helper loaded: url_helper
INFO - 2024-08-09 10:19:46 --> Helper loaded: form_helper
INFO - 2024-08-09 10:19:46 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:19:46 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:19:46 --> Email Class Initialized
INFO - 2024-08-09 10:19:46 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:19:46 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:19:46 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:19:46 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:19:46 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:19:46 --> Controller Class Initialized
INFO - 2024-08-09 10:19:46 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:19:46 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:19:46 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:19:46 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:19:46 --> Final output sent to browser
DEBUG - 2024-08-09 10:19:46 --> Total execution time: 0.1241
INFO - 2024-08-09 10:19:56 --> Config Class Initialized
INFO - 2024-08-09 10:19:56 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:19:56 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:19:56 --> Utf8 Class Initialized
INFO - 2024-08-09 10:19:56 --> URI Class Initialized
INFO - 2024-08-09 10:19:56 --> Router Class Initialized
INFO - 2024-08-09 10:19:56 --> Output Class Initialized
INFO - 2024-08-09 10:19:56 --> Security Class Initialized
DEBUG - 2024-08-09 10:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:19:56 --> Input Class Initialized
INFO - 2024-08-09 10:19:56 --> Language Class Initialized
INFO - 2024-08-09 10:19:56 --> Loader Class Initialized
INFO - 2024-08-09 10:19:56 --> Helper loaded: url_helper
INFO - 2024-08-09 10:19:56 --> Helper loaded: form_helper
INFO - 2024-08-09 10:19:56 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:19:56 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:19:56 --> Email Class Initialized
INFO - 2024-08-09 10:19:56 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:19:56 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:19:56 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:19:56 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:19:56 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:19:56 --> Controller Class Initialized
INFO - 2024-08-09 10:19:56 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:19:56 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:19:56 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:19:56 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:19:56 --> Final output sent to browser
DEBUG - 2024-08-09 10:19:56 --> Total execution time: 0.1052
INFO - 2024-08-09 10:19:57 --> Config Class Initialized
INFO - 2024-08-09 10:19:57 --> Hooks Class Initialized
INFO - 2024-08-09 10:19:57 --> Config Class Initialized
INFO - 2024-08-09 10:19:57 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:19:57 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:19:57 --> Utf8 Class Initialized
INFO - 2024-08-09 10:19:57 --> URI Class Initialized
DEBUG - 2024-08-09 10:19:57 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:19:57 --> Utf8 Class Initialized
INFO - 2024-08-09 10:19:57 --> Router Class Initialized
INFO - 2024-08-09 10:19:57 --> Output Class Initialized
INFO - 2024-08-09 10:19:57 --> Security Class Initialized
DEBUG - 2024-08-09 10:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:19:57 --> Input Class Initialized
INFO - 2024-08-09 10:19:57 --> Language Class Initialized
INFO - 2024-08-09 10:19:57 --> Loader Class Initialized
INFO - 2024-08-09 10:19:57 --> Helper loaded: url_helper
INFO - 2024-08-09 10:19:57 --> Helper loaded: form_helper
INFO - 2024-08-09 10:19:57 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:19:57 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:19:57 --> Email Class Initialized
INFO - 2024-08-09 10:19:57 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:19:57 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:19:57 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:19:57 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:19:57 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:19:57 --> Controller Class Initialized
INFO - 2024-08-09 10:19:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:19:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:19:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:19:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:19:57 --> Final output sent to browser
DEBUG - 2024-08-09 10:19:57 --> Total execution time: 0.1193
INFO - 2024-08-09 10:19:59 --> Config Class Initialized
INFO - 2024-08-09 10:19:59 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:19:59 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:19:59 --> Utf8 Class Initialized
INFO - 2024-08-09 10:19:59 --> URI Class Initialized
INFO - 2024-08-09 10:19:59 --> Router Class Initialized
INFO - 2024-08-09 10:19:59 --> Output Class Initialized
INFO - 2024-08-09 10:19:59 --> Security Class Initialized
DEBUG - 2024-08-09 10:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:19:59 --> Input Class Initialized
INFO - 2024-08-09 10:19:59 --> Language Class Initialized
INFO - 2024-08-09 10:19:59 --> Loader Class Initialized
INFO - 2024-08-09 10:19:59 --> Helper loaded: url_helper
INFO - 2024-08-09 10:19:59 --> Helper loaded: form_helper
INFO - 2024-08-09 10:19:59 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:19:59 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:19:59 --> Email Class Initialized
INFO - 2024-08-09 10:19:59 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:19:59 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:19:59 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:19:59 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:19:59 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:19:59 --> Controller Class Initialized
INFO - 2024-08-09 10:19:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:19:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:19:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:19:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:19:59 --> Final output sent to browser
DEBUG - 2024-08-09 10:19:59 --> Total execution time: 0.1296
INFO - 2024-08-09 10:19:59 --> Config Class Initialized
INFO - 2024-08-09 10:19:59 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:19:59 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:19:59 --> Utf8 Class Initialized
INFO - 2024-08-09 10:19:59 --> Config Class Initialized
INFO - 2024-08-09 10:19:59 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:19:59 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:19:59 --> Utf8 Class Initialized
INFO - 2024-08-09 10:19:59 --> URI Class Initialized
INFO - 2024-08-09 10:19:59 --> Router Class Initialized
INFO - 2024-08-09 10:19:59 --> Output Class Initialized
INFO - 2024-08-09 10:19:59 --> Security Class Initialized
DEBUG - 2024-08-09 10:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:20:00 --> Input Class Initialized
INFO - 2024-08-09 10:20:00 --> Language Class Initialized
INFO - 2024-08-09 10:20:00 --> Loader Class Initialized
INFO - 2024-08-09 10:20:00 --> Helper loaded: url_helper
INFO - 2024-08-09 10:20:00 --> Helper loaded: form_helper
INFO - 2024-08-09 10:20:00 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:20:00 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:20:00 --> Email Class Initialized
INFO - 2024-08-09 10:20:00 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:20:00 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:20:00 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:20:00 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:20:00 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:20:00 --> Controller Class Initialized
INFO - 2024-08-09 10:20:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:20:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:20:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:20:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:20:00 --> Final output sent to browser
DEBUG - 2024-08-09 10:20:00 --> Total execution time: 0.1564
INFO - 2024-08-09 10:21:22 --> Config Class Initialized
INFO - 2024-08-09 10:21:22 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:21:22 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:21:22 --> Utf8 Class Initialized
INFO - 2024-08-09 10:21:22 --> URI Class Initialized
INFO - 2024-08-09 10:21:22 --> Router Class Initialized
INFO - 2024-08-09 10:21:22 --> Output Class Initialized
INFO - 2024-08-09 10:21:22 --> Security Class Initialized
DEBUG - 2024-08-09 10:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:21:22 --> Input Class Initialized
INFO - 2024-08-09 10:21:22 --> Language Class Initialized
INFO - 2024-08-09 10:21:22 --> Loader Class Initialized
INFO - 2024-08-09 10:21:22 --> Helper loaded: url_helper
INFO - 2024-08-09 10:21:22 --> Helper loaded: form_helper
INFO - 2024-08-09 10:21:22 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:21:22 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:21:22 --> Email Class Initialized
INFO - 2024-08-09 10:21:22 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:21:22 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:21:22 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:21:22 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:21:22 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:21:22 --> Controller Class Initialized
INFO - 2024-08-09 10:21:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:21:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:21:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:21:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:21:22 --> Final output sent to browser
DEBUG - 2024-08-09 10:21:22 --> Total execution time: 0.1274
INFO - 2024-08-09 10:21:22 --> Config Class Initialized
INFO - 2024-08-09 10:21:22 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:21:22 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:21:22 --> Utf8 Class Initialized
INFO - 2024-08-09 10:21:22 --> URI Class Initialized
INFO - 2024-08-09 10:21:22 --> Router Class Initialized
INFO - 2024-08-09 10:21:22 --> Output Class Initialized
INFO - 2024-08-09 10:21:22 --> Security Class Initialized
INFO - 2024-08-09 10:21:22 --> Config Class Initialized
INFO - 2024-08-09 10:21:22 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:21:22 --> Input Class Initialized
INFO - 2024-08-09 10:21:22 --> Language Class Initialized
DEBUG - 2024-08-09 10:21:22 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:21:22 --> Utf8 Class Initialized
INFO - 2024-08-09 10:21:22 --> Loader Class Initialized
INFO - 2024-08-09 10:21:22 --> Helper loaded: url_helper
INFO - 2024-08-09 10:21:22 --> Helper loaded: form_helper
INFO - 2024-08-09 10:21:22 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:21:22 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:21:22 --> Email Class Initialized
INFO - 2024-08-09 10:21:22 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:21:22 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:21:22 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:21:22 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:21:22 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:21:22 --> Controller Class Initialized
INFO - 2024-08-09 10:21:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:21:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:21:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:21:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:21:22 --> Final output sent to browser
DEBUG - 2024-08-09 10:21:22 --> Total execution time: 0.1118
INFO - 2024-08-09 10:21:32 --> Config Class Initialized
INFO - 2024-08-09 10:21:32 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:21:32 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:21:32 --> Utf8 Class Initialized
INFO - 2024-08-09 10:21:32 --> URI Class Initialized
INFO - 2024-08-09 10:21:32 --> Router Class Initialized
INFO - 2024-08-09 10:21:32 --> Output Class Initialized
INFO - 2024-08-09 10:21:32 --> Security Class Initialized
DEBUG - 2024-08-09 10:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:21:32 --> Input Class Initialized
INFO - 2024-08-09 10:21:32 --> Language Class Initialized
INFO - 2024-08-09 10:21:32 --> Loader Class Initialized
INFO - 2024-08-09 10:21:32 --> Helper loaded: url_helper
INFO - 2024-08-09 10:21:32 --> Helper loaded: form_helper
INFO - 2024-08-09 10:21:32 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:21:32 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:21:32 --> Email Class Initialized
INFO - 2024-08-09 10:21:32 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:21:32 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:21:32 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:21:32 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:21:32 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:21:32 --> Controller Class Initialized
INFO - 2024-08-09 10:21:32 --> Config Class Initialized
INFO - 2024-08-09 10:21:32 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:21:32 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:21:32 --> Utf8 Class Initialized
INFO - 2024-08-09 10:21:32 --> URI Class Initialized
INFO - 2024-08-09 10:21:32 --> Router Class Initialized
INFO - 2024-08-09 10:21:32 --> Output Class Initialized
INFO - 2024-08-09 10:21:32 --> Security Class Initialized
DEBUG - 2024-08-09 10:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:21:32 --> Input Class Initialized
INFO - 2024-08-09 10:21:32 --> Language Class Initialized
INFO - 2024-08-09 10:21:32 --> Loader Class Initialized
INFO - 2024-08-09 10:21:32 --> Helper loaded: url_helper
INFO - 2024-08-09 10:21:32 --> Helper loaded: form_helper
INFO - 2024-08-09 10:21:32 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:21:32 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:21:32 --> Email Class Initialized
INFO - 2024-08-09 10:21:32 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:21:32 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:21:32 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:21:32 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:21:32 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:21:32 --> Controller Class Initialized
INFO - 2024-08-09 10:21:32 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:21:32 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:21:32 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:21:32 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:21:32 --> Final output sent to browser
DEBUG - 2024-08-09 10:21:32 --> Total execution time: 0.0901
INFO - 2024-08-09 10:21:33 --> Config Class Initialized
INFO - 2024-08-09 10:21:33 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:21:33 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:21:33 --> Utf8 Class Initialized
INFO - 2024-08-09 10:21:33 --> URI Class Initialized
INFO - 2024-08-09 10:21:33 --> Config Class Initialized
INFO - 2024-08-09 10:21:33 --> Hooks Class Initialized
INFO - 2024-08-09 10:21:33 --> Router Class Initialized
INFO - 2024-08-09 10:21:33 --> Output Class Initialized
DEBUG - 2024-08-09 10:21:33 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:21:33 --> Utf8 Class Initialized
INFO - 2024-08-09 10:21:33 --> Security Class Initialized
DEBUG - 2024-08-09 10:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:21:33 --> Input Class Initialized
INFO - 2024-08-09 10:21:33 --> Language Class Initialized
INFO - 2024-08-09 10:21:33 --> Loader Class Initialized
INFO - 2024-08-09 10:21:33 --> Helper loaded: url_helper
INFO - 2024-08-09 10:21:33 --> Helper loaded: form_helper
INFO - 2024-08-09 10:21:33 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:21:33 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:21:33 --> Email Class Initialized
INFO - 2024-08-09 10:21:33 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:21:33 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:21:33 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:21:33 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:21:33 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:21:33 --> Controller Class Initialized
INFO - 2024-08-09 10:21:33 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:21:33 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:21:33 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:21:33 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:21:33 --> Final output sent to browser
DEBUG - 2024-08-09 10:21:33 --> Total execution time: 0.1164
INFO - 2024-08-09 10:23:26 --> Config Class Initialized
INFO - 2024-08-09 10:23:26 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:23:26 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:23:26 --> Utf8 Class Initialized
INFO - 2024-08-09 10:23:26 --> URI Class Initialized
INFO - 2024-08-09 10:23:26 --> Router Class Initialized
INFO - 2024-08-09 10:23:26 --> Output Class Initialized
INFO - 2024-08-09 10:23:26 --> Security Class Initialized
DEBUG - 2024-08-09 10:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:23:26 --> Input Class Initialized
INFO - 2024-08-09 10:23:26 --> Language Class Initialized
INFO - 2024-08-09 10:23:26 --> Loader Class Initialized
INFO - 2024-08-09 10:23:26 --> Helper loaded: url_helper
INFO - 2024-08-09 10:23:26 --> Helper loaded: form_helper
INFO - 2024-08-09 10:23:26 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:23:26 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:23:26 --> Email Class Initialized
INFO - 2024-08-09 10:23:26 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:23:26 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:23:26 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:23:26 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:23:26 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:23:26 --> Controller Class Initialized
INFO - 2024-08-09 10:23:26 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:23:26 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:23:26 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:23:26 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:23:26 --> Final output sent to browser
DEBUG - 2024-08-09 10:23:26 --> Total execution time: 0.1414
INFO - 2024-08-09 10:23:27 --> Config Class Initialized
INFO - 2024-08-09 10:23:27 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:23:27 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:23:27 --> Utf8 Class Initialized
INFO - 2024-08-09 10:23:27 --> URI Class Initialized
INFO - 2024-08-09 10:23:27 --> Router Class Initialized
INFO - 2024-08-09 10:23:27 --> Config Class Initialized
INFO - 2024-08-09 10:23:27 --> Hooks Class Initialized
INFO - 2024-08-09 10:23:27 --> Output Class Initialized
INFO - 2024-08-09 10:23:27 --> Security Class Initialized
DEBUG - 2024-08-09 10:23:27 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:23:27 --> Utf8 Class Initialized
DEBUG - 2024-08-09 10:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:23:27 --> Input Class Initialized
INFO - 2024-08-09 10:23:27 --> Language Class Initialized
INFO - 2024-08-09 10:23:27 --> Loader Class Initialized
INFO - 2024-08-09 10:23:27 --> Helper loaded: url_helper
INFO - 2024-08-09 10:23:27 --> Helper loaded: form_helper
INFO - 2024-08-09 10:23:27 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:23:27 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:23:27 --> Email Class Initialized
INFO - 2024-08-09 10:23:27 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:23:27 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:23:27 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:23:27 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:23:27 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:23:27 --> Controller Class Initialized
INFO - 2024-08-09 10:23:27 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:23:27 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:23:27 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:23:27 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:23:27 --> Final output sent to browser
DEBUG - 2024-08-09 10:23:27 --> Total execution time: 0.1150
INFO - 2024-08-09 10:23:30 --> Config Class Initialized
INFO - 2024-08-09 10:23:30 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:23:30 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:23:30 --> Utf8 Class Initialized
INFO - 2024-08-09 10:23:30 --> URI Class Initialized
INFO - 2024-08-09 10:23:30 --> Router Class Initialized
INFO - 2024-08-09 10:23:30 --> Output Class Initialized
INFO - 2024-08-09 10:23:30 --> Security Class Initialized
DEBUG - 2024-08-09 10:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:23:30 --> Input Class Initialized
INFO - 2024-08-09 10:23:30 --> Language Class Initialized
INFO - 2024-08-09 10:23:30 --> Loader Class Initialized
INFO - 2024-08-09 10:23:30 --> Helper loaded: url_helper
INFO - 2024-08-09 10:23:30 --> Helper loaded: form_helper
INFO - 2024-08-09 10:23:30 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:23:30 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:23:30 --> Email Class Initialized
INFO - 2024-08-09 10:23:30 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:23:30 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:23:30 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:23:30 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:23:30 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:23:30 --> Controller Class Initialized
INFO - 2024-08-09 10:23:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:23:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:23:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:23:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:23:30 --> Final output sent to browser
DEBUG - 2024-08-09 10:23:30 --> Total execution time: 0.1044
INFO - 2024-08-09 10:23:30 --> Config Class Initialized
INFO - 2024-08-09 10:23:30 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:23:30 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:23:30 --> Utf8 Class Initialized
INFO - 2024-08-09 10:23:30 --> URI Class Initialized
INFO - 2024-08-09 10:23:30 --> Config Class Initialized
INFO - 2024-08-09 10:23:30 --> Hooks Class Initialized
INFO - 2024-08-09 10:23:30 --> Router Class Initialized
INFO - 2024-08-09 10:23:30 --> Output Class Initialized
INFO - 2024-08-09 10:23:30 --> Security Class Initialized
DEBUG - 2024-08-09 10:23:30 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 10:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:23:30 --> Utf8 Class Initialized
INFO - 2024-08-09 10:23:30 --> Input Class Initialized
INFO - 2024-08-09 10:23:30 --> Language Class Initialized
INFO - 2024-08-09 10:23:30 --> Loader Class Initialized
INFO - 2024-08-09 10:23:30 --> Helper loaded: url_helper
INFO - 2024-08-09 10:23:30 --> Helper loaded: form_helper
INFO - 2024-08-09 10:23:30 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:23:30 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:23:30 --> Email Class Initialized
INFO - 2024-08-09 10:23:30 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:23:30 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:23:30 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:23:30 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:23:30 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:23:30 --> Controller Class Initialized
INFO - 2024-08-09 10:23:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:23:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:23:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:23:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:23:30 --> Final output sent to browser
DEBUG - 2024-08-09 10:23:30 --> Total execution time: 0.1193
INFO - 2024-08-09 10:23:34 --> Config Class Initialized
INFO - 2024-08-09 10:23:34 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:23:34 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:23:34 --> Utf8 Class Initialized
INFO - 2024-08-09 10:23:34 --> URI Class Initialized
INFO - 2024-08-09 10:23:34 --> Router Class Initialized
INFO - 2024-08-09 10:23:34 --> Output Class Initialized
INFO - 2024-08-09 10:23:34 --> Security Class Initialized
DEBUG - 2024-08-09 10:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:23:34 --> Input Class Initialized
INFO - 2024-08-09 10:23:34 --> Language Class Initialized
INFO - 2024-08-09 10:23:34 --> Loader Class Initialized
INFO - 2024-08-09 10:23:34 --> Helper loaded: url_helper
INFO - 2024-08-09 10:23:34 --> Helper loaded: form_helper
INFO - 2024-08-09 10:23:34 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:23:34 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:23:34 --> Email Class Initialized
INFO - 2024-08-09 10:23:34 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:23:34 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:23:34 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:23:34 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:23:34 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:23:34 --> Controller Class Initialized
INFO - 2024-08-09 10:23:34 --> Config Class Initialized
INFO - 2024-08-09 10:23:34 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:23:34 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:23:34 --> Utf8 Class Initialized
INFO - 2024-08-09 10:23:34 --> URI Class Initialized
INFO - 2024-08-09 10:23:34 --> Router Class Initialized
INFO - 2024-08-09 10:23:34 --> Output Class Initialized
INFO - 2024-08-09 10:23:34 --> Security Class Initialized
DEBUG - 2024-08-09 10:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:23:34 --> Input Class Initialized
INFO - 2024-08-09 10:23:34 --> Language Class Initialized
INFO - 2024-08-09 10:23:34 --> Loader Class Initialized
INFO - 2024-08-09 10:23:34 --> Helper loaded: url_helper
INFO - 2024-08-09 10:23:34 --> Helper loaded: form_helper
INFO - 2024-08-09 10:23:34 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:23:34 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:23:34 --> Email Class Initialized
INFO - 2024-08-09 10:23:34 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:23:35 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:23:35 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:23:35 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:23:35 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:23:35 --> Controller Class Initialized
INFO - 2024-08-09 10:23:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:23:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:23:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:23:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:23:35 --> Final output sent to browser
DEBUG - 2024-08-09 10:23:35 --> Total execution time: 0.0869
INFO - 2024-08-09 10:23:35 --> Config Class Initialized
INFO - 2024-08-09 10:23:35 --> Hooks Class Initialized
INFO - 2024-08-09 10:23:35 --> Config Class Initialized
INFO - 2024-08-09 10:23:35 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:23:35 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:23:35 --> Utf8 Class Initialized
INFO - 2024-08-09 10:23:35 --> URI Class Initialized
DEBUG - 2024-08-09 10:23:35 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:23:35 --> Utf8 Class Initialized
INFO - 2024-08-09 10:23:35 --> Router Class Initialized
INFO - 2024-08-09 10:23:35 --> Output Class Initialized
INFO - 2024-08-09 10:23:35 --> Security Class Initialized
DEBUG - 2024-08-09 10:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:23:35 --> Input Class Initialized
INFO - 2024-08-09 10:23:35 --> Language Class Initialized
INFO - 2024-08-09 10:23:35 --> Loader Class Initialized
INFO - 2024-08-09 10:23:35 --> Helper loaded: url_helper
INFO - 2024-08-09 10:23:35 --> Helper loaded: form_helper
INFO - 2024-08-09 10:23:35 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:23:35 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:23:35 --> Email Class Initialized
INFO - 2024-08-09 10:23:35 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:23:35 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:23:35 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:23:35 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:23:35 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:23:35 --> Controller Class Initialized
INFO - 2024-08-09 10:23:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:23:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:23:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:23:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:23:35 --> Final output sent to browser
DEBUG - 2024-08-09 10:23:35 --> Total execution time: 0.1115
INFO - 2024-08-09 10:28:04 --> Config Class Initialized
INFO - 2024-08-09 10:28:04 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:28:04 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:28:04 --> Utf8 Class Initialized
INFO - 2024-08-09 10:28:04 --> URI Class Initialized
INFO - 2024-08-09 10:28:04 --> Router Class Initialized
INFO - 2024-08-09 10:28:04 --> Output Class Initialized
INFO - 2024-08-09 10:28:04 --> Security Class Initialized
DEBUG - 2024-08-09 10:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:28:04 --> Input Class Initialized
INFO - 2024-08-09 10:28:04 --> Language Class Initialized
INFO - 2024-08-09 10:28:04 --> Loader Class Initialized
INFO - 2024-08-09 10:28:04 --> Helper loaded: url_helper
INFO - 2024-08-09 10:28:04 --> Helper loaded: form_helper
INFO - 2024-08-09 10:28:04 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:28:04 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:28:04 --> Email Class Initialized
INFO - 2024-08-09 10:28:04 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:28:04 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:28:04 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:28:04 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:28:04 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:28:04 --> Controller Class Initialized
INFO - 2024-08-09 10:28:04 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:28:04 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:28:04 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:28:04 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:28:04 --> Final output sent to browser
DEBUG - 2024-08-09 10:28:04 --> Total execution time: 0.1753
INFO - 2024-08-09 10:28:04 --> Config Class Initialized
INFO - 2024-08-09 10:28:04 --> Hooks Class Initialized
INFO - 2024-08-09 10:28:04 --> Config Class Initialized
INFO - 2024-08-09 10:28:04 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:28:04 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:28:04 --> Utf8 Class Initialized
DEBUG - 2024-08-09 10:28:04 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:28:04 --> Utf8 Class Initialized
INFO - 2024-08-09 10:28:04 --> URI Class Initialized
INFO - 2024-08-09 10:28:04 --> Router Class Initialized
INFO - 2024-08-09 10:28:04 --> Output Class Initialized
INFO - 2024-08-09 10:28:04 --> Security Class Initialized
DEBUG - 2024-08-09 10:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:28:04 --> Input Class Initialized
INFO - 2024-08-09 10:28:04 --> Language Class Initialized
INFO - 2024-08-09 10:28:04 --> Loader Class Initialized
INFO - 2024-08-09 10:28:04 --> Helper loaded: url_helper
INFO - 2024-08-09 10:28:04 --> Helper loaded: form_helper
INFO - 2024-08-09 10:28:04 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:28:04 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:28:04 --> Email Class Initialized
INFO - 2024-08-09 10:28:04 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:28:04 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:28:04 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:28:04 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:28:04 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:28:04 --> Controller Class Initialized
INFO - 2024-08-09 10:28:04 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:28:04 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:28:04 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:28:04 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:28:04 --> Final output sent to browser
DEBUG - 2024-08-09 10:28:04 --> Total execution time: 0.1668
INFO - 2024-08-09 10:28:07 --> Config Class Initialized
INFO - 2024-08-09 10:28:07 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:28:07 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:28:07 --> Utf8 Class Initialized
INFO - 2024-08-09 10:28:07 --> URI Class Initialized
INFO - 2024-08-09 10:28:07 --> Router Class Initialized
INFO - 2024-08-09 10:28:07 --> Output Class Initialized
INFO - 2024-08-09 10:28:07 --> Security Class Initialized
DEBUG - 2024-08-09 10:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:28:07 --> Input Class Initialized
INFO - 2024-08-09 10:28:07 --> Language Class Initialized
INFO - 2024-08-09 10:28:07 --> Loader Class Initialized
INFO - 2024-08-09 10:28:07 --> Helper loaded: url_helper
INFO - 2024-08-09 10:28:07 --> Helper loaded: form_helper
INFO - 2024-08-09 10:28:07 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:28:07 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:28:07 --> Email Class Initialized
INFO - 2024-08-09 10:28:07 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:28:07 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:28:07 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:28:07 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:28:07 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:28:07 --> Controller Class Initialized
INFO - 2024-08-09 10:28:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:28:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:28:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:28:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:28:07 --> Final output sent to browser
DEBUG - 2024-08-09 10:28:07 --> Total execution time: 0.1137
INFO - 2024-08-09 10:28:07 --> Config Class Initialized
INFO - 2024-08-09 10:28:07 --> Config Class Initialized
INFO - 2024-08-09 10:28:07 --> Hooks Class Initialized
INFO - 2024-08-09 10:28:07 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:28:07 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:28:07 --> Utf8 Class Initialized
DEBUG - 2024-08-09 10:28:07 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:28:07 --> Utf8 Class Initialized
INFO - 2024-08-09 10:28:07 --> URI Class Initialized
INFO - 2024-08-09 10:28:07 --> Router Class Initialized
INFO - 2024-08-09 10:28:07 --> Output Class Initialized
INFO - 2024-08-09 10:28:07 --> Security Class Initialized
DEBUG - 2024-08-09 10:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:28:07 --> Input Class Initialized
INFO - 2024-08-09 10:28:07 --> Language Class Initialized
INFO - 2024-08-09 10:28:07 --> Loader Class Initialized
INFO - 2024-08-09 10:28:07 --> Helper loaded: url_helper
INFO - 2024-08-09 10:28:07 --> Helper loaded: form_helper
INFO - 2024-08-09 10:28:07 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:28:07 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:28:07 --> Email Class Initialized
INFO - 2024-08-09 10:28:07 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:28:07 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:28:07 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:28:07 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:28:07 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:28:07 --> Controller Class Initialized
INFO - 2024-08-09 10:28:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:28:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:28:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:28:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:28:07 --> Final output sent to browser
DEBUG - 2024-08-09 10:28:07 --> Total execution time: 0.1334
INFO - 2024-08-09 10:29:29 --> Config Class Initialized
INFO - 2024-08-09 10:29:29 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:29:29 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:29:29 --> Utf8 Class Initialized
INFO - 2024-08-09 10:29:29 --> URI Class Initialized
INFO - 2024-08-09 10:29:29 --> Router Class Initialized
INFO - 2024-08-09 10:29:29 --> Output Class Initialized
INFO - 2024-08-09 10:29:29 --> Security Class Initialized
DEBUG - 2024-08-09 10:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:29:29 --> Input Class Initialized
INFO - 2024-08-09 10:29:29 --> Language Class Initialized
INFO - 2024-08-09 10:29:29 --> Loader Class Initialized
INFO - 2024-08-09 10:29:29 --> Helper loaded: url_helper
INFO - 2024-08-09 10:29:29 --> Helper loaded: form_helper
INFO - 2024-08-09 10:29:29 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:29:29 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:29:29 --> Email Class Initialized
INFO - 2024-08-09 10:29:29 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:29:29 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:29:29 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:29:29 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:29:29 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:29:29 --> Controller Class Initialized
INFO - 2024-08-09 10:29:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:29:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:29:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:29:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:29:29 --> Final output sent to browser
DEBUG - 2024-08-09 10:29:29 --> Total execution time: 0.1763
INFO - 2024-08-09 10:29:30 --> Config Class Initialized
INFO - 2024-08-09 10:29:30 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:29:30 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:29:30 --> Utf8 Class Initialized
INFO - 2024-08-09 10:29:30 --> URI Class Initialized
INFO - 2024-08-09 10:29:30 --> Router Class Initialized
INFO - 2024-08-09 10:29:30 --> Output Class Initialized
INFO - 2024-08-09 10:29:30 --> Config Class Initialized
INFO - 2024-08-09 10:29:30 --> Hooks Class Initialized
INFO - 2024-08-09 10:29:30 --> Security Class Initialized
DEBUG - 2024-08-09 10:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:29:30 --> Input Class Initialized
DEBUG - 2024-08-09 10:29:30 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:29:30 --> Utf8 Class Initialized
INFO - 2024-08-09 10:29:30 --> Language Class Initialized
INFO - 2024-08-09 10:29:30 --> Loader Class Initialized
INFO - 2024-08-09 10:29:30 --> Helper loaded: url_helper
INFO - 2024-08-09 10:29:30 --> Helper loaded: form_helper
INFO - 2024-08-09 10:29:30 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:29:30 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:29:30 --> Email Class Initialized
INFO - 2024-08-09 10:29:30 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:29:30 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:29:30 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:29:30 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:29:30 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:29:30 --> Controller Class Initialized
INFO - 2024-08-09 10:29:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:29:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:29:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:29:30 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:29:30 --> Final output sent to browser
DEBUG - 2024-08-09 10:29:30 --> Total execution time: 0.2240
INFO - 2024-08-09 10:29:36 --> Config Class Initialized
INFO - 2024-08-09 10:29:36 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:29:36 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:29:36 --> Utf8 Class Initialized
INFO - 2024-08-09 10:29:36 --> URI Class Initialized
INFO - 2024-08-09 10:29:36 --> Router Class Initialized
INFO - 2024-08-09 10:29:36 --> Output Class Initialized
INFO - 2024-08-09 10:29:36 --> Security Class Initialized
DEBUG - 2024-08-09 10:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:29:36 --> Input Class Initialized
INFO - 2024-08-09 10:29:36 --> Language Class Initialized
INFO - 2024-08-09 10:29:36 --> Loader Class Initialized
INFO - 2024-08-09 10:29:36 --> Helper loaded: url_helper
INFO - 2024-08-09 10:29:36 --> Helper loaded: form_helper
INFO - 2024-08-09 10:29:36 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:29:36 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:29:36 --> Email Class Initialized
INFO - 2024-08-09 10:29:36 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:29:36 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:29:36 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:29:36 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:29:36 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:29:36 --> Controller Class Initialized
INFO - 2024-08-09 10:29:36 --> Config Class Initialized
INFO - 2024-08-09 10:29:36 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:29:36 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:29:36 --> Utf8 Class Initialized
INFO - 2024-08-09 10:29:36 --> URI Class Initialized
INFO - 2024-08-09 10:29:36 --> Router Class Initialized
INFO - 2024-08-09 10:29:36 --> Output Class Initialized
INFO - 2024-08-09 10:29:36 --> Security Class Initialized
DEBUG - 2024-08-09 10:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:29:36 --> Input Class Initialized
INFO - 2024-08-09 10:29:36 --> Language Class Initialized
INFO - 2024-08-09 10:29:36 --> Loader Class Initialized
INFO - 2024-08-09 10:29:36 --> Helper loaded: url_helper
INFO - 2024-08-09 10:29:36 --> Helper loaded: form_helper
INFO - 2024-08-09 10:29:36 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:29:36 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:29:36 --> Email Class Initialized
INFO - 2024-08-09 10:29:36 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:29:36 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:29:36 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:29:36 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:29:36 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:29:36 --> Controller Class Initialized
INFO - 2024-08-09 10:29:36 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:29:36 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:29:36 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:29:36 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:29:36 --> Final output sent to browser
DEBUG - 2024-08-09 10:29:36 --> Total execution time: 0.0942
INFO - 2024-08-09 10:29:36 --> Config Class Initialized
INFO - 2024-08-09 10:29:36 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:29:36 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:29:36 --> Config Class Initialized
INFO - 2024-08-09 10:29:36 --> Utf8 Class Initialized
INFO - 2024-08-09 10:29:36 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:29:36 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:29:36 --> Utf8 Class Initialized
INFO - 2024-08-09 10:29:36 --> URI Class Initialized
INFO - 2024-08-09 10:29:36 --> Router Class Initialized
INFO - 2024-08-09 10:29:36 --> Output Class Initialized
INFO - 2024-08-09 10:29:36 --> Security Class Initialized
DEBUG - 2024-08-09 10:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:29:36 --> Input Class Initialized
INFO - 2024-08-09 10:29:36 --> Language Class Initialized
INFO - 2024-08-09 10:29:36 --> Loader Class Initialized
INFO - 2024-08-09 10:29:36 --> Helper loaded: url_helper
INFO - 2024-08-09 10:29:36 --> Helper loaded: form_helper
INFO - 2024-08-09 10:29:36 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:29:36 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:29:36 --> Email Class Initialized
INFO - 2024-08-09 10:29:36 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:29:36 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:29:36 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:29:36 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:29:36 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:29:36 --> Controller Class Initialized
INFO - 2024-08-09 10:29:36 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:29:36 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:29:36 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:29:36 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:29:36 --> Final output sent to browser
DEBUG - 2024-08-09 10:29:36 --> Total execution time: 0.1259
INFO - 2024-08-09 10:31:54 --> Config Class Initialized
INFO - 2024-08-09 10:31:54 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:31:54 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:31:54 --> Utf8 Class Initialized
INFO - 2024-08-09 10:31:54 --> URI Class Initialized
INFO - 2024-08-09 10:31:54 --> Router Class Initialized
INFO - 2024-08-09 10:31:54 --> Output Class Initialized
INFO - 2024-08-09 10:31:54 --> Security Class Initialized
DEBUG - 2024-08-09 10:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:31:54 --> Input Class Initialized
INFO - 2024-08-09 10:31:54 --> Language Class Initialized
INFO - 2024-08-09 10:31:54 --> Loader Class Initialized
INFO - 2024-08-09 10:31:54 --> Helper loaded: url_helper
INFO - 2024-08-09 10:31:54 --> Helper loaded: form_helper
INFO - 2024-08-09 10:31:54 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:31:54 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:31:54 --> Email Class Initialized
INFO - 2024-08-09 10:31:54 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:31:54 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:31:54 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:31:54 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:31:54 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:31:54 --> Controller Class Initialized
INFO - 2024-08-09 10:31:54 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:31:54 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:31:54 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:31:54 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:31:54 --> Final output sent to browser
DEBUG - 2024-08-09 10:31:54 --> Total execution time: 0.1317
INFO - 2024-08-09 10:31:55 --> Config Class Initialized
INFO - 2024-08-09 10:31:55 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:31:55 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:31:55 --> Utf8 Class Initialized
INFO - 2024-08-09 10:31:55 --> URI Class Initialized
INFO - 2024-08-09 10:31:55 --> Router Class Initialized
INFO - 2024-08-09 10:31:55 --> Config Class Initialized
INFO - 2024-08-09 10:31:55 --> Output Class Initialized
INFO - 2024-08-09 10:31:55 --> Hooks Class Initialized
INFO - 2024-08-09 10:31:55 --> Security Class Initialized
DEBUG - 2024-08-09 10:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:31:55 --> Input Class Initialized
DEBUG - 2024-08-09 10:31:55 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:31:55 --> Language Class Initialized
INFO - 2024-08-09 10:31:55 --> Utf8 Class Initialized
INFO - 2024-08-09 10:31:55 --> Loader Class Initialized
INFO - 2024-08-09 10:31:55 --> Helper loaded: url_helper
INFO - 2024-08-09 10:31:55 --> Helper loaded: form_helper
INFO - 2024-08-09 10:31:55 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:31:55 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:31:55 --> Email Class Initialized
INFO - 2024-08-09 10:31:55 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:31:55 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:31:55 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:31:55 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:31:55 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:31:55 --> Controller Class Initialized
INFO - 2024-08-09 10:31:55 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:31:55 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:31:55 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:31:55 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:31:55 --> Final output sent to browser
DEBUG - 2024-08-09 10:31:55 --> Total execution time: 0.1114
INFO - 2024-08-09 10:31:57 --> Config Class Initialized
INFO - 2024-08-09 10:31:57 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:31:57 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:31:57 --> Utf8 Class Initialized
INFO - 2024-08-09 10:31:57 --> URI Class Initialized
INFO - 2024-08-09 10:31:57 --> Router Class Initialized
INFO - 2024-08-09 10:31:57 --> Output Class Initialized
INFO - 2024-08-09 10:31:57 --> Security Class Initialized
DEBUG - 2024-08-09 10:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:31:57 --> Input Class Initialized
INFO - 2024-08-09 10:31:57 --> Language Class Initialized
INFO - 2024-08-09 10:31:57 --> Loader Class Initialized
INFO - 2024-08-09 10:31:57 --> Helper loaded: url_helper
INFO - 2024-08-09 10:31:57 --> Helper loaded: form_helper
INFO - 2024-08-09 10:31:57 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:31:57 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:31:57 --> Email Class Initialized
INFO - 2024-08-09 10:31:57 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:31:57 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:31:57 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:31:57 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:31:57 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:31:57 --> Controller Class Initialized
INFO - 2024-08-09 10:31:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:31:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:31:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:31:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:31:57 --> Final output sent to browser
DEBUG - 2024-08-09 10:31:57 --> Total execution time: 0.1341
INFO - 2024-08-09 10:31:58 --> Config Class Initialized
INFO - 2024-08-09 10:31:58 --> Config Class Initialized
INFO - 2024-08-09 10:31:58 --> Hooks Class Initialized
INFO - 2024-08-09 10:31:58 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:31:58 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 10:31:58 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:31:58 --> Utf8 Class Initialized
INFO - 2024-08-09 10:31:58 --> Utf8 Class Initialized
INFO - 2024-08-09 10:31:58 --> URI Class Initialized
INFO - 2024-08-09 10:31:58 --> Router Class Initialized
INFO - 2024-08-09 10:31:58 --> Output Class Initialized
INFO - 2024-08-09 10:31:58 --> Security Class Initialized
DEBUG - 2024-08-09 10:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:31:58 --> Input Class Initialized
INFO - 2024-08-09 10:31:58 --> Language Class Initialized
INFO - 2024-08-09 10:31:58 --> Loader Class Initialized
INFO - 2024-08-09 10:31:58 --> Helper loaded: url_helper
INFO - 2024-08-09 10:31:58 --> Helper loaded: form_helper
INFO - 2024-08-09 10:31:58 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:31:58 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:31:58 --> Email Class Initialized
INFO - 2024-08-09 10:31:58 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:31:58 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:31:58 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:31:58 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:31:58 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:31:58 --> Controller Class Initialized
INFO - 2024-08-09 10:31:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:31:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:31:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:31:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:31:58 --> Final output sent to browser
DEBUG - 2024-08-09 10:31:58 --> Total execution time: 0.1286
INFO - 2024-08-09 10:32:00 --> Config Class Initialized
INFO - 2024-08-09 10:32:00 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:32:00 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:00 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:00 --> URI Class Initialized
INFO - 2024-08-09 10:32:00 --> Router Class Initialized
INFO - 2024-08-09 10:32:00 --> Output Class Initialized
INFO - 2024-08-09 10:32:00 --> Security Class Initialized
DEBUG - 2024-08-09 10:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:32:00 --> Input Class Initialized
INFO - 2024-08-09 10:32:00 --> Language Class Initialized
INFO - 2024-08-09 10:32:00 --> Loader Class Initialized
INFO - 2024-08-09 10:32:00 --> Helper loaded: url_helper
INFO - 2024-08-09 10:32:00 --> Helper loaded: form_helper
INFO - 2024-08-09 10:32:00 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:32:00 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:32:00 --> Email Class Initialized
INFO - 2024-08-09 10:32:00 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:32:00 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:32:00 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:32:00 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:32:00 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:32:00 --> Controller Class Initialized
INFO - 2024-08-09 10:32:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:32:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:32:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:32:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:32:00 --> Final output sent to browser
DEBUG - 2024-08-09 10:32:00 --> Total execution time: 0.0933
INFO - 2024-08-09 10:32:01 --> Config Class Initialized
INFO - 2024-08-09 10:32:01 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:32:01 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:01 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:01 --> URI Class Initialized
INFO - 2024-08-09 10:32:01 --> Config Class Initialized
INFO - 2024-08-09 10:32:01 --> Hooks Class Initialized
INFO - 2024-08-09 10:32:01 --> Router Class Initialized
DEBUG - 2024-08-09 10:32:01 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:01 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:01 --> Output Class Initialized
INFO - 2024-08-09 10:32:01 --> Security Class Initialized
DEBUG - 2024-08-09 10:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:32:01 --> Input Class Initialized
INFO - 2024-08-09 10:32:01 --> Language Class Initialized
INFO - 2024-08-09 10:32:01 --> Loader Class Initialized
INFO - 2024-08-09 10:32:01 --> Helper loaded: url_helper
INFO - 2024-08-09 10:32:01 --> Helper loaded: form_helper
INFO - 2024-08-09 10:32:01 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:32:01 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:32:01 --> Email Class Initialized
INFO - 2024-08-09 10:32:01 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:32:01 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:32:01 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:32:01 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:32:01 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:32:01 --> Controller Class Initialized
INFO - 2024-08-09 10:32:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:32:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:32:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:32:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:32:01 --> Final output sent to browser
DEBUG - 2024-08-09 10:32:01 --> Total execution time: 0.1325
INFO - 2024-08-09 10:32:02 --> Config Class Initialized
INFO - 2024-08-09 10:32:02 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:32:02 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:02 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:02 --> URI Class Initialized
INFO - 2024-08-09 10:32:02 --> Router Class Initialized
INFO - 2024-08-09 10:32:03 --> Output Class Initialized
INFO - 2024-08-09 10:32:03 --> Security Class Initialized
DEBUG - 2024-08-09 10:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:32:03 --> Input Class Initialized
INFO - 2024-08-09 10:32:03 --> Language Class Initialized
INFO - 2024-08-09 10:32:03 --> Loader Class Initialized
INFO - 2024-08-09 10:32:03 --> Helper loaded: url_helper
INFO - 2024-08-09 10:32:03 --> Helper loaded: form_helper
INFO - 2024-08-09 10:32:03 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:32:03 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:32:03 --> Email Class Initialized
INFO - 2024-08-09 10:32:03 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:32:03 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:32:03 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:32:03 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:32:03 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:32:03 --> Controller Class Initialized
INFO - 2024-08-09 10:32:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:32:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:32:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:32:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:32:03 --> Final output sent to browser
DEBUG - 2024-08-09 10:32:03 --> Total execution time: 0.1204
INFO - 2024-08-09 10:32:03 --> Config Class Initialized
INFO - 2024-08-09 10:32:03 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:32:03 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:03 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:03 --> Config Class Initialized
INFO - 2024-08-09 10:32:03 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:32:03 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:03 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:03 --> URI Class Initialized
INFO - 2024-08-09 10:32:03 --> Router Class Initialized
INFO - 2024-08-09 10:32:03 --> Output Class Initialized
INFO - 2024-08-09 10:32:03 --> Security Class Initialized
DEBUG - 2024-08-09 10:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:32:03 --> Input Class Initialized
INFO - 2024-08-09 10:32:03 --> Language Class Initialized
INFO - 2024-08-09 10:32:03 --> Loader Class Initialized
INFO - 2024-08-09 10:32:03 --> Helper loaded: url_helper
INFO - 2024-08-09 10:32:03 --> Helper loaded: form_helper
INFO - 2024-08-09 10:32:03 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:32:03 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:32:03 --> Email Class Initialized
INFO - 2024-08-09 10:32:03 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:32:03 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:32:03 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:32:03 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:32:03 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:32:03 --> Controller Class Initialized
INFO - 2024-08-09 10:32:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:32:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:32:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:32:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:32:03 --> Final output sent to browser
DEBUG - 2024-08-09 10:32:03 --> Total execution time: 0.1494
INFO - 2024-08-09 10:32:06 --> Config Class Initialized
INFO - 2024-08-09 10:32:06 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:32:06 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:06 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:06 --> URI Class Initialized
INFO - 2024-08-09 10:32:06 --> Router Class Initialized
INFO - 2024-08-09 10:32:06 --> Output Class Initialized
INFO - 2024-08-09 10:32:06 --> Security Class Initialized
DEBUG - 2024-08-09 10:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:32:06 --> Input Class Initialized
INFO - 2024-08-09 10:32:06 --> Language Class Initialized
INFO - 2024-08-09 10:32:06 --> Loader Class Initialized
INFO - 2024-08-09 10:32:06 --> Helper loaded: url_helper
INFO - 2024-08-09 10:32:06 --> Helper loaded: form_helper
INFO - 2024-08-09 10:32:06 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:32:06 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:32:06 --> Email Class Initialized
INFO - 2024-08-09 10:32:06 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:32:06 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:32:06 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:32:06 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:32:06 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:32:06 --> Controller Class Initialized
INFO - 2024-08-09 10:32:06 --> Config Class Initialized
INFO - 2024-08-09 10:32:06 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:32:06 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:06 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:06 --> URI Class Initialized
INFO - 2024-08-09 10:32:06 --> Router Class Initialized
INFO - 2024-08-09 10:32:06 --> Output Class Initialized
INFO - 2024-08-09 10:32:06 --> Security Class Initialized
DEBUG - 2024-08-09 10:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:32:06 --> Input Class Initialized
INFO - 2024-08-09 10:32:06 --> Language Class Initialized
INFO - 2024-08-09 10:32:06 --> Loader Class Initialized
INFO - 2024-08-09 10:32:06 --> Helper loaded: url_helper
INFO - 2024-08-09 10:32:06 --> Helper loaded: form_helper
INFO - 2024-08-09 10:32:06 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:32:06 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:32:06 --> Email Class Initialized
INFO - 2024-08-09 10:32:06 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:32:06 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:32:06 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:32:06 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:32:06 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:32:06 --> Controller Class Initialized
INFO - 2024-08-09 10:32:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:32:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:32:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:32:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:32:06 --> Final output sent to browser
DEBUG - 2024-08-09 10:32:06 --> Total execution time: 0.1107
INFO - 2024-08-09 10:32:07 --> Config Class Initialized
INFO - 2024-08-09 10:32:07 --> Hooks Class Initialized
INFO - 2024-08-09 10:32:07 --> Config Class Initialized
INFO - 2024-08-09 10:32:07 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:32:07 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:07 --> Utf8 Class Initialized
DEBUG - 2024-08-09 10:32:07 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:07 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:07 --> URI Class Initialized
INFO - 2024-08-09 10:32:07 --> Router Class Initialized
INFO - 2024-08-09 10:32:07 --> Output Class Initialized
INFO - 2024-08-09 10:32:07 --> Security Class Initialized
DEBUG - 2024-08-09 10:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:32:07 --> Input Class Initialized
INFO - 2024-08-09 10:32:07 --> Language Class Initialized
INFO - 2024-08-09 10:32:07 --> Loader Class Initialized
INFO - 2024-08-09 10:32:07 --> Helper loaded: url_helper
INFO - 2024-08-09 10:32:07 --> Helper loaded: form_helper
INFO - 2024-08-09 10:32:07 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:32:07 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:32:07 --> Email Class Initialized
INFO - 2024-08-09 10:32:07 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:32:07 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:32:07 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:32:07 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:32:07 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:32:07 --> Controller Class Initialized
INFO - 2024-08-09 10:32:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:32:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:32:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:32:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:32:07 --> Final output sent to browser
DEBUG - 2024-08-09 10:32:07 --> Total execution time: 0.1180
INFO - 2024-08-09 10:32:31 --> Config Class Initialized
INFO - 2024-08-09 10:32:31 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:32:31 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:31 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:31 --> URI Class Initialized
INFO - 2024-08-09 10:32:31 --> Router Class Initialized
INFO - 2024-08-09 10:32:31 --> Output Class Initialized
INFO - 2024-08-09 10:32:31 --> Security Class Initialized
DEBUG - 2024-08-09 10:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:32:31 --> Input Class Initialized
INFO - 2024-08-09 10:32:31 --> Language Class Initialized
INFO - 2024-08-09 10:32:31 --> Loader Class Initialized
INFO - 2024-08-09 10:32:31 --> Helper loaded: url_helper
INFO - 2024-08-09 10:32:31 --> Helper loaded: form_helper
INFO - 2024-08-09 10:32:31 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:32:31 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:32:31 --> Email Class Initialized
INFO - 2024-08-09 10:32:31 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:32:31 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:32:31 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:32:31 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:32:31 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:32:31 --> Controller Class Initialized
INFO - 2024-08-09 10:32:31 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:32:31 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:32:31 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:32:31 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:32:31 --> Final output sent to browser
DEBUG - 2024-08-09 10:32:31 --> Total execution time: 0.1487
INFO - 2024-08-09 10:32:32 --> Config Class Initialized
INFO - 2024-08-09 10:32:32 --> Hooks Class Initialized
INFO - 2024-08-09 10:32:32 --> Config Class Initialized
INFO - 2024-08-09 10:32:32 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:32:32 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 10:32:32 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:32 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:32 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:32 --> URI Class Initialized
INFO - 2024-08-09 10:32:32 --> Router Class Initialized
INFO - 2024-08-09 10:32:32 --> Output Class Initialized
INFO - 2024-08-09 10:32:32 --> Security Class Initialized
DEBUG - 2024-08-09 10:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:32:32 --> Input Class Initialized
INFO - 2024-08-09 10:32:32 --> Language Class Initialized
INFO - 2024-08-09 10:32:32 --> Loader Class Initialized
INFO - 2024-08-09 10:32:32 --> Helper loaded: url_helper
INFO - 2024-08-09 10:32:32 --> Helper loaded: form_helper
INFO - 2024-08-09 10:32:32 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:32:32 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:32:32 --> Email Class Initialized
INFO - 2024-08-09 10:32:32 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:32:32 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:32:32 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:32:32 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:32:32 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:32:32 --> Controller Class Initialized
INFO - 2024-08-09 10:32:32 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:32:32 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:32:32 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:32:32 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:32:32 --> Final output sent to browser
DEBUG - 2024-08-09 10:32:32 --> Total execution time: 0.1141
INFO - 2024-08-09 10:32:35 --> Config Class Initialized
INFO - 2024-08-09 10:32:35 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:32:35 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:35 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:35 --> URI Class Initialized
INFO - 2024-08-09 10:32:35 --> Router Class Initialized
INFO - 2024-08-09 10:32:35 --> Output Class Initialized
INFO - 2024-08-09 10:32:35 --> Security Class Initialized
DEBUG - 2024-08-09 10:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:32:35 --> Input Class Initialized
INFO - 2024-08-09 10:32:35 --> Language Class Initialized
INFO - 2024-08-09 10:32:35 --> Loader Class Initialized
INFO - 2024-08-09 10:32:35 --> Helper loaded: url_helper
INFO - 2024-08-09 10:32:35 --> Helper loaded: form_helper
INFO - 2024-08-09 10:32:35 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:32:35 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:32:35 --> Email Class Initialized
INFO - 2024-08-09 10:32:35 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:32:35 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:32:35 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:32:35 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:32:35 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:32:35 --> Controller Class Initialized
INFO - 2024-08-09 10:32:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:32:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:32:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:32:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:32:35 --> Final output sent to browser
DEBUG - 2024-08-09 10:32:35 --> Total execution time: 0.1067
INFO - 2024-08-09 10:32:35 --> Config Class Initialized
INFO - 2024-08-09 10:32:35 --> Config Class Initialized
INFO - 2024-08-09 10:32:35 --> Hooks Class Initialized
INFO - 2024-08-09 10:32:35 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:32:35 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 10:32:35 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:35 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:35 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:35 --> URI Class Initialized
INFO - 2024-08-09 10:32:35 --> Router Class Initialized
INFO - 2024-08-09 10:32:35 --> Output Class Initialized
INFO - 2024-08-09 10:32:35 --> Security Class Initialized
DEBUG - 2024-08-09 10:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:32:35 --> Input Class Initialized
INFO - 2024-08-09 10:32:35 --> Language Class Initialized
INFO - 2024-08-09 10:32:35 --> Loader Class Initialized
INFO - 2024-08-09 10:32:35 --> Helper loaded: url_helper
INFO - 2024-08-09 10:32:35 --> Helper loaded: form_helper
INFO - 2024-08-09 10:32:35 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:32:35 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:32:35 --> Email Class Initialized
INFO - 2024-08-09 10:32:35 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:32:35 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:32:35 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:32:35 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:32:35 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:32:35 --> Controller Class Initialized
INFO - 2024-08-09 10:32:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:32:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:32:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:32:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:32:35 --> Final output sent to browser
DEBUG - 2024-08-09 10:32:35 --> Total execution time: 0.1116
INFO - 2024-08-09 10:32:37 --> Config Class Initialized
INFO - 2024-08-09 10:32:37 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:32:37 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:37 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:37 --> URI Class Initialized
INFO - 2024-08-09 10:32:37 --> Router Class Initialized
INFO - 2024-08-09 10:32:37 --> Output Class Initialized
INFO - 2024-08-09 10:32:37 --> Security Class Initialized
DEBUG - 2024-08-09 10:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:32:37 --> Input Class Initialized
INFO - 2024-08-09 10:32:37 --> Language Class Initialized
INFO - 2024-08-09 10:32:37 --> Loader Class Initialized
INFO - 2024-08-09 10:32:37 --> Helper loaded: url_helper
INFO - 2024-08-09 10:32:37 --> Helper loaded: form_helper
INFO - 2024-08-09 10:32:37 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:32:37 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:32:37 --> Email Class Initialized
INFO - 2024-08-09 10:32:37 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:32:37 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:32:37 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:32:37 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:32:37 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:32:37 --> Controller Class Initialized
INFO - 2024-08-09 10:32:37 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:32:37 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:32:37 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:32:37 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:32:37 --> Final output sent to browser
DEBUG - 2024-08-09 10:32:37 --> Total execution time: 0.0966
INFO - 2024-08-09 10:32:38 --> Config Class Initialized
INFO - 2024-08-09 10:32:38 --> Config Class Initialized
INFO - 2024-08-09 10:32:38 --> Hooks Class Initialized
INFO - 2024-08-09 10:32:38 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:32:38 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:38 --> Utf8 Class Initialized
DEBUG - 2024-08-09 10:32:38 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:38 --> URI Class Initialized
INFO - 2024-08-09 10:32:38 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:38 --> Router Class Initialized
INFO - 2024-08-09 10:32:38 --> Output Class Initialized
INFO - 2024-08-09 10:32:38 --> Security Class Initialized
DEBUG - 2024-08-09 10:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:32:38 --> Input Class Initialized
INFO - 2024-08-09 10:32:38 --> Language Class Initialized
INFO - 2024-08-09 10:32:38 --> Loader Class Initialized
INFO - 2024-08-09 10:32:38 --> Helper loaded: url_helper
INFO - 2024-08-09 10:32:38 --> Helper loaded: form_helper
INFO - 2024-08-09 10:32:38 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:32:38 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:32:38 --> Email Class Initialized
INFO - 2024-08-09 10:32:38 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:32:38 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:32:38 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:32:38 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:32:38 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:32:38 --> Controller Class Initialized
INFO - 2024-08-09 10:32:38 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:32:38 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:32:38 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:32:38 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:32:38 --> Final output sent to browser
DEBUG - 2024-08-09 10:32:38 --> Total execution time: 0.1239
INFO - 2024-08-09 10:32:41 --> Config Class Initialized
INFO - 2024-08-09 10:32:41 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:32:41 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:41 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:41 --> URI Class Initialized
INFO - 2024-08-09 10:32:41 --> Router Class Initialized
INFO - 2024-08-09 10:32:41 --> Output Class Initialized
INFO - 2024-08-09 10:32:41 --> Security Class Initialized
DEBUG - 2024-08-09 10:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:32:41 --> Input Class Initialized
INFO - 2024-08-09 10:32:41 --> Language Class Initialized
INFO - 2024-08-09 10:32:41 --> Loader Class Initialized
INFO - 2024-08-09 10:32:41 --> Helper loaded: url_helper
INFO - 2024-08-09 10:32:41 --> Helper loaded: form_helper
INFO - 2024-08-09 10:32:41 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:32:41 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:32:41 --> Email Class Initialized
INFO - 2024-08-09 10:32:41 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:32:41 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:32:41 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:32:41 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:32:41 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:32:41 --> Controller Class Initialized
INFO - 2024-08-09 10:32:42 --> Config Class Initialized
INFO - 2024-08-09 10:32:42 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:32:42 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:42 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:42 --> URI Class Initialized
INFO - 2024-08-09 10:32:42 --> Router Class Initialized
INFO - 2024-08-09 10:32:42 --> Output Class Initialized
INFO - 2024-08-09 10:32:42 --> Security Class Initialized
DEBUG - 2024-08-09 10:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:32:42 --> Input Class Initialized
INFO - 2024-08-09 10:32:42 --> Language Class Initialized
INFO - 2024-08-09 10:32:42 --> Loader Class Initialized
INFO - 2024-08-09 10:32:42 --> Helper loaded: url_helper
INFO - 2024-08-09 10:32:42 --> Helper loaded: form_helper
INFO - 2024-08-09 10:32:42 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:32:42 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:32:42 --> Email Class Initialized
INFO - 2024-08-09 10:32:42 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:32:42 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:32:42 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:32:42 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:32:42 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:32:42 --> Controller Class Initialized
INFO - 2024-08-09 10:32:42 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:32:42 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:32:42 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:32:42 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:32:42 --> Final output sent to browser
DEBUG - 2024-08-09 10:32:42 --> Total execution time: 0.1018
INFO - 2024-08-09 10:32:42 --> Config Class Initialized
INFO - 2024-08-09 10:32:42 --> Config Class Initialized
INFO - 2024-08-09 10:32:42 --> Hooks Class Initialized
INFO - 2024-08-09 10:32:42 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:32:42 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:42 --> Utf8 Class Initialized
DEBUG - 2024-08-09 10:32:42 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:42 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:42 --> URI Class Initialized
INFO - 2024-08-09 10:32:42 --> Router Class Initialized
INFO - 2024-08-09 10:32:42 --> Output Class Initialized
INFO - 2024-08-09 10:32:42 --> Security Class Initialized
DEBUG - 2024-08-09 10:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:32:42 --> Input Class Initialized
INFO - 2024-08-09 10:32:42 --> Language Class Initialized
INFO - 2024-08-09 10:32:42 --> Loader Class Initialized
INFO - 2024-08-09 10:32:42 --> Helper loaded: url_helper
INFO - 2024-08-09 10:32:42 --> Helper loaded: form_helper
INFO - 2024-08-09 10:32:42 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:32:42 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:32:42 --> Email Class Initialized
INFO - 2024-08-09 10:32:42 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:32:42 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:32:42 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:32:42 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:32:42 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:32:42 --> Controller Class Initialized
INFO - 2024-08-09 10:32:42 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:32:42 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:32:42 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:32:42 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:32:42 --> Final output sent to browser
DEBUG - 2024-08-09 10:32:42 --> Total execution time: 0.1140
INFO - 2024-08-09 10:32:56 --> Config Class Initialized
INFO - 2024-08-09 10:32:56 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:32:56 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:56 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:56 --> URI Class Initialized
INFO - 2024-08-09 10:32:56 --> Router Class Initialized
INFO - 2024-08-09 10:32:56 --> Output Class Initialized
INFO - 2024-08-09 10:32:56 --> Security Class Initialized
DEBUG - 2024-08-09 10:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:32:56 --> Input Class Initialized
INFO - 2024-08-09 10:32:56 --> Language Class Initialized
INFO - 2024-08-09 10:32:56 --> Loader Class Initialized
INFO - 2024-08-09 10:32:56 --> Helper loaded: url_helper
INFO - 2024-08-09 10:32:56 --> Helper loaded: form_helper
INFO - 2024-08-09 10:32:56 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:32:56 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:32:56 --> Email Class Initialized
INFO - 2024-08-09 10:32:56 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:32:56 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:32:56 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:32:56 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:32:56 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:32:56 --> Controller Class Initialized
INFO - 2024-08-09 10:32:56 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:32:56 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:32:56 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:32:56 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:32:56 --> Final output sent to browser
DEBUG - 2024-08-09 10:32:56 --> Total execution time: 0.1903
INFO - 2024-08-09 10:32:57 --> Config Class Initialized
INFO - 2024-08-09 10:32:57 --> Hooks Class Initialized
INFO - 2024-08-09 10:32:57 --> Config Class Initialized
INFO - 2024-08-09 10:32:57 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:32:57 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:57 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:57 --> URI Class Initialized
DEBUG - 2024-08-09 10:32:57 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:57 --> Router Class Initialized
INFO - 2024-08-09 10:32:57 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:57 --> Output Class Initialized
INFO - 2024-08-09 10:32:57 --> Security Class Initialized
DEBUG - 2024-08-09 10:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:32:57 --> Input Class Initialized
INFO - 2024-08-09 10:32:57 --> Language Class Initialized
INFO - 2024-08-09 10:32:57 --> Loader Class Initialized
INFO - 2024-08-09 10:32:57 --> Helper loaded: url_helper
INFO - 2024-08-09 10:32:57 --> Helper loaded: form_helper
INFO - 2024-08-09 10:32:57 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:32:57 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:32:57 --> Email Class Initialized
INFO - 2024-08-09 10:32:57 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:32:57 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:32:57 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:32:57 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:32:57 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:32:57 --> Controller Class Initialized
INFO - 2024-08-09 10:32:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:32:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:32:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:32:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:32:57 --> Final output sent to browser
DEBUG - 2024-08-09 10:32:57 --> Total execution time: 0.1107
INFO - 2024-08-09 10:32:59 --> Config Class Initialized
INFO - 2024-08-09 10:32:59 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:32:59 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:32:59 --> Utf8 Class Initialized
INFO - 2024-08-09 10:32:59 --> URI Class Initialized
INFO - 2024-08-09 10:32:59 --> Router Class Initialized
INFO - 2024-08-09 10:32:59 --> Output Class Initialized
INFO - 2024-08-09 10:32:59 --> Security Class Initialized
DEBUG - 2024-08-09 10:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:32:59 --> Input Class Initialized
INFO - 2024-08-09 10:32:59 --> Language Class Initialized
INFO - 2024-08-09 10:32:59 --> Loader Class Initialized
INFO - 2024-08-09 10:32:59 --> Helper loaded: url_helper
INFO - 2024-08-09 10:32:59 --> Helper loaded: form_helper
INFO - 2024-08-09 10:32:59 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:32:59 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:32:59 --> Email Class Initialized
INFO - 2024-08-09 10:32:59 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:32:59 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:32:59 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:32:59 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:32:59 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:32:59 --> Controller Class Initialized
INFO - 2024-08-09 10:32:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:32:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:32:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:32:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:32:59 --> Final output sent to browser
DEBUG - 2024-08-09 10:32:59 --> Total execution time: 0.0977
INFO - 2024-08-09 10:33:00 --> Config Class Initialized
INFO - 2024-08-09 10:33:00 --> Config Class Initialized
INFO - 2024-08-09 10:33:00 --> Hooks Class Initialized
INFO - 2024-08-09 10:33:00 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:33:00 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 10:33:00 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:33:00 --> Utf8 Class Initialized
INFO - 2024-08-09 10:33:00 --> Utf8 Class Initialized
INFO - 2024-08-09 10:33:00 --> URI Class Initialized
INFO - 2024-08-09 10:33:00 --> Router Class Initialized
INFO - 2024-08-09 10:33:00 --> Output Class Initialized
INFO - 2024-08-09 10:33:00 --> Security Class Initialized
DEBUG - 2024-08-09 10:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:33:00 --> Input Class Initialized
INFO - 2024-08-09 10:33:00 --> Language Class Initialized
INFO - 2024-08-09 10:33:00 --> Loader Class Initialized
INFO - 2024-08-09 10:33:00 --> Helper loaded: url_helper
INFO - 2024-08-09 10:33:00 --> Helper loaded: form_helper
INFO - 2024-08-09 10:33:00 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:33:00 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:33:00 --> Email Class Initialized
INFO - 2024-08-09 10:33:00 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:33:00 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:33:00 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:33:00 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:33:00 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:33:00 --> Controller Class Initialized
INFO - 2024-08-09 10:33:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:33:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:33:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:33:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:33:00 --> Final output sent to browser
DEBUG - 2024-08-09 10:33:00 --> Total execution time: 0.1257
INFO - 2024-08-09 10:33:00 --> Config Class Initialized
INFO - 2024-08-09 10:33:00 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:33:00 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:33:00 --> Utf8 Class Initialized
INFO - 2024-08-09 10:33:00 --> URI Class Initialized
INFO - 2024-08-09 10:33:00 --> Router Class Initialized
INFO - 2024-08-09 10:33:00 --> Output Class Initialized
INFO - 2024-08-09 10:33:00 --> Security Class Initialized
DEBUG - 2024-08-09 10:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:33:00 --> Input Class Initialized
INFO - 2024-08-09 10:33:00 --> Language Class Initialized
INFO - 2024-08-09 10:33:00 --> Loader Class Initialized
INFO - 2024-08-09 10:33:00 --> Helper loaded: url_helper
INFO - 2024-08-09 10:33:00 --> Helper loaded: form_helper
INFO - 2024-08-09 10:33:00 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:33:00 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:33:00 --> Email Class Initialized
INFO - 2024-08-09 10:33:00 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:33:00 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:33:00 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:33:00 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:33:00 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:33:00 --> Controller Class Initialized
INFO - 2024-08-09 10:33:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:33:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:33:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:33:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:33:00 --> Final output sent to browser
DEBUG - 2024-08-09 10:33:00 --> Total execution time: 0.1177
INFO - 2024-08-09 10:33:01 --> Config Class Initialized
INFO - 2024-08-09 10:33:01 --> Hooks Class Initialized
INFO - 2024-08-09 10:33:01 --> Config Class Initialized
INFO - 2024-08-09 10:33:01 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:33:01 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:33:01 --> Utf8 Class Initialized
DEBUG - 2024-08-09 10:33:01 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:33:01 --> Utf8 Class Initialized
INFO - 2024-08-09 10:33:01 --> URI Class Initialized
INFO - 2024-08-09 10:33:01 --> Router Class Initialized
INFO - 2024-08-09 10:33:01 --> Output Class Initialized
INFO - 2024-08-09 10:33:01 --> Security Class Initialized
DEBUG - 2024-08-09 10:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:33:01 --> Input Class Initialized
INFO - 2024-08-09 10:33:01 --> Language Class Initialized
INFO - 2024-08-09 10:33:01 --> Loader Class Initialized
INFO - 2024-08-09 10:33:01 --> Helper loaded: url_helper
INFO - 2024-08-09 10:33:01 --> Helper loaded: form_helper
INFO - 2024-08-09 10:33:01 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:33:01 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:33:02 --> Email Class Initialized
INFO - 2024-08-09 10:33:02 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:33:02 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:33:02 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:33:02 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:33:02 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:33:02 --> Controller Class Initialized
INFO - 2024-08-09 10:33:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:33:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:33:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:33:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:33:02 --> Final output sent to browser
DEBUG - 2024-08-09 10:33:02 --> Total execution time: 0.1128
INFO - 2024-08-09 10:33:04 --> Config Class Initialized
INFO - 2024-08-09 10:33:04 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:33:04 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:33:04 --> Utf8 Class Initialized
INFO - 2024-08-09 10:33:04 --> URI Class Initialized
INFO - 2024-08-09 10:33:04 --> Router Class Initialized
INFO - 2024-08-09 10:33:04 --> Output Class Initialized
INFO - 2024-08-09 10:33:04 --> Security Class Initialized
DEBUG - 2024-08-09 10:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:33:04 --> Input Class Initialized
INFO - 2024-08-09 10:33:04 --> Language Class Initialized
INFO - 2024-08-09 10:33:04 --> Loader Class Initialized
INFO - 2024-08-09 10:33:04 --> Helper loaded: url_helper
INFO - 2024-08-09 10:33:04 --> Helper loaded: form_helper
INFO - 2024-08-09 10:33:04 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:33:04 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:33:04 --> Email Class Initialized
INFO - 2024-08-09 10:33:04 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:33:04 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:33:04 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:33:04 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:33:04 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:33:04 --> Controller Class Initialized
INFO - 2024-08-09 10:33:04 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:33:04 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:33:04 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:33:04 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:33:04 --> Final output sent to browser
DEBUG - 2024-08-09 10:33:04 --> Total execution time: 0.1090
INFO - 2024-08-09 10:33:05 --> Config Class Initialized
INFO - 2024-08-09 10:33:05 --> Hooks Class Initialized
INFO - 2024-08-09 10:33:05 --> Config Class Initialized
INFO - 2024-08-09 10:33:05 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:33:05 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:33:05 --> Utf8 Class Initialized
DEBUG - 2024-08-09 10:33:05 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:33:05 --> Utf8 Class Initialized
INFO - 2024-08-09 10:33:05 --> URI Class Initialized
INFO - 2024-08-09 10:33:05 --> Router Class Initialized
INFO - 2024-08-09 10:33:05 --> Output Class Initialized
INFO - 2024-08-09 10:33:05 --> Security Class Initialized
DEBUG - 2024-08-09 10:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:33:05 --> Input Class Initialized
INFO - 2024-08-09 10:33:05 --> Language Class Initialized
INFO - 2024-08-09 10:33:05 --> Loader Class Initialized
INFO - 2024-08-09 10:33:05 --> Helper loaded: url_helper
INFO - 2024-08-09 10:33:05 --> Helper loaded: form_helper
INFO - 2024-08-09 10:33:05 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:33:05 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:33:05 --> Email Class Initialized
INFO - 2024-08-09 10:33:05 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:33:05 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:33:05 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:33:05 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:33:05 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:33:05 --> Controller Class Initialized
INFO - 2024-08-09 10:33:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:33:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:33:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:33:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:33:05 --> Final output sent to browser
DEBUG - 2024-08-09 10:33:05 --> Total execution time: 0.1191
INFO - 2024-08-09 10:33:09 --> Config Class Initialized
INFO - 2024-08-09 10:33:09 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:33:09 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:33:09 --> Utf8 Class Initialized
INFO - 2024-08-09 10:33:09 --> URI Class Initialized
INFO - 2024-08-09 10:33:09 --> Router Class Initialized
INFO - 2024-08-09 10:33:09 --> Output Class Initialized
INFO - 2024-08-09 10:33:09 --> Security Class Initialized
DEBUG - 2024-08-09 10:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:33:09 --> Input Class Initialized
INFO - 2024-08-09 10:33:09 --> Language Class Initialized
INFO - 2024-08-09 10:33:09 --> Loader Class Initialized
INFO - 2024-08-09 10:33:09 --> Helper loaded: url_helper
INFO - 2024-08-09 10:33:09 --> Helper loaded: form_helper
INFO - 2024-08-09 10:33:09 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:33:09 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:33:09 --> Email Class Initialized
INFO - 2024-08-09 10:33:09 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:33:09 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:33:09 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:33:09 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:33:09 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:33:09 --> Controller Class Initialized
INFO - 2024-08-09 10:33:09 --> Config Class Initialized
INFO - 2024-08-09 10:33:09 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:33:09 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:33:09 --> Utf8 Class Initialized
INFO - 2024-08-09 10:33:09 --> URI Class Initialized
INFO - 2024-08-09 10:33:09 --> Router Class Initialized
INFO - 2024-08-09 10:33:09 --> Output Class Initialized
INFO - 2024-08-09 10:33:09 --> Security Class Initialized
DEBUG - 2024-08-09 10:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:33:09 --> Input Class Initialized
INFO - 2024-08-09 10:33:09 --> Language Class Initialized
INFO - 2024-08-09 10:33:09 --> Loader Class Initialized
INFO - 2024-08-09 10:33:09 --> Helper loaded: url_helper
INFO - 2024-08-09 10:33:09 --> Helper loaded: form_helper
INFO - 2024-08-09 10:33:09 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:33:09 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:33:09 --> Email Class Initialized
INFO - 2024-08-09 10:33:09 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:33:09 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:33:09 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:33:09 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:33:09 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:33:09 --> Controller Class Initialized
INFO - 2024-08-09 10:33:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:33:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:33:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:33:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:33:09 --> Final output sent to browser
DEBUG - 2024-08-09 10:33:09 --> Total execution time: 0.0851
INFO - 2024-08-09 10:33:09 --> Config Class Initialized
INFO - 2024-08-09 10:33:09 --> Hooks Class Initialized
INFO - 2024-08-09 10:33:09 --> Config Class Initialized
DEBUG - 2024-08-09 10:33:09 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:33:09 --> Utf8 Class Initialized
INFO - 2024-08-09 10:33:09 --> URI Class Initialized
INFO - 2024-08-09 10:33:09 --> Hooks Class Initialized
INFO - 2024-08-09 10:33:09 --> Router Class Initialized
DEBUG - 2024-08-09 10:33:09 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:33:09 --> Utf8 Class Initialized
INFO - 2024-08-09 10:33:09 --> Output Class Initialized
INFO - 2024-08-09 10:33:09 --> Security Class Initialized
DEBUG - 2024-08-09 10:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:33:09 --> Input Class Initialized
INFO - 2024-08-09 10:33:09 --> Language Class Initialized
INFO - 2024-08-09 10:33:09 --> Loader Class Initialized
INFO - 2024-08-09 10:33:09 --> Helper loaded: url_helper
INFO - 2024-08-09 10:33:09 --> Helper loaded: form_helper
INFO - 2024-08-09 10:33:09 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:33:09 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:33:09 --> Email Class Initialized
INFO - 2024-08-09 10:33:09 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:33:09 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:33:09 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:33:09 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:33:09 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:33:09 --> Controller Class Initialized
INFO - 2024-08-09 10:33:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:33:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:33:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:33:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:33:09 --> Final output sent to browser
DEBUG - 2024-08-09 10:33:09 --> Total execution time: 0.1276
INFO - 2024-08-09 10:33:51 --> Config Class Initialized
INFO - 2024-08-09 10:33:51 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:33:51 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:33:51 --> Utf8 Class Initialized
INFO - 2024-08-09 10:33:51 --> URI Class Initialized
INFO - 2024-08-09 10:33:51 --> Router Class Initialized
INFO - 2024-08-09 10:33:51 --> Output Class Initialized
INFO - 2024-08-09 10:33:51 --> Security Class Initialized
DEBUG - 2024-08-09 10:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:33:51 --> Input Class Initialized
INFO - 2024-08-09 10:33:51 --> Language Class Initialized
ERROR - 2024-08-09 10:33:51 --> Severity: error --> Exception: syntax error, unexpected token ")", expecting variable or "{" or "$" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 126
INFO - 2024-08-09 10:34:07 --> Config Class Initialized
INFO - 2024-08-09 10:34:07 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:34:07 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:34:07 --> Utf8 Class Initialized
INFO - 2024-08-09 10:34:07 --> URI Class Initialized
INFO - 2024-08-09 10:34:07 --> Router Class Initialized
INFO - 2024-08-09 10:34:07 --> Output Class Initialized
INFO - 2024-08-09 10:34:07 --> Security Class Initialized
DEBUG - 2024-08-09 10:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:34:07 --> Input Class Initialized
INFO - 2024-08-09 10:34:07 --> Language Class Initialized
ERROR - 2024-08-09 10:34:07 --> Severity: error --> Exception: syntax error, unexpected token ")", expecting variable or "{" or "$" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 126
INFO - 2024-08-09 10:35:02 --> Config Class Initialized
INFO - 2024-08-09 10:35:02 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:35:02 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:35:02 --> Utf8 Class Initialized
INFO - 2024-08-09 10:35:02 --> URI Class Initialized
INFO - 2024-08-09 10:35:02 --> Router Class Initialized
INFO - 2024-08-09 10:35:02 --> Output Class Initialized
INFO - 2024-08-09 10:35:02 --> Security Class Initialized
DEBUG - 2024-08-09 10:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:35:02 --> Input Class Initialized
INFO - 2024-08-09 10:35:02 --> Language Class Initialized
INFO - 2024-08-09 10:35:02 --> Loader Class Initialized
INFO - 2024-08-09 10:35:02 --> Helper loaded: url_helper
INFO - 2024-08-09 10:35:02 --> Helper loaded: form_helper
INFO - 2024-08-09 10:35:02 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:35:02 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:35:02 --> Email Class Initialized
INFO - 2024-08-09 10:35:02 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:35:02 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:35:02 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:35:02 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:35:02 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:35:02 --> Controller Class Initialized
INFO - 2024-08-09 10:35:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:35:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:35:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:35:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:35:02 --> Final output sent to browser
DEBUG - 2024-08-09 10:35:02 --> Total execution time: 0.1365
INFO - 2024-08-09 10:35:03 --> Config Class Initialized
INFO - 2024-08-09 10:35:03 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:35:03 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:35:03 --> Utf8 Class Initialized
INFO - 2024-08-09 10:35:03 --> URI Class Initialized
INFO - 2024-08-09 10:35:03 --> Router Class Initialized
INFO - 2024-08-09 10:35:03 --> Output Class Initialized
INFO - 2024-08-09 10:35:03 --> Security Class Initialized
DEBUG - 2024-08-09 10:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:35:03 --> Input Class Initialized
INFO - 2024-08-09 10:35:03 --> Config Class Initialized
INFO - 2024-08-09 10:35:03 --> Hooks Class Initialized
INFO - 2024-08-09 10:35:03 --> Language Class Initialized
DEBUG - 2024-08-09 10:35:03 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:35:03 --> Loader Class Initialized
INFO - 2024-08-09 10:35:03 --> Utf8 Class Initialized
INFO - 2024-08-09 10:35:03 --> Helper loaded: url_helper
INFO - 2024-08-09 10:35:03 --> Helper loaded: form_helper
INFO - 2024-08-09 10:35:03 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:35:03 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:35:03 --> Email Class Initialized
INFO - 2024-08-09 10:35:03 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:35:03 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:35:03 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:35:03 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:35:03 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:35:03 --> Controller Class Initialized
INFO - 2024-08-09 10:35:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:35:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:35:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:35:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:35:03 --> Final output sent to browser
DEBUG - 2024-08-09 10:35:03 --> Total execution time: 0.1366
INFO - 2024-08-09 10:35:06 --> Config Class Initialized
INFO - 2024-08-09 10:35:06 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:35:06 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:35:06 --> Utf8 Class Initialized
INFO - 2024-08-09 10:35:06 --> URI Class Initialized
INFO - 2024-08-09 10:35:06 --> Router Class Initialized
INFO - 2024-08-09 10:35:06 --> Output Class Initialized
INFO - 2024-08-09 10:35:06 --> Security Class Initialized
DEBUG - 2024-08-09 10:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:35:06 --> Input Class Initialized
INFO - 2024-08-09 10:35:06 --> Language Class Initialized
INFO - 2024-08-09 10:35:06 --> Loader Class Initialized
INFO - 2024-08-09 10:35:06 --> Helper loaded: url_helper
INFO - 2024-08-09 10:35:06 --> Helper loaded: form_helper
INFO - 2024-08-09 10:35:06 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:35:06 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:35:06 --> Email Class Initialized
INFO - 2024-08-09 10:35:06 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:35:06 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:35:06 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:35:06 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:35:06 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:35:06 --> Controller Class Initialized
INFO - 2024-08-09 10:35:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:35:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:35:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:35:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:35:06 --> Final output sent to browser
DEBUG - 2024-08-09 10:35:06 --> Total execution time: 0.1136
INFO - 2024-08-09 10:35:06 --> Config Class Initialized
INFO - 2024-08-09 10:35:06 --> Config Class Initialized
INFO - 2024-08-09 10:35:06 --> Hooks Class Initialized
INFO - 2024-08-09 10:35:06 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:35:06 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:35:06 --> Utf8 Class Initialized
DEBUG - 2024-08-09 10:35:06 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:35:06 --> Utf8 Class Initialized
INFO - 2024-08-09 10:35:06 --> URI Class Initialized
INFO - 2024-08-09 10:35:06 --> Router Class Initialized
INFO - 2024-08-09 10:35:06 --> Output Class Initialized
INFO - 2024-08-09 10:35:06 --> Security Class Initialized
DEBUG - 2024-08-09 10:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:35:06 --> Input Class Initialized
INFO - 2024-08-09 10:35:06 --> Language Class Initialized
INFO - 2024-08-09 10:35:06 --> Loader Class Initialized
INFO - 2024-08-09 10:35:06 --> Helper loaded: url_helper
INFO - 2024-08-09 10:35:06 --> Helper loaded: form_helper
INFO - 2024-08-09 10:35:06 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:35:06 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:35:07 --> Email Class Initialized
INFO - 2024-08-09 10:35:07 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:35:07 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:35:07 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:35:07 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:35:07 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:35:07 --> Controller Class Initialized
INFO - 2024-08-09 10:35:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:35:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:35:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:35:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:35:07 --> Final output sent to browser
DEBUG - 2024-08-09 10:35:07 --> Total execution time: 0.1389
INFO - 2024-08-09 10:35:15 --> Config Class Initialized
INFO - 2024-08-09 10:35:15 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:35:15 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:35:15 --> Utf8 Class Initialized
INFO - 2024-08-09 10:35:15 --> URI Class Initialized
INFO - 2024-08-09 10:35:15 --> Router Class Initialized
INFO - 2024-08-09 10:35:15 --> Output Class Initialized
INFO - 2024-08-09 10:35:15 --> Security Class Initialized
DEBUG - 2024-08-09 10:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:35:15 --> Input Class Initialized
INFO - 2024-08-09 10:35:15 --> Language Class Initialized
INFO - 2024-08-09 10:35:15 --> Loader Class Initialized
INFO - 2024-08-09 10:35:15 --> Helper loaded: url_helper
INFO - 2024-08-09 10:35:15 --> Helper loaded: form_helper
INFO - 2024-08-09 10:35:15 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:35:15 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:35:15 --> Email Class Initialized
INFO - 2024-08-09 10:35:15 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:35:15 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:35:15 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:35:15 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:35:15 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:35:15 --> Controller Class Initialized
INFO - 2024-08-09 10:35:15 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:35:15 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:35:15 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:35:15 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:35:15 --> Final output sent to browser
DEBUG - 2024-08-09 10:35:15 --> Total execution time: 0.1524
INFO - 2024-08-09 10:35:15 --> Config Class Initialized
INFO - 2024-08-09 10:35:15 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:35:15 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:35:15 --> Utf8 Class Initialized
INFO - 2024-08-09 10:35:15 --> URI Class Initialized
INFO - 2024-08-09 10:35:15 --> Router Class Initialized
INFO - 2024-08-09 10:35:15 --> Config Class Initialized
INFO - 2024-08-09 10:35:15 --> Hooks Class Initialized
INFO - 2024-08-09 10:35:15 --> Output Class Initialized
INFO - 2024-08-09 10:35:15 --> Security Class Initialized
DEBUG - 2024-08-09 10:35:15 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:35:15 --> Utf8 Class Initialized
DEBUG - 2024-08-09 10:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:35:15 --> Input Class Initialized
INFO - 2024-08-09 10:35:15 --> Language Class Initialized
INFO - 2024-08-09 10:35:15 --> Loader Class Initialized
INFO - 2024-08-09 10:35:15 --> Helper loaded: url_helper
INFO - 2024-08-09 10:35:15 --> Helper loaded: form_helper
INFO - 2024-08-09 10:35:15 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:35:15 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:35:15 --> Email Class Initialized
INFO - 2024-08-09 10:35:15 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:35:15 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:35:15 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:35:15 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:35:15 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:35:15 --> Controller Class Initialized
INFO - 2024-08-09 10:35:15 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:35:15 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:35:15 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:35:15 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:35:15 --> Final output sent to browser
DEBUG - 2024-08-09 10:35:15 --> Total execution time: 0.1074
INFO - 2024-08-09 10:35:20 --> Config Class Initialized
INFO - 2024-08-09 10:35:20 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:35:20 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:35:20 --> Utf8 Class Initialized
INFO - 2024-08-09 10:35:20 --> URI Class Initialized
INFO - 2024-08-09 10:35:20 --> Router Class Initialized
INFO - 2024-08-09 10:35:20 --> Output Class Initialized
INFO - 2024-08-09 10:35:20 --> Security Class Initialized
DEBUG - 2024-08-09 10:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:35:20 --> Input Class Initialized
INFO - 2024-08-09 10:35:20 --> Language Class Initialized
INFO - 2024-08-09 10:35:20 --> Loader Class Initialized
INFO - 2024-08-09 10:35:20 --> Helper loaded: url_helper
INFO - 2024-08-09 10:35:20 --> Helper loaded: form_helper
INFO - 2024-08-09 10:35:20 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:35:20 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:35:20 --> Email Class Initialized
INFO - 2024-08-09 10:35:20 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:35:20 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:35:20 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:35:20 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:35:20 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:35:20 --> Controller Class Initialized
INFO - 2024-08-09 10:35:20 --> Config Class Initialized
INFO - 2024-08-09 10:35:20 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:35:20 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:35:20 --> Utf8 Class Initialized
INFO - 2024-08-09 10:35:20 --> URI Class Initialized
INFO - 2024-08-09 10:35:20 --> Router Class Initialized
INFO - 2024-08-09 10:35:20 --> Output Class Initialized
INFO - 2024-08-09 10:35:20 --> Security Class Initialized
DEBUG - 2024-08-09 10:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:35:20 --> Input Class Initialized
INFO - 2024-08-09 10:35:20 --> Language Class Initialized
INFO - 2024-08-09 10:35:20 --> Loader Class Initialized
INFO - 2024-08-09 10:35:20 --> Helper loaded: url_helper
INFO - 2024-08-09 10:35:20 --> Helper loaded: form_helper
INFO - 2024-08-09 10:35:20 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:35:20 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:35:20 --> Email Class Initialized
INFO - 2024-08-09 10:35:20 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:35:20 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:35:20 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:35:20 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:35:20 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:35:20 --> Controller Class Initialized
INFO - 2024-08-09 10:35:20 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:35:20 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:35:20 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:35:20 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:35:20 --> Final output sent to browser
DEBUG - 2024-08-09 10:35:20 --> Total execution time: 0.0836
INFO - 2024-08-09 10:35:20 --> Config Class Initialized
INFO - 2024-08-09 10:35:20 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:35:20 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:35:20 --> Utf8 Class Initialized
INFO - 2024-08-09 10:35:20 --> Config Class Initialized
INFO - 2024-08-09 10:35:20 --> URI Class Initialized
INFO - 2024-08-09 10:35:20 --> Hooks Class Initialized
INFO - 2024-08-09 10:35:21 --> Router Class Initialized
DEBUG - 2024-08-09 10:35:21 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:35:21 --> Utf8 Class Initialized
INFO - 2024-08-09 10:35:21 --> Output Class Initialized
INFO - 2024-08-09 10:35:21 --> Security Class Initialized
DEBUG - 2024-08-09 10:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:35:21 --> Input Class Initialized
INFO - 2024-08-09 10:35:21 --> Language Class Initialized
INFO - 2024-08-09 10:35:21 --> Loader Class Initialized
INFO - 2024-08-09 10:35:21 --> Helper loaded: url_helper
INFO - 2024-08-09 10:35:21 --> Helper loaded: form_helper
INFO - 2024-08-09 10:35:21 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:35:21 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:35:21 --> Email Class Initialized
INFO - 2024-08-09 10:35:21 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:35:21 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:35:21 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:35:21 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:35:21 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:35:21 --> Controller Class Initialized
INFO - 2024-08-09 10:35:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:35:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:35:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:35:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:35:21 --> Final output sent to browser
DEBUG - 2024-08-09 10:35:21 --> Total execution time: 0.1330
INFO - 2024-08-09 10:49:44 --> Config Class Initialized
INFO - 2024-08-09 10:49:44 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:49:44 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:49:44 --> Utf8 Class Initialized
INFO - 2024-08-09 10:49:44 --> URI Class Initialized
INFO - 2024-08-09 10:49:44 --> Router Class Initialized
INFO - 2024-08-09 10:49:44 --> Output Class Initialized
INFO - 2024-08-09 10:49:44 --> Security Class Initialized
DEBUG - 2024-08-09 10:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:49:44 --> Input Class Initialized
INFO - 2024-08-09 10:49:44 --> Language Class Initialized
INFO - 2024-08-09 10:49:44 --> Loader Class Initialized
INFO - 2024-08-09 10:49:44 --> Helper loaded: url_helper
INFO - 2024-08-09 10:49:44 --> Helper loaded: form_helper
INFO - 2024-08-09 10:49:44 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:49:44 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:49:44 --> Email Class Initialized
INFO - 2024-08-09 10:49:44 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:49:44 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:49:44 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:49:44 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:49:44 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:49:44 --> Controller Class Initialized
ERROR - 2024-08-09 10:49:44 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 76
ERROR - 2024-08-09 10:49:44 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 77
INFO - 2024-08-09 10:49:44 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:49:44 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:49:44 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:49:44 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:49:44 --> Final output sent to browser
DEBUG - 2024-08-09 10:49:44 --> Total execution time: 0.1480
INFO - 2024-08-09 10:49:44 --> Config Class Initialized
INFO - 2024-08-09 10:49:44 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:49:44 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:49:44 --> Utf8 Class Initialized
INFO - 2024-08-09 10:49:44 --> Config Class Initialized
INFO - 2024-08-09 10:49:44 --> Hooks Class Initialized
INFO - 2024-08-09 10:49:44 --> URI Class Initialized
DEBUG - 2024-08-09 10:49:44 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:49:44 --> Router Class Initialized
INFO - 2024-08-09 10:49:44 --> Utf8 Class Initialized
INFO - 2024-08-09 10:49:44 --> Output Class Initialized
INFO - 2024-08-09 10:49:45 --> Security Class Initialized
DEBUG - 2024-08-09 10:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:49:45 --> Input Class Initialized
INFO - 2024-08-09 10:49:45 --> Language Class Initialized
INFO - 2024-08-09 10:49:45 --> Loader Class Initialized
INFO - 2024-08-09 10:49:45 --> Helper loaded: url_helper
INFO - 2024-08-09 10:49:45 --> Helper loaded: form_helper
INFO - 2024-08-09 10:49:45 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:49:45 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:49:45 --> Email Class Initialized
INFO - 2024-08-09 10:49:45 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:49:45 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:49:45 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:49:45 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:49:45 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:49:45 --> Controller Class Initialized
ERROR - 2024-08-09 10:49:45 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 76
ERROR - 2024-08-09 10:49:45 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 77
INFO - 2024-08-09 10:49:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:49:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:49:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:49:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:49:45 --> Final output sent to browser
DEBUG - 2024-08-09 10:49:45 --> Total execution time: 0.1339
INFO - 2024-08-09 10:49:47 --> Config Class Initialized
INFO - 2024-08-09 10:49:47 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:49:47 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:49:47 --> Utf8 Class Initialized
INFO - 2024-08-09 10:49:47 --> URI Class Initialized
INFO - 2024-08-09 10:49:47 --> Router Class Initialized
INFO - 2024-08-09 10:49:47 --> Output Class Initialized
INFO - 2024-08-09 10:49:47 --> Security Class Initialized
DEBUG - 2024-08-09 10:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:49:47 --> Input Class Initialized
INFO - 2024-08-09 10:49:47 --> Language Class Initialized
INFO - 2024-08-09 10:49:47 --> Loader Class Initialized
INFO - 2024-08-09 10:49:47 --> Helper loaded: url_helper
INFO - 2024-08-09 10:49:47 --> Helper loaded: form_helper
INFO - 2024-08-09 10:49:47 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:49:47 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:49:47 --> Email Class Initialized
INFO - 2024-08-09 10:49:47 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:49:47 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:49:47 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:49:47 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:49:47 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:49:47 --> Controller Class Initialized
INFO - 2024-08-09 10:49:47 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:49:47 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:49:47 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:49:47 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:49:47 --> Final output sent to browser
DEBUG - 2024-08-09 10:49:47 --> Total execution time: 0.1158
INFO - 2024-08-09 10:49:48 --> Config Class Initialized
INFO - 2024-08-09 10:49:48 --> Hooks Class Initialized
INFO - 2024-08-09 10:49:48 --> Config Class Initialized
INFO - 2024-08-09 10:49:48 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:49:48 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:49:48 --> Utf8 Class Initialized
DEBUG - 2024-08-09 10:49:48 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:49:48 --> Utf8 Class Initialized
INFO - 2024-08-09 10:49:48 --> URI Class Initialized
INFO - 2024-08-09 10:49:48 --> Router Class Initialized
INFO - 2024-08-09 10:49:48 --> Output Class Initialized
INFO - 2024-08-09 10:49:48 --> Security Class Initialized
DEBUG - 2024-08-09 10:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:49:48 --> Input Class Initialized
INFO - 2024-08-09 10:49:48 --> Language Class Initialized
INFO - 2024-08-09 10:49:48 --> Loader Class Initialized
INFO - 2024-08-09 10:49:48 --> Helper loaded: url_helper
INFO - 2024-08-09 10:49:48 --> Helper loaded: form_helper
INFO - 2024-08-09 10:49:48 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:49:48 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:49:48 --> Email Class Initialized
INFO - 2024-08-09 10:49:48 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:49:48 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:49:48 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:49:48 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:49:48 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:49:48 --> Controller Class Initialized
INFO - 2024-08-09 10:49:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:49:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:49:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:49:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:49:48 --> Final output sent to browser
DEBUG - 2024-08-09 10:49:48 --> Total execution time: 0.1140
INFO - 2024-08-09 10:49:49 --> Config Class Initialized
INFO - 2024-08-09 10:49:49 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:49:49 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:49:49 --> Utf8 Class Initialized
INFO - 2024-08-09 10:49:49 --> URI Class Initialized
INFO - 2024-08-09 10:49:49 --> Router Class Initialized
INFO - 2024-08-09 10:49:49 --> Output Class Initialized
INFO - 2024-08-09 10:49:49 --> Security Class Initialized
DEBUG - 2024-08-09 10:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:49:49 --> Input Class Initialized
INFO - 2024-08-09 10:49:49 --> Language Class Initialized
INFO - 2024-08-09 10:49:49 --> Loader Class Initialized
INFO - 2024-08-09 10:49:49 --> Helper loaded: url_helper
INFO - 2024-08-09 10:49:49 --> Helper loaded: form_helper
INFO - 2024-08-09 10:49:49 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:49:49 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:49:49 --> Email Class Initialized
INFO - 2024-08-09 10:49:49 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:49:49 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:49:49 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:49:49 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:49:49 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:49:49 --> Controller Class Initialized
INFO - 2024-08-09 10:49:49 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:49:49 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:49:49 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:49:49 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:49:49 --> Final output sent to browser
DEBUG - 2024-08-09 10:49:49 --> Total execution time: 0.0999
INFO - 2024-08-09 10:49:49 --> Config Class Initialized
INFO - 2024-08-09 10:49:49 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:49:49 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:49:49 --> Utf8 Class Initialized
INFO - 2024-08-09 10:49:49 --> URI Class Initialized
INFO - 2024-08-09 10:49:49 --> Router Class Initialized
INFO - 2024-08-09 10:49:49 --> Output Class Initialized
INFO - 2024-08-09 10:49:49 --> Security Class Initialized
DEBUG - 2024-08-09 10:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:49:49 --> Input Class Initialized
INFO - 2024-08-09 10:49:49 --> Language Class Initialized
INFO - 2024-08-09 10:49:49 --> Loader Class Initialized
INFO - 2024-08-09 10:49:49 --> Helper loaded: url_helper
INFO - 2024-08-09 10:49:49 --> Helper loaded: form_helper
INFO - 2024-08-09 10:49:49 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:49:49 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:49:49 --> Config Class Initialized
INFO - 2024-08-09 10:49:49 --> Hooks Class Initialized
INFO - 2024-08-09 10:49:49 --> Email Class Initialized
INFO - 2024-08-09 10:49:49 --> Model "Estudiante_model" initialized
DEBUG - 2024-08-09 10:49:50 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:49:50 --> Utf8 Class Initialized
INFO - 2024-08-09 10:49:50 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:49:50 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:49:50 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:49:50 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:49:50 --> Controller Class Initialized
INFO - 2024-08-09 10:49:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:49:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:49:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:49:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:49:50 --> Final output sent to browser
DEBUG - 2024-08-09 10:49:50 --> Total execution time: 0.1339
INFO - 2024-08-09 10:49:50 --> Config Class Initialized
INFO - 2024-08-09 10:49:50 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:49:50 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:49:50 --> Utf8 Class Initialized
INFO - 2024-08-09 10:49:50 --> URI Class Initialized
INFO - 2024-08-09 10:49:50 --> Router Class Initialized
INFO - 2024-08-09 10:49:50 --> Output Class Initialized
INFO - 2024-08-09 10:49:50 --> Security Class Initialized
DEBUG - 2024-08-09 10:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:49:50 --> Input Class Initialized
INFO - 2024-08-09 10:49:50 --> Language Class Initialized
INFO - 2024-08-09 10:49:50 --> Loader Class Initialized
INFO - 2024-08-09 10:49:50 --> Helper loaded: url_helper
INFO - 2024-08-09 10:49:50 --> Helper loaded: form_helper
INFO - 2024-08-09 10:49:50 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:49:50 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:49:50 --> Email Class Initialized
INFO - 2024-08-09 10:49:50 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:49:50 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:49:50 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:49:50 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:49:50 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:49:50 --> Controller Class Initialized
INFO - 2024-08-09 10:49:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:49:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:49:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:49:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:49:50 --> Final output sent to browser
DEBUG - 2024-08-09 10:49:50 --> Total execution time: 0.1328
INFO - 2024-08-09 10:49:51 --> Config Class Initialized
INFO - 2024-08-09 10:49:51 --> Config Class Initialized
INFO - 2024-08-09 10:49:51 --> Hooks Class Initialized
INFO - 2024-08-09 10:49:51 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:49:51 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:49:51 --> Utf8 Class Initialized
DEBUG - 2024-08-09 10:49:51 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:49:51 --> Utf8 Class Initialized
INFO - 2024-08-09 10:49:51 --> URI Class Initialized
INFO - 2024-08-09 10:49:51 --> Router Class Initialized
INFO - 2024-08-09 10:49:51 --> Output Class Initialized
INFO - 2024-08-09 10:49:51 --> Security Class Initialized
DEBUG - 2024-08-09 10:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:49:51 --> Input Class Initialized
INFO - 2024-08-09 10:49:51 --> Language Class Initialized
INFO - 2024-08-09 10:49:51 --> Loader Class Initialized
INFO - 2024-08-09 10:49:51 --> Helper loaded: url_helper
INFO - 2024-08-09 10:49:51 --> Helper loaded: form_helper
INFO - 2024-08-09 10:49:51 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:49:51 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:49:51 --> Email Class Initialized
INFO - 2024-08-09 10:49:51 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:49:51 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:49:51 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:49:51 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:49:51 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:49:51 --> Controller Class Initialized
INFO - 2024-08-09 10:49:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:49:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:49:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:49:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:49:51 --> Final output sent to browser
DEBUG - 2024-08-09 10:49:51 --> Total execution time: 0.1177
INFO - 2024-08-09 10:49:52 --> Config Class Initialized
INFO - 2024-08-09 10:49:52 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:49:52 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:49:52 --> Utf8 Class Initialized
INFO - 2024-08-09 10:49:52 --> URI Class Initialized
INFO - 2024-08-09 10:49:52 --> Router Class Initialized
INFO - 2024-08-09 10:49:52 --> Output Class Initialized
INFO - 2024-08-09 10:49:52 --> Security Class Initialized
DEBUG - 2024-08-09 10:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:49:52 --> Input Class Initialized
INFO - 2024-08-09 10:49:52 --> Language Class Initialized
INFO - 2024-08-09 10:49:52 --> Loader Class Initialized
INFO - 2024-08-09 10:49:52 --> Helper loaded: url_helper
INFO - 2024-08-09 10:49:52 --> Helper loaded: form_helper
INFO - 2024-08-09 10:49:52 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:49:52 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:49:52 --> Email Class Initialized
INFO - 2024-08-09 10:49:52 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:49:52 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:49:52 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:49:52 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:49:52 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:49:52 --> Controller Class Initialized
ERROR - 2024-08-09 10:49:52 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 76
ERROR - 2024-08-09 10:49:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 77
INFO - 2024-08-09 10:49:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:49:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:49:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:49:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:49:52 --> Final output sent to browser
DEBUG - 2024-08-09 10:49:52 --> Total execution time: 0.1318
INFO - 2024-08-09 10:49:53 --> Config Class Initialized
INFO - 2024-08-09 10:49:53 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:49:53 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:49:53 --> Utf8 Class Initialized
INFO - 2024-08-09 10:49:53 --> URI Class Initialized
INFO - 2024-08-09 10:49:53 --> Router Class Initialized
INFO - 2024-08-09 10:49:53 --> Output Class Initialized
INFO - 2024-08-09 10:49:53 --> Security Class Initialized
DEBUG - 2024-08-09 10:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:49:53 --> Input Class Initialized
INFO - 2024-08-09 10:49:53 --> Language Class Initialized
INFO - 2024-08-09 10:49:53 --> Loader Class Initialized
INFO - 2024-08-09 10:49:53 --> Config Class Initialized
INFO - 2024-08-09 10:49:53 --> Helper loaded: url_helper
INFO - 2024-08-09 10:49:53 --> Hooks Class Initialized
INFO - 2024-08-09 10:49:53 --> Helper loaded: form_helper
INFO - 2024-08-09 10:49:53 --> Helper loaded: funciones_helper
DEBUG - 2024-08-09 10:49:53 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:49:53 --> Utf8 Class Initialized
INFO - 2024-08-09 10:49:53 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:49:53 --> Email Class Initialized
INFO - 2024-08-09 10:49:53 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:49:53 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:49:53 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:49:53 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:49:53 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:49:53 --> Controller Class Initialized
ERROR - 2024-08-09 10:49:53 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 76
ERROR - 2024-08-09 10:49:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 77
INFO - 2024-08-09 10:49:53 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:49:53 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:49:53 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:49:53 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:49:53 --> Final output sent to browser
DEBUG - 2024-08-09 10:49:53 --> Total execution time: 0.1297
INFO - 2024-08-09 10:50:01 --> Config Class Initialized
INFO - 2024-08-09 10:50:01 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:50:01 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:50:01 --> Utf8 Class Initialized
INFO - 2024-08-09 10:50:01 --> URI Class Initialized
INFO - 2024-08-09 10:50:01 --> Router Class Initialized
INFO - 2024-08-09 10:50:01 --> Output Class Initialized
INFO - 2024-08-09 10:50:01 --> Security Class Initialized
DEBUG - 2024-08-09 10:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:50:01 --> Input Class Initialized
INFO - 2024-08-09 10:50:01 --> Language Class Initialized
INFO - 2024-08-09 10:50:01 --> Loader Class Initialized
INFO - 2024-08-09 10:50:01 --> Helper loaded: url_helper
INFO - 2024-08-09 10:50:01 --> Helper loaded: form_helper
INFO - 2024-08-09 10:50:01 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:50:01 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:50:01 --> Email Class Initialized
INFO - 2024-08-09 10:50:01 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:50:01 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:50:01 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:50:01 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:50:01 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:50:01 --> Controller Class Initialized
ERROR - 2024-08-09 10:50:01 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 76
ERROR - 2024-08-09 10:50:01 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 77
INFO - 2024-08-09 10:50:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:50:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:50:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:50:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:50:01 --> Final output sent to browser
DEBUG - 2024-08-09 10:50:01 --> Total execution time: 0.1033
INFO - 2024-08-09 10:50:01 --> Config Class Initialized
INFO - 2024-08-09 10:50:01 --> Config Class Initialized
INFO - 2024-08-09 10:50:01 --> Hooks Class Initialized
INFO - 2024-08-09 10:50:01 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 10:50:01 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:50:01 --> Utf8 Class Initialized
INFO - 2024-08-09 10:50:01 --> Utf8 Class Initialized
INFO - 2024-08-09 10:50:01 --> URI Class Initialized
INFO - 2024-08-09 10:50:01 --> Router Class Initialized
INFO - 2024-08-09 10:50:01 --> Output Class Initialized
INFO - 2024-08-09 10:50:01 --> Security Class Initialized
DEBUG - 2024-08-09 10:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:50:01 --> Input Class Initialized
INFO - 2024-08-09 10:50:01 --> Language Class Initialized
INFO - 2024-08-09 10:50:01 --> Loader Class Initialized
INFO - 2024-08-09 10:50:01 --> Helper loaded: url_helper
INFO - 2024-08-09 10:50:01 --> Helper loaded: form_helper
INFO - 2024-08-09 10:50:01 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:50:01 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:50:01 --> Email Class Initialized
INFO - 2024-08-09 10:50:01 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:50:01 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:50:01 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:50:01 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:50:01 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:50:01 --> Controller Class Initialized
ERROR - 2024-08-09 10:50:01 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 76
ERROR - 2024-08-09 10:50:01 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 77
INFO - 2024-08-09 10:50:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:50:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:50:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:50:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:50:01 --> Final output sent to browser
DEBUG - 2024-08-09 10:50:01 --> Total execution time: 0.1268
INFO - 2024-08-09 10:50:04 --> Config Class Initialized
INFO - 2024-08-09 10:50:04 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:50:04 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:50:04 --> Utf8 Class Initialized
INFO - 2024-08-09 10:50:04 --> URI Class Initialized
INFO - 2024-08-09 10:50:04 --> Router Class Initialized
INFO - 2024-08-09 10:50:04 --> Output Class Initialized
INFO - 2024-08-09 10:50:04 --> Security Class Initialized
DEBUG - 2024-08-09 10:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:50:04 --> Input Class Initialized
INFO - 2024-08-09 10:50:04 --> Language Class Initialized
INFO - 2024-08-09 10:50:04 --> Loader Class Initialized
INFO - 2024-08-09 10:50:04 --> Helper loaded: url_helper
INFO - 2024-08-09 10:50:04 --> Helper loaded: form_helper
INFO - 2024-08-09 10:50:04 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:50:04 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:50:04 --> Email Class Initialized
INFO - 2024-08-09 10:50:04 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:50:04 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:50:04 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:50:04 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:50:04 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:50:04 --> Controller Class Initialized
ERROR - 2024-08-09 10:50:04 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 76
ERROR - 2024-08-09 10:50:04 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 77
INFO - 2024-08-09 10:50:04 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:50:04 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:50:04 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:50:04 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:50:04 --> Final output sent to browser
DEBUG - 2024-08-09 10:50:04 --> Total execution time: 0.1047
INFO - 2024-08-09 10:50:05 --> Config Class Initialized
INFO - 2024-08-09 10:50:05 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:50:05 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:50:05 --> Utf8 Class Initialized
INFO - 2024-08-09 10:50:05 --> URI Class Initialized
INFO - 2024-08-09 10:50:05 --> Router Class Initialized
INFO - 2024-08-09 10:50:05 --> Config Class Initialized
INFO - 2024-08-09 10:50:05 --> Hooks Class Initialized
INFO - 2024-08-09 10:50:05 --> Output Class Initialized
INFO - 2024-08-09 10:50:05 --> Security Class Initialized
DEBUG - 2024-08-09 10:50:05 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:50:05 --> Utf8 Class Initialized
DEBUG - 2024-08-09 10:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:50:05 --> Input Class Initialized
INFO - 2024-08-09 10:50:05 --> Language Class Initialized
INFO - 2024-08-09 10:50:05 --> Loader Class Initialized
INFO - 2024-08-09 10:50:05 --> Helper loaded: url_helper
INFO - 2024-08-09 10:50:05 --> Helper loaded: form_helper
INFO - 2024-08-09 10:50:05 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:50:05 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:50:05 --> Email Class Initialized
INFO - 2024-08-09 10:50:05 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:50:05 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:50:05 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:50:05 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:50:05 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:50:05 --> Controller Class Initialized
ERROR - 2024-08-09 10:50:05 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 76
ERROR - 2024-08-09 10:50:05 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 77
INFO - 2024-08-09 10:50:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:50:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:50:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:50:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:50:05 --> Final output sent to browser
DEBUG - 2024-08-09 10:50:05 --> Total execution time: 0.1501
INFO - 2024-08-09 10:50:06 --> Config Class Initialized
INFO - 2024-08-09 10:50:06 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:50:06 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:50:06 --> Utf8 Class Initialized
INFO - 2024-08-09 10:50:06 --> URI Class Initialized
INFO - 2024-08-09 10:50:06 --> Router Class Initialized
INFO - 2024-08-09 10:50:06 --> Output Class Initialized
INFO - 2024-08-09 10:50:06 --> Security Class Initialized
DEBUG - 2024-08-09 10:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:50:06 --> Input Class Initialized
INFO - 2024-08-09 10:50:06 --> Language Class Initialized
INFO - 2024-08-09 10:50:06 --> Loader Class Initialized
INFO - 2024-08-09 10:50:06 --> Helper loaded: url_helper
INFO - 2024-08-09 10:50:06 --> Helper loaded: form_helper
INFO - 2024-08-09 10:50:06 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:50:06 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:50:06 --> Email Class Initialized
INFO - 2024-08-09 10:50:06 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:50:06 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:50:06 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:50:06 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:50:06 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:50:06 --> Controller Class Initialized
INFO - 2024-08-09 10:50:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:50:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:50:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:50:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:50:06 --> Final output sent to browser
DEBUG - 2024-08-09 10:50:06 --> Total execution time: 0.1077
INFO - 2024-08-09 10:50:07 --> Config Class Initialized
INFO - 2024-08-09 10:50:07 --> Config Class Initialized
INFO - 2024-08-09 10:50:07 --> Hooks Class Initialized
INFO - 2024-08-09 10:50:07 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:50:07 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:50:07 --> Utf8 Class Initialized
DEBUG - 2024-08-09 10:50:07 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:50:07 --> Utf8 Class Initialized
INFO - 2024-08-09 10:50:07 --> URI Class Initialized
INFO - 2024-08-09 10:50:07 --> Router Class Initialized
INFO - 2024-08-09 10:50:07 --> Output Class Initialized
INFO - 2024-08-09 10:50:07 --> Security Class Initialized
DEBUG - 2024-08-09 10:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:50:07 --> Input Class Initialized
INFO - 2024-08-09 10:50:07 --> Language Class Initialized
INFO - 2024-08-09 10:50:07 --> Loader Class Initialized
INFO - 2024-08-09 10:50:07 --> Helper loaded: url_helper
INFO - 2024-08-09 10:50:07 --> Helper loaded: form_helper
INFO - 2024-08-09 10:50:07 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:50:07 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:50:07 --> Email Class Initialized
INFO - 2024-08-09 10:50:07 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:50:07 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:50:07 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:50:07 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:50:07 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:50:07 --> Controller Class Initialized
INFO - 2024-08-09 10:50:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:50:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:50:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 10:50:07 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:50:07 --> Final output sent to browser
DEBUG - 2024-08-09 10:50:07 --> Total execution time: 0.1265
INFO - 2024-08-09 10:50:09 --> Config Class Initialized
INFO - 2024-08-09 10:50:09 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:50:09 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:50:09 --> Utf8 Class Initialized
INFO - 2024-08-09 10:50:09 --> URI Class Initialized
INFO - 2024-08-09 10:50:09 --> Router Class Initialized
INFO - 2024-08-09 10:50:09 --> Output Class Initialized
INFO - 2024-08-09 10:50:09 --> Security Class Initialized
DEBUG - 2024-08-09 10:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:50:09 --> Input Class Initialized
INFO - 2024-08-09 10:50:09 --> Language Class Initialized
INFO - 2024-08-09 10:50:09 --> Loader Class Initialized
INFO - 2024-08-09 10:50:09 --> Helper loaded: url_helper
INFO - 2024-08-09 10:50:09 --> Helper loaded: form_helper
INFO - 2024-08-09 10:50:09 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:50:09 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:50:09 --> Email Class Initialized
INFO - 2024-08-09 10:50:09 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:50:09 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:50:09 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:50:09 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:50:09 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:50:09 --> Controller Class Initialized
ERROR - 2024-08-09 10:50:09 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 76
ERROR - 2024-08-09 10:50:09 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 77
INFO - 2024-08-09 10:50:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:50:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:50:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:50:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:50:09 --> Final output sent to browser
DEBUG - 2024-08-09 10:50:09 --> Total execution time: 0.0990
INFO - 2024-08-09 10:50:09 --> Config Class Initialized
INFO - 2024-08-09 10:50:09 --> Config Class Initialized
INFO - 2024-08-09 10:50:09 --> Hooks Class Initialized
INFO - 2024-08-09 10:50:09 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:50:09 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 10:50:09 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:50:09 --> Utf8 Class Initialized
INFO - 2024-08-09 10:50:09 --> Utf8 Class Initialized
INFO - 2024-08-09 10:50:09 --> URI Class Initialized
INFO - 2024-08-09 10:50:09 --> Router Class Initialized
INFO - 2024-08-09 10:50:09 --> Output Class Initialized
INFO - 2024-08-09 10:50:09 --> Security Class Initialized
DEBUG - 2024-08-09 10:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:50:09 --> Input Class Initialized
INFO - 2024-08-09 10:50:09 --> Language Class Initialized
INFO - 2024-08-09 10:50:09 --> Loader Class Initialized
INFO - 2024-08-09 10:50:09 --> Helper loaded: url_helper
INFO - 2024-08-09 10:50:09 --> Helper loaded: form_helper
INFO - 2024-08-09 10:50:09 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:50:09 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:50:09 --> Email Class Initialized
INFO - 2024-08-09 10:50:09 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:50:09 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:50:09 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:50:09 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:50:09 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:50:09 --> Controller Class Initialized
ERROR - 2024-08-09 10:50:09 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 76
ERROR - 2024-08-09 10:50:09 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 77
INFO - 2024-08-09 10:50:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:50:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:50:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:50:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:50:09 --> Final output sent to browser
DEBUG - 2024-08-09 10:50:09 --> Total execution time: 0.1241
INFO - 2024-08-09 10:55:39 --> Config Class Initialized
INFO - 2024-08-09 10:55:39 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:55:39 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:55:39 --> Utf8 Class Initialized
INFO - 2024-08-09 10:55:39 --> URI Class Initialized
INFO - 2024-08-09 10:55:39 --> Router Class Initialized
INFO - 2024-08-09 10:55:39 --> Output Class Initialized
INFO - 2024-08-09 10:55:39 --> Security Class Initialized
DEBUG - 2024-08-09 10:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:55:39 --> Input Class Initialized
INFO - 2024-08-09 10:55:39 --> Language Class Initialized
INFO - 2024-08-09 10:55:39 --> Loader Class Initialized
INFO - 2024-08-09 10:55:39 --> Helper loaded: url_helper
INFO - 2024-08-09 10:55:39 --> Helper loaded: form_helper
INFO - 2024-08-09 10:55:39 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:55:39 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:55:39 --> Email Class Initialized
INFO - 2024-08-09 10:55:39 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:55:39 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:55:39 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:55:39 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:55:39 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:55:39 --> Controller Class Initialized
INFO - 2024-08-09 10:55:39 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:55:39 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:55:39 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:55:39 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:55:39 --> Final output sent to browser
DEBUG - 2024-08-09 10:55:39 --> Total execution time: 0.1726
INFO - 2024-08-09 10:55:40 --> Config Class Initialized
INFO - 2024-08-09 10:55:40 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:55:40 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:55:40 --> Utf8 Class Initialized
INFO - 2024-08-09 10:55:40 --> URI Class Initialized
INFO - 2024-08-09 10:55:40 --> Router Class Initialized
INFO - 2024-08-09 10:55:40 --> Output Class Initialized
INFO - 2024-08-09 10:55:40 --> Security Class Initialized
DEBUG - 2024-08-09 10:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:55:40 --> Input Class Initialized
INFO - 2024-08-09 10:55:40 --> Language Class Initialized
INFO - 2024-08-09 10:55:40 --> Config Class Initialized
INFO - 2024-08-09 10:55:40 --> Hooks Class Initialized
INFO - 2024-08-09 10:55:40 --> Loader Class Initialized
DEBUG - 2024-08-09 10:55:40 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:55:40 --> Utf8 Class Initialized
INFO - 2024-08-09 10:55:40 --> Helper loaded: url_helper
INFO - 2024-08-09 10:55:40 --> Helper loaded: form_helper
INFO - 2024-08-09 10:55:40 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:55:40 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:55:40 --> Email Class Initialized
INFO - 2024-08-09 10:55:40 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:55:40 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:55:40 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:55:40 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:55:40 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:55:40 --> Controller Class Initialized
INFO - 2024-08-09 10:55:40 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:55:40 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:55:40 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:55:40 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:55:40 --> Final output sent to browser
DEBUG - 2024-08-09 10:55:40 --> Total execution time: 0.1471
INFO - 2024-08-09 10:55:47 --> Config Class Initialized
INFO - 2024-08-09 10:55:47 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:55:47 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:55:47 --> Utf8 Class Initialized
INFO - 2024-08-09 10:55:47 --> URI Class Initialized
INFO - 2024-08-09 10:55:47 --> Router Class Initialized
INFO - 2024-08-09 10:55:47 --> Output Class Initialized
INFO - 2024-08-09 10:55:47 --> Security Class Initialized
DEBUG - 2024-08-09 10:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:55:47 --> Input Class Initialized
INFO - 2024-08-09 10:55:47 --> Language Class Initialized
INFO - 2024-08-09 10:55:47 --> Loader Class Initialized
INFO - 2024-08-09 10:55:47 --> Helper loaded: url_helper
INFO - 2024-08-09 10:55:47 --> Helper loaded: form_helper
INFO - 2024-08-09 10:55:47 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:55:47 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:55:47 --> Email Class Initialized
INFO - 2024-08-09 10:55:47 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:55:47 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:55:47 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:55:47 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:55:47 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:55:47 --> Controller Class Initialized
INFO - 2024-08-09 10:55:47 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:55:47 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:55:47 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:55:47 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:55:47 --> Final output sent to browser
DEBUG - 2024-08-09 10:55:47 --> Total execution time: 0.1313
INFO - 2024-08-09 10:55:48 --> Config Class Initialized
INFO - 2024-08-09 10:55:48 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:55:48 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:55:48 --> Utf8 Class Initialized
INFO - 2024-08-09 10:55:48 --> URI Class Initialized
INFO - 2024-08-09 10:55:48 --> Router Class Initialized
INFO - 2024-08-09 10:55:48 --> Config Class Initialized
INFO - 2024-08-09 10:55:48 --> Output Class Initialized
INFO - 2024-08-09 10:55:48 --> Hooks Class Initialized
INFO - 2024-08-09 10:55:48 --> Security Class Initialized
DEBUG - 2024-08-09 10:55:48 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 10:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:55:48 --> Utf8 Class Initialized
INFO - 2024-08-09 10:55:48 --> Input Class Initialized
INFO - 2024-08-09 10:55:48 --> Language Class Initialized
INFO - 2024-08-09 10:55:48 --> Loader Class Initialized
INFO - 2024-08-09 10:55:48 --> Helper loaded: url_helper
INFO - 2024-08-09 10:55:48 --> Helper loaded: form_helper
INFO - 2024-08-09 10:55:48 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:55:48 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:55:48 --> Email Class Initialized
INFO - 2024-08-09 10:55:48 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:55:48 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:55:48 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:55:48 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:55:48 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:55:48 --> Controller Class Initialized
INFO - 2024-08-09 10:55:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:55:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:55:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:55:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:55:48 --> Final output sent to browser
DEBUG - 2024-08-09 10:55:48 --> Total execution time: 0.1794
INFO - 2024-08-09 10:55:51 --> Config Class Initialized
INFO - 2024-08-09 10:55:51 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:55:51 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:55:51 --> Utf8 Class Initialized
INFO - 2024-08-09 10:55:51 --> URI Class Initialized
INFO - 2024-08-09 10:55:51 --> Router Class Initialized
INFO - 2024-08-09 10:55:51 --> Output Class Initialized
INFO - 2024-08-09 10:55:51 --> Security Class Initialized
DEBUG - 2024-08-09 10:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:55:51 --> Input Class Initialized
INFO - 2024-08-09 10:55:51 --> Language Class Initialized
INFO - 2024-08-09 10:55:51 --> Loader Class Initialized
INFO - 2024-08-09 10:55:51 --> Helper loaded: url_helper
INFO - 2024-08-09 10:55:51 --> Helper loaded: form_helper
INFO - 2024-08-09 10:55:51 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:55:51 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:55:51 --> Email Class Initialized
INFO - 2024-08-09 10:55:51 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:55:51 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:55:51 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:55:51 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:55:51 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:55:51 --> Controller Class Initialized
INFO - 2024-08-09 10:55:51 --> Config Class Initialized
INFO - 2024-08-09 10:55:51 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:55:51 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:55:51 --> Utf8 Class Initialized
INFO - 2024-08-09 10:55:51 --> URI Class Initialized
INFO - 2024-08-09 10:55:51 --> Router Class Initialized
INFO - 2024-08-09 10:55:51 --> Output Class Initialized
INFO - 2024-08-09 10:55:51 --> Security Class Initialized
DEBUG - 2024-08-09 10:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:55:51 --> Input Class Initialized
INFO - 2024-08-09 10:55:51 --> Language Class Initialized
INFO - 2024-08-09 10:55:51 --> Loader Class Initialized
INFO - 2024-08-09 10:55:51 --> Helper loaded: url_helper
INFO - 2024-08-09 10:55:51 --> Helper loaded: form_helper
INFO - 2024-08-09 10:55:51 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:55:51 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:55:51 --> Email Class Initialized
INFO - 2024-08-09 10:55:51 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:55:51 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:55:51 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:55:51 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:55:51 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:55:51 --> Controller Class Initialized
INFO - 2024-08-09 10:55:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:55:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:55:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:55:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:55:52 --> Final output sent to browser
DEBUG - 2024-08-09 10:55:52 --> Total execution time: 0.0978
INFO - 2024-08-09 10:55:52 --> Config Class Initialized
INFO - 2024-08-09 10:55:52 --> Config Class Initialized
INFO - 2024-08-09 10:55:52 --> Hooks Class Initialized
INFO - 2024-08-09 10:55:52 --> Hooks Class Initialized
DEBUG - 2024-08-09 10:55:52 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:55:52 --> Utf8 Class Initialized
DEBUG - 2024-08-09 10:55:52 --> UTF-8 Support Enabled
INFO - 2024-08-09 10:55:52 --> Utf8 Class Initialized
INFO - 2024-08-09 10:55:52 --> URI Class Initialized
INFO - 2024-08-09 10:55:52 --> Router Class Initialized
INFO - 2024-08-09 10:55:52 --> Output Class Initialized
INFO - 2024-08-09 10:55:52 --> Security Class Initialized
DEBUG - 2024-08-09 10:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 10:55:52 --> Input Class Initialized
INFO - 2024-08-09 10:55:52 --> Language Class Initialized
INFO - 2024-08-09 10:55:52 --> Loader Class Initialized
INFO - 2024-08-09 10:55:52 --> Helper loaded: url_helper
INFO - 2024-08-09 10:55:52 --> Helper loaded: form_helper
INFO - 2024-08-09 10:55:52 --> Helper loaded: funciones_helper
INFO - 2024-08-09 10:55:52 --> Database Driver Class Initialized
DEBUG - 2024-08-09 10:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 10:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 10:55:52 --> Email Class Initialized
INFO - 2024-08-09 10:55:52 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 10:55:52 --> Model "Pais_model" initialized
INFO - 2024-08-09 10:55:52 --> Model "Libro_model" initialized
INFO - 2024-08-09 10:55:52 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 10:55:52 --> Model "Usuario_model" initialized
INFO - 2024-08-09 10:55:52 --> Controller Class Initialized
INFO - 2024-08-09 10:55:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 10:55:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 10:55:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 10:55:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 10:55:52 --> Final output sent to browser
DEBUG - 2024-08-09 10:55:52 --> Total execution time: 0.1038
INFO - 2024-08-09 11:02:24 --> Config Class Initialized
INFO - 2024-08-09 11:02:24 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:02:24 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:02:24 --> Utf8 Class Initialized
INFO - 2024-08-09 11:02:24 --> URI Class Initialized
INFO - 2024-08-09 11:02:24 --> Router Class Initialized
INFO - 2024-08-09 11:02:24 --> Output Class Initialized
INFO - 2024-08-09 11:02:24 --> Security Class Initialized
DEBUG - 2024-08-09 11:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:02:24 --> Input Class Initialized
INFO - 2024-08-09 11:02:24 --> Language Class Initialized
INFO - 2024-08-09 11:02:24 --> Loader Class Initialized
INFO - 2024-08-09 11:02:24 --> Helper loaded: url_helper
INFO - 2024-08-09 11:02:24 --> Helper loaded: form_helper
INFO - 2024-08-09 11:02:24 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:02:24 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:02:24 --> Email Class Initialized
INFO - 2024-08-09 11:02:24 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:02:24 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:02:24 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:02:24 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:02:24 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:02:24 --> Controller Class Initialized
INFO - 2024-08-09 11:02:24 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:02:24 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 11:02:24 --> Severity: Warning --> Undefined array key "idUsuario" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 38
ERROR - 2024-08-09 11:02:24 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 43
ERROR - 2024-08-09 11:02:24 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 49
ERROR - 2024-08-09 11:02:24 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 55
ERROR - 2024-08-09 11:02:24 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 61
ERROR - 2024-08-09 11:02:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 67
ERROR - 2024-08-09 11:02:24 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 74
ERROR - 2024-08-09 11:02:24 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 75
ERROR - 2024-08-09 11:02:24 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 76
ERROR - 2024-08-09 11:02:24 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 83
ERROR - 2024-08-09 11:02:24 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 90
ERROR - 2024-08-09 11:02:24 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 94
INFO - 2024-08-09 11:02:24 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:02:24 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:02:24 --> Final output sent to browser
DEBUG - 2024-08-09 11:02:24 --> Total execution time: 0.1557
INFO - 2024-08-09 11:02:25 --> Config Class Initialized
INFO - 2024-08-09 11:02:25 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:02:25 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:02:25 --> Utf8 Class Initialized
INFO - 2024-08-09 11:02:25 --> URI Class Initialized
INFO - 2024-08-09 11:02:25 --> Router Class Initialized
INFO - 2024-08-09 11:02:25 --> Config Class Initialized
INFO - 2024-08-09 11:02:25 --> Output Class Initialized
INFO - 2024-08-09 11:02:25 --> Hooks Class Initialized
INFO - 2024-08-09 11:02:25 --> Security Class Initialized
DEBUG - 2024-08-09 11:02:25 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 11:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:02:25 --> Utf8 Class Initialized
INFO - 2024-08-09 11:02:25 --> Input Class Initialized
INFO - 2024-08-09 11:02:25 --> Language Class Initialized
INFO - 2024-08-09 11:02:25 --> Loader Class Initialized
INFO - 2024-08-09 11:02:25 --> Helper loaded: url_helper
INFO - 2024-08-09 11:02:25 --> Helper loaded: form_helper
INFO - 2024-08-09 11:02:25 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:02:25 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:02:25 --> Email Class Initialized
INFO - 2024-08-09 11:02:25 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:02:25 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:02:25 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:02:25 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:02:25 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:02:25 --> Controller Class Initialized
INFO - 2024-08-09 11:02:25 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:02:25 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 11:02:25 --> Severity: Warning --> Undefined array key "idUsuario" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 38
ERROR - 2024-08-09 11:02:25 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 43
ERROR - 2024-08-09 11:02:25 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 49
ERROR - 2024-08-09 11:02:25 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 55
ERROR - 2024-08-09 11:02:25 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 61
ERROR - 2024-08-09 11:02:25 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 67
ERROR - 2024-08-09 11:02:25 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 74
ERROR - 2024-08-09 11:02:25 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 75
ERROR - 2024-08-09 11:02:25 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 76
ERROR - 2024-08-09 11:02:25 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 83
ERROR - 2024-08-09 11:02:25 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 90
ERROR - 2024-08-09 11:02:25 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 94
INFO - 2024-08-09 11:02:25 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:02:25 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:02:25 --> Final output sent to browser
DEBUG - 2024-08-09 11:02:25 --> Total execution time: 0.1530
INFO - 2024-08-09 11:03:57 --> Config Class Initialized
INFO - 2024-08-09 11:03:57 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:03:57 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:03:57 --> Utf8 Class Initialized
INFO - 2024-08-09 11:03:57 --> URI Class Initialized
INFO - 2024-08-09 11:03:57 --> Router Class Initialized
INFO - 2024-08-09 11:03:57 --> Output Class Initialized
INFO - 2024-08-09 11:03:57 --> Security Class Initialized
DEBUG - 2024-08-09 11:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:03:57 --> Input Class Initialized
INFO - 2024-08-09 11:03:57 --> Language Class Initialized
INFO - 2024-08-09 11:03:57 --> Loader Class Initialized
INFO - 2024-08-09 11:03:57 --> Helper loaded: url_helper
INFO - 2024-08-09 11:03:57 --> Helper loaded: form_helper
INFO - 2024-08-09 11:03:57 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:03:57 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:03:57 --> Email Class Initialized
INFO - 2024-08-09 11:03:57 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:03:57 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:03:57 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:03:57 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:03:57 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:03:57 --> Controller Class Initialized
INFO - 2024-08-09 11:03:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:03:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "idUsuario" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 38
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 43
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 49
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 55
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 61
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 67
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 74
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 75
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 76
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 83
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 90
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 94
INFO - 2024-08-09 11:03:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:03:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:03:57 --> Final output sent to browser
DEBUG - 2024-08-09 11:03:57 --> Total execution time: 0.1793
INFO - 2024-08-09 11:03:57 --> Config Class Initialized
INFO - 2024-08-09 11:03:57 --> Hooks Class Initialized
INFO - 2024-08-09 11:03:57 --> Config Class Initialized
INFO - 2024-08-09 11:03:57 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:03:57 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:03:57 --> Utf8 Class Initialized
INFO - 2024-08-09 11:03:57 --> URI Class Initialized
INFO - 2024-08-09 11:03:57 --> Router Class Initialized
DEBUG - 2024-08-09 11:03:57 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:03:57 --> Utf8 Class Initialized
INFO - 2024-08-09 11:03:57 --> Output Class Initialized
INFO - 2024-08-09 11:03:57 --> Security Class Initialized
DEBUG - 2024-08-09 11:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:03:57 --> Input Class Initialized
INFO - 2024-08-09 11:03:57 --> Language Class Initialized
INFO - 2024-08-09 11:03:57 --> Loader Class Initialized
INFO - 2024-08-09 11:03:57 --> Helper loaded: url_helper
INFO - 2024-08-09 11:03:57 --> Helper loaded: form_helper
INFO - 2024-08-09 11:03:57 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:03:57 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:03:57 --> Email Class Initialized
INFO - 2024-08-09 11:03:57 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:03:57 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:03:57 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:03:57 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:03:57 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:03:57 --> Controller Class Initialized
INFO - 2024-08-09 11:03:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:03:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "idUsuario" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 38
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 43
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 49
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 55
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 61
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 67
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 74
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 75
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 76
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 83
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 90
ERROR - 2024-08-09 11:03:57 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 94
INFO - 2024-08-09 11:03:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:03:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:03:57 --> Final output sent to browser
DEBUG - 2024-08-09 11:03:57 --> Total execution time: 0.1611
INFO - 2024-08-09 11:04:00 --> Config Class Initialized
INFO - 2024-08-09 11:04:00 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:04:00 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:04:00 --> Utf8 Class Initialized
INFO - 2024-08-09 11:04:00 --> URI Class Initialized
INFO - 2024-08-09 11:04:00 --> Router Class Initialized
INFO - 2024-08-09 11:04:00 --> Output Class Initialized
INFO - 2024-08-09 11:04:00 --> Security Class Initialized
DEBUG - 2024-08-09 11:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:04:00 --> Input Class Initialized
INFO - 2024-08-09 11:04:00 --> Language Class Initialized
INFO - 2024-08-09 11:04:00 --> Loader Class Initialized
INFO - 2024-08-09 11:04:00 --> Helper loaded: url_helper
INFO - 2024-08-09 11:04:00 --> Helper loaded: form_helper
INFO - 2024-08-09 11:04:00 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:04:00 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:04:00 --> Email Class Initialized
INFO - 2024-08-09 11:04:00 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:04:00 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:04:00 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:04:00 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:04:00 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:04:00 --> Controller Class Initialized
INFO - 2024-08-09 11:04:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:04:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:04:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:04:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:04:00 --> Final output sent to browser
DEBUG - 2024-08-09 11:04:00 --> Total execution time: 0.1011
INFO - 2024-08-09 11:04:00 --> Config Class Initialized
INFO - 2024-08-09 11:04:00 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:04:00 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:04:00 --> Utf8 Class Initialized
INFO - 2024-08-09 11:04:00 --> URI Class Initialized
INFO - 2024-08-09 11:04:00 --> Router Class Initialized
INFO - 2024-08-09 11:04:00 --> Output Class Initialized
INFO - 2024-08-09 11:04:00 --> Security Class Initialized
INFO - 2024-08-09 11:04:00 --> Config Class Initialized
INFO - 2024-08-09 11:04:00 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2024-08-09 11:04:00 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:04:00 --> Input Class Initialized
INFO - 2024-08-09 11:04:00 --> Utf8 Class Initialized
INFO - 2024-08-09 11:04:00 --> Language Class Initialized
INFO - 2024-08-09 11:04:00 --> Loader Class Initialized
INFO - 2024-08-09 11:04:00 --> Helper loaded: url_helper
INFO - 2024-08-09 11:04:00 --> Helper loaded: form_helper
INFO - 2024-08-09 11:04:00 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:04:00 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:04:00 --> Email Class Initialized
INFO - 2024-08-09 11:04:00 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:04:00 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:04:00 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:04:00 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:04:00 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:04:00 --> Controller Class Initialized
INFO - 2024-08-09 11:04:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:04:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:04:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:04:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:04:00 --> Final output sent to browser
DEBUG - 2024-08-09 11:04:00 --> Total execution time: 0.1284
INFO - 2024-08-09 11:04:03 --> Config Class Initialized
INFO - 2024-08-09 11:04:03 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:04:03 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:04:03 --> Utf8 Class Initialized
INFO - 2024-08-09 11:04:03 --> URI Class Initialized
INFO - 2024-08-09 11:04:03 --> Router Class Initialized
INFO - 2024-08-09 11:04:03 --> Output Class Initialized
INFO - 2024-08-09 11:04:03 --> Security Class Initialized
DEBUG - 2024-08-09 11:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:04:03 --> Input Class Initialized
INFO - 2024-08-09 11:04:03 --> Language Class Initialized
INFO - 2024-08-09 11:04:03 --> Loader Class Initialized
INFO - 2024-08-09 11:04:03 --> Helper loaded: url_helper
INFO - 2024-08-09 11:04:03 --> Helper loaded: form_helper
INFO - 2024-08-09 11:04:03 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:04:03 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:04:03 --> Email Class Initialized
INFO - 2024-08-09 11:04:03 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:04:03 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:04:03 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:04:03 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:04:03 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:04:03 --> Controller Class Initialized
INFO - 2024-08-09 11:04:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:04:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "idUsuario" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 38
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 43
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 49
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 55
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 61
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 67
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 74
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 75
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 76
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 83
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 90
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 94
INFO - 2024-08-09 11:04:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:04:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:04:03 --> Final output sent to browser
DEBUG - 2024-08-09 11:04:03 --> Total execution time: 0.1202
INFO - 2024-08-09 11:04:03 --> Config Class Initialized
INFO - 2024-08-09 11:04:03 --> Hooks Class Initialized
INFO - 2024-08-09 11:04:03 --> Config Class Initialized
INFO - 2024-08-09 11:04:03 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:04:03 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:04:03 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:04:03 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:04:03 --> Utf8 Class Initialized
INFO - 2024-08-09 11:04:03 --> URI Class Initialized
INFO - 2024-08-09 11:04:03 --> Router Class Initialized
INFO - 2024-08-09 11:04:03 --> Output Class Initialized
INFO - 2024-08-09 11:04:03 --> Security Class Initialized
DEBUG - 2024-08-09 11:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:04:03 --> Input Class Initialized
INFO - 2024-08-09 11:04:03 --> Language Class Initialized
INFO - 2024-08-09 11:04:03 --> Loader Class Initialized
INFO - 2024-08-09 11:04:03 --> Helper loaded: url_helper
INFO - 2024-08-09 11:04:03 --> Helper loaded: form_helper
INFO - 2024-08-09 11:04:03 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:04:03 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:04:03 --> Email Class Initialized
INFO - 2024-08-09 11:04:03 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:04:03 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:04:03 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:04:03 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:04:03 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:04:03 --> Controller Class Initialized
INFO - 2024-08-09 11:04:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:04:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "idUsuario" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 38
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 43
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 49
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 55
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 61
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 67
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 74
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 75
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 76
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 83
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 90
ERROR - 2024-08-09 11:04:03 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 94
INFO - 2024-08-09 11:04:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:04:03 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:04:03 --> Final output sent to browser
DEBUG - 2024-08-09 11:04:03 --> Total execution time: 0.1355
INFO - 2024-08-09 11:06:11 --> Config Class Initialized
INFO - 2024-08-09 11:06:11 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:06:11 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:06:11 --> Utf8 Class Initialized
INFO - 2024-08-09 11:06:11 --> URI Class Initialized
INFO - 2024-08-09 11:06:11 --> Router Class Initialized
INFO - 2024-08-09 11:06:11 --> Output Class Initialized
INFO - 2024-08-09 11:06:11 --> Security Class Initialized
DEBUG - 2024-08-09 11:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:06:11 --> Input Class Initialized
INFO - 2024-08-09 11:06:11 --> Language Class Initialized
INFO - 2024-08-09 11:06:11 --> Loader Class Initialized
INFO - 2024-08-09 11:06:11 --> Helper loaded: url_helper
INFO - 2024-08-09 11:06:11 --> Helper loaded: form_helper
INFO - 2024-08-09 11:06:11 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:06:11 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:06:11 --> Email Class Initialized
INFO - 2024-08-09 11:06:11 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:06:11 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:06:11 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:06:11 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:06:11 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:06:11 --> Controller Class Initialized
INFO - 2024-08-09 11:06:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:06:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 11:06:11 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 43
ERROR - 2024-08-09 11:06:11 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 49
ERROR - 2024-08-09 11:06:11 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 55
ERROR - 2024-08-09 11:06:11 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 61
ERROR - 2024-08-09 11:06:11 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 67
ERROR - 2024-08-09 11:06:11 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 74
ERROR - 2024-08-09 11:06:11 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 75
ERROR - 2024-08-09 11:06:11 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 76
ERROR - 2024-08-09 11:06:11 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 83
ERROR - 2024-08-09 11:06:11 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 90
ERROR - 2024-08-09 11:06:11 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 94
INFO - 2024-08-09 11:06:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:06:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:06:11 --> Final output sent to browser
DEBUG - 2024-08-09 11:06:11 --> Total execution time: 0.2009
INFO - 2024-08-09 11:06:12 --> Config Class Initialized
INFO - 2024-08-09 11:06:12 --> Hooks Class Initialized
INFO - 2024-08-09 11:06:12 --> Config Class Initialized
INFO - 2024-08-09 11:06:12 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:06:12 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:06:12 --> Utf8 Class Initialized
INFO - 2024-08-09 11:06:12 --> URI Class Initialized
DEBUG - 2024-08-09 11:06:12 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:06:12 --> Utf8 Class Initialized
INFO - 2024-08-09 11:06:12 --> Router Class Initialized
INFO - 2024-08-09 11:06:12 --> Output Class Initialized
INFO - 2024-08-09 11:06:12 --> Security Class Initialized
DEBUG - 2024-08-09 11:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:06:12 --> Input Class Initialized
INFO - 2024-08-09 11:06:12 --> Language Class Initialized
INFO - 2024-08-09 11:06:12 --> Loader Class Initialized
INFO - 2024-08-09 11:06:12 --> Helper loaded: url_helper
INFO - 2024-08-09 11:06:12 --> Helper loaded: form_helper
INFO - 2024-08-09 11:06:12 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:06:12 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:06:12 --> Email Class Initialized
INFO - 2024-08-09 11:06:12 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:06:12 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:06:12 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:06:12 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:06:12 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:06:12 --> Controller Class Initialized
INFO - 2024-08-09 11:06:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:06:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 11:06:12 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 43
ERROR - 2024-08-09 11:06:12 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 49
ERROR - 2024-08-09 11:06:12 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 55
ERROR - 2024-08-09 11:06:12 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 61
ERROR - 2024-08-09 11:06:12 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 67
ERROR - 2024-08-09 11:06:12 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 74
ERROR - 2024-08-09 11:06:12 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 75
ERROR - 2024-08-09 11:06:12 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 76
ERROR - 2024-08-09 11:06:12 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 83
ERROR - 2024-08-09 11:06:12 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 90
ERROR - 2024-08-09 11:06:12 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 94
INFO - 2024-08-09 11:06:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:06:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:06:12 --> Final output sent to browser
DEBUG - 2024-08-09 11:06:12 --> Total execution time: 0.1441
INFO - 2024-08-09 11:09:12 --> Config Class Initialized
INFO - 2024-08-09 11:09:12 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:09:12 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:09:12 --> Utf8 Class Initialized
INFO - 2024-08-09 11:09:12 --> URI Class Initialized
INFO - 2024-08-09 11:09:12 --> Router Class Initialized
INFO - 2024-08-09 11:09:12 --> Output Class Initialized
INFO - 2024-08-09 11:09:12 --> Security Class Initialized
DEBUG - 2024-08-09 11:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:09:12 --> Input Class Initialized
INFO - 2024-08-09 11:09:12 --> Language Class Initialized
INFO - 2024-08-09 11:09:12 --> Loader Class Initialized
INFO - 2024-08-09 11:09:12 --> Helper loaded: url_helper
INFO - 2024-08-09 11:09:12 --> Helper loaded: form_helper
INFO - 2024-08-09 11:09:12 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:09:12 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:09:12 --> Email Class Initialized
INFO - 2024-08-09 11:09:12 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:09:12 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:09:12 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:09:12 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:09:12 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:09:12 --> Controller Class Initialized
INFO - 2024-08-09 11:09:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:09:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 11:09:12 --> Severity: error --> Exception: syntax error, unexpected token "endif", expecting end of file C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 109
INFO - 2024-08-09 11:09:26 --> Config Class Initialized
INFO - 2024-08-09 11:09:26 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:09:26 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:09:26 --> Utf8 Class Initialized
INFO - 2024-08-09 11:09:26 --> URI Class Initialized
INFO - 2024-08-09 11:09:26 --> Router Class Initialized
INFO - 2024-08-09 11:09:26 --> Output Class Initialized
INFO - 2024-08-09 11:09:26 --> Security Class Initialized
DEBUG - 2024-08-09 11:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:09:26 --> Input Class Initialized
INFO - 2024-08-09 11:09:26 --> Language Class Initialized
INFO - 2024-08-09 11:09:26 --> Loader Class Initialized
INFO - 2024-08-09 11:09:26 --> Helper loaded: url_helper
INFO - 2024-08-09 11:09:26 --> Helper loaded: form_helper
INFO - 2024-08-09 11:09:26 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:09:27 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:09:27 --> Email Class Initialized
INFO - 2024-08-09 11:09:27 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:09:27 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:09:27 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:09:27 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:09:27 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:09:27 --> Controller Class Initialized
INFO - 2024-08-09 11:09:27 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:09:27 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 46
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 52
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 58
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 64
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 70
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 77
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 78
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 79
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 86
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 93
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 97
INFO - 2024-08-09 11:09:27 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:09:27 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:09:27 --> Final output sent to browser
DEBUG - 2024-08-09 11:09:27 --> Total execution time: 0.2049
INFO - 2024-08-09 11:09:27 --> Config Class Initialized
INFO - 2024-08-09 11:09:27 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:09:27 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:09:27 --> Utf8 Class Initialized
INFO - 2024-08-09 11:09:27 --> Config Class Initialized
INFO - 2024-08-09 11:09:27 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:09:27 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:09:27 --> Utf8 Class Initialized
INFO - 2024-08-09 11:09:27 --> URI Class Initialized
INFO - 2024-08-09 11:09:27 --> Router Class Initialized
INFO - 2024-08-09 11:09:27 --> Output Class Initialized
INFO - 2024-08-09 11:09:27 --> Security Class Initialized
DEBUG - 2024-08-09 11:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:09:27 --> Input Class Initialized
INFO - 2024-08-09 11:09:27 --> Language Class Initialized
INFO - 2024-08-09 11:09:27 --> Loader Class Initialized
INFO - 2024-08-09 11:09:27 --> Helper loaded: url_helper
INFO - 2024-08-09 11:09:27 --> Helper loaded: form_helper
INFO - 2024-08-09 11:09:27 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:09:27 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:09:27 --> Email Class Initialized
INFO - 2024-08-09 11:09:27 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:09:27 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:09:27 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:09:27 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:09:27 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:09:27 --> Controller Class Initialized
INFO - 2024-08-09 11:09:27 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:09:27 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 46
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 52
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 58
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 64
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 70
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 77
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 78
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 79
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 86
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 93
ERROR - 2024-08-09 11:09:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 97
INFO - 2024-08-09 11:09:27 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:09:27 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:09:27 --> Final output sent to browser
DEBUG - 2024-08-09 11:09:27 --> Total execution time: 0.1591
INFO - 2024-08-09 11:10:25 --> Config Class Initialized
INFO - 2024-08-09 11:10:25 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:10:25 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:10:25 --> Utf8 Class Initialized
INFO - 2024-08-09 11:10:25 --> URI Class Initialized
INFO - 2024-08-09 11:10:25 --> Router Class Initialized
INFO - 2024-08-09 11:10:25 --> Output Class Initialized
INFO - 2024-08-09 11:10:25 --> Security Class Initialized
DEBUG - 2024-08-09 11:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:10:25 --> Input Class Initialized
INFO - 2024-08-09 11:10:25 --> Language Class Initialized
INFO - 2024-08-09 11:10:25 --> Loader Class Initialized
INFO - 2024-08-09 11:10:25 --> Helper loaded: url_helper
INFO - 2024-08-09 11:10:25 --> Helper loaded: form_helper
INFO - 2024-08-09 11:10:25 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:10:25 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:10:25 --> Email Class Initialized
INFO - 2024-08-09 11:10:25 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:10:25 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:10:25 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:10:25 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:10:25 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:10:25 --> Controller Class Initialized
INFO - 2024-08-09 11:10:25 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:10:25 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 11:10:25 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 46
ERROR - 2024-08-09 11:10:25 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 52
ERROR - 2024-08-09 11:10:25 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 58
ERROR - 2024-08-09 11:10:25 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 64
ERROR - 2024-08-09 11:10:25 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 70
ERROR - 2024-08-09 11:10:25 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 77
ERROR - 2024-08-09 11:10:25 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 78
ERROR - 2024-08-09 11:10:25 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 79
ERROR - 2024-08-09 11:10:25 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 86
ERROR - 2024-08-09 11:10:25 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 93
ERROR - 2024-08-09 11:10:25 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 97
INFO - 2024-08-09 11:10:25 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:10:25 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:10:25 --> Final output sent to browser
DEBUG - 2024-08-09 11:10:25 --> Total execution time: 0.1290
INFO - 2024-08-09 11:10:26 --> Config Class Initialized
INFO - 2024-08-09 11:10:26 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:10:26 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:10:26 --> Utf8 Class Initialized
INFO - 2024-08-09 11:10:26 --> URI Class Initialized
INFO - 2024-08-09 11:10:26 --> Router Class Initialized
INFO - 2024-08-09 11:10:26 --> Config Class Initialized
INFO - 2024-08-09 11:10:26 --> Hooks Class Initialized
INFO - 2024-08-09 11:10:26 --> Output Class Initialized
INFO - 2024-08-09 11:10:26 --> Security Class Initialized
DEBUG - 2024-08-09 11:10:26 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:10:26 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:10:26 --> Input Class Initialized
INFO - 2024-08-09 11:10:26 --> Language Class Initialized
INFO - 2024-08-09 11:10:26 --> Loader Class Initialized
INFO - 2024-08-09 11:10:26 --> Helper loaded: url_helper
INFO - 2024-08-09 11:10:26 --> Helper loaded: form_helper
INFO - 2024-08-09 11:10:26 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:10:26 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:10:26 --> Email Class Initialized
INFO - 2024-08-09 11:10:26 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:10:26 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:10:26 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:10:26 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:10:26 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:10:26 --> Controller Class Initialized
INFO - 2024-08-09 11:10:26 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:10:26 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 11:10:26 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 46
ERROR - 2024-08-09 11:10:26 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 52
ERROR - 2024-08-09 11:10:26 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 58
ERROR - 2024-08-09 11:10:26 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 64
ERROR - 2024-08-09 11:10:26 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 70
ERROR - 2024-08-09 11:10:26 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 77
ERROR - 2024-08-09 11:10:26 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 78
ERROR - 2024-08-09 11:10:26 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 79
ERROR - 2024-08-09 11:10:26 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 86
ERROR - 2024-08-09 11:10:26 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 93
ERROR - 2024-08-09 11:10:26 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 97
INFO - 2024-08-09 11:10:26 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:10:26 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:10:26 --> Final output sent to browser
DEBUG - 2024-08-09 11:10:26 --> Total execution time: 0.1383
INFO - 2024-08-09 11:10:41 --> Config Class Initialized
INFO - 2024-08-09 11:10:41 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:10:41 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:10:41 --> Utf8 Class Initialized
INFO - 2024-08-09 11:10:41 --> URI Class Initialized
INFO - 2024-08-09 11:10:41 --> Router Class Initialized
INFO - 2024-08-09 11:10:41 --> Output Class Initialized
INFO - 2024-08-09 11:10:41 --> Security Class Initialized
DEBUG - 2024-08-09 11:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:10:41 --> Input Class Initialized
INFO - 2024-08-09 11:10:41 --> Language Class Initialized
INFO - 2024-08-09 11:10:41 --> Loader Class Initialized
INFO - 2024-08-09 11:10:41 --> Helper loaded: url_helper
INFO - 2024-08-09 11:10:41 --> Helper loaded: form_helper
INFO - 2024-08-09 11:10:41 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:10:41 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:10:41 --> Email Class Initialized
INFO - 2024-08-09 11:10:41 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:10:41 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:10:41 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:10:41 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:10:41 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:10:41 --> Controller Class Initialized
INFO - 2024-08-09 11:10:41 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:10:41 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 11:10:41 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 43
ERROR - 2024-08-09 11:10:41 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 49
ERROR - 2024-08-09 11:10:41 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 55
ERROR - 2024-08-09 11:10:41 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 61
ERROR - 2024-08-09 11:10:41 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 67
ERROR - 2024-08-09 11:10:41 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 74
ERROR - 2024-08-09 11:10:41 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 75
ERROR - 2024-08-09 11:10:41 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 76
ERROR - 2024-08-09 11:10:41 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 83
ERROR - 2024-08-09 11:10:41 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 90
ERROR - 2024-08-09 11:10:41 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 94
INFO - 2024-08-09 11:10:41 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:10:41 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:10:41 --> Final output sent to browser
DEBUG - 2024-08-09 11:10:41 --> Total execution time: 0.1245
INFO - 2024-08-09 11:10:42 --> Config Class Initialized
INFO - 2024-08-09 11:10:42 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:10:42 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:10:42 --> Utf8 Class Initialized
INFO - 2024-08-09 11:10:42 --> URI Class Initialized
INFO - 2024-08-09 11:10:42 --> Router Class Initialized
INFO - 2024-08-09 11:10:42 --> Config Class Initialized
INFO - 2024-08-09 11:10:42 --> Hooks Class Initialized
INFO - 2024-08-09 11:10:42 --> Output Class Initialized
INFO - 2024-08-09 11:10:42 --> Security Class Initialized
DEBUG - 2024-08-09 11:10:42 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:10:42 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:10:42 --> Input Class Initialized
INFO - 2024-08-09 11:10:42 --> Language Class Initialized
INFO - 2024-08-09 11:10:42 --> Loader Class Initialized
INFO - 2024-08-09 11:10:42 --> Helper loaded: url_helper
INFO - 2024-08-09 11:10:42 --> Helper loaded: form_helper
INFO - 2024-08-09 11:10:42 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:10:42 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:10:42 --> Email Class Initialized
INFO - 2024-08-09 11:10:42 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:10:42 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:10:42 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:10:42 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:10:42 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:10:42 --> Controller Class Initialized
INFO - 2024-08-09 11:10:42 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:10:42 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 11:10:42 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 43
ERROR - 2024-08-09 11:10:42 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 49
ERROR - 2024-08-09 11:10:42 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 55
ERROR - 2024-08-09 11:10:42 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 61
ERROR - 2024-08-09 11:10:42 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 67
ERROR - 2024-08-09 11:10:42 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 74
ERROR - 2024-08-09 11:10:42 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 75
ERROR - 2024-08-09 11:10:42 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 76
ERROR - 2024-08-09 11:10:42 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 83
ERROR - 2024-08-09 11:10:42 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 90
ERROR - 2024-08-09 11:10:42 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 94
INFO - 2024-08-09 11:10:42 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:10:42 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:10:42 --> Final output sent to browser
DEBUG - 2024-08-09 11:10:42 --> Total execution time: 0.1594
INFO - 2024-08-09 11:11:47 --> Config Class Initialized
INFO - 2024-08-09 11:11:47 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:11:47 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:11:47 --> Utf8 Class Initialized
INFO - 2024-08-09 11:11:47 --> URI Class Initialized
INFO - 2024-08-09 11:11:47 --> Router Class Initialized
INFO - 2024-08-09 11:11:47 --> Output Class Initialized
INFO - 2024-08-09 11:11:47 --> Security Class Initialized
DEBUG - 2024-08-09 11:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:11:47 --> Input Class Initialized
INFO - 2024-08-09 11:11:47 --> Language Class Initialized
INFO - 2024-08-09 11:11:47 --> Loader Class Initialized
INFO - 2024-08-09 11:11:47 --> Helper loaded: url_helper
INFO - 2024-08-09 11:11:47 --> Helper loaded: form_helper
INFO - 2024-08-09 11:11:47 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:11:47 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:11:48 --> Email Class Initialized
INFO - 2024-08-09 11:11:48 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:11:48 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:11:48 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:11:48 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:11:48 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:11:48 --> Controller Class Initialized
ERROR - 2024-08-09 11:11:48 --> Severity: error --> Exception: Call to a member function row_array() on array C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:12:01 --> Config Class Initialized
INFO - 2024-08-09 11:12:01 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:12:01 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:12:01 --> Utf8 Class Initialized
INFO - 2024-08-09 11:12:01 --> URI Class Initialized
INFO - 2024-08-09 11:12:01 --> Router Class Initialized
INFO - 2024-08-09 11:12:01 --> Output Class Initialized
INFO - 2024-08-09 11:12:01 --> Security Class Initialized
DEBUG - 2024-08-09 11:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:12:01 --> Input Class Initialized
INFO - 2024-08-09 11:12:01 --> Language Class Initialized
INFO - 2024-08-09 11:12:01 --> Loader Class Initialized
INFO - 2024-08-09 11:12:01 --> Helper loaded: url_helper
INFO - 2024-08-09 11:12:01 --> Helper loaded: form_helper
INFO - 2024-08-09 11:12:01 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:12:01 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:12:01 --> Email Class Initialized
INFO - 2024-08-09 11:12:01 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:12:01 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:12:01 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:12:01 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:12:01 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:12:01 --> Controller Class Initialized
INFO - 2024-08-09 11:12:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:12:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "idUsuario" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 38
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 43
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 49
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 55
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 61
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 67
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 74
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 75
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 76
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 83
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 90
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 94
INFO - 2024-08-09 11:12:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:12:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:12:01 --> Final output sent to browser
DEBUG - 2024-08-09 11:12:01 --> Total execution time: 0.1182
INFO - 2024-08-09 11:12:01 --> Config Class Initialized
INFO - 2024-08-09 11:12:01 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:12:01 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:12:01 --> Utf8 Class Initialized
INFO - 2024-08-09 11:12:01 --> URI Class Initialized
INFO - 2024-08-09 11:12:01 --> Config Class Initialized
INFO - 2024-08-09 11:12:01 --> Router Class Initialized
INFO - 2024-08-09 11:12:01 --> Hooks Class Initialized
INFO - 2024-08-09 11:12:01 --> Output Class Initialized
INFO - 2024-08-09 11:12:01 --> Security Class Initialized
DEBUG - 2024-08-09 11:12:01 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:12:01 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:12:01 --> Input Class Initialized
INFO - 2024-08-09 11:12:01 --> Language Class Initialized
INFO - 2024-08-09 11:12:01 --> Loader Class Initialized
INFO - 2024-08-09 11:12:01 --> Helper loaded: url_helper
INFO - 2024-08-09 11:12:01 --> Helper loaded: form_helper
INFO - 2024-08-09 11:12:01 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:12:01 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:12:01 --> Email Class Initialized
INFO - 2024-08-09 11:12:01 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:12:01 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:12:01 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:12:01 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:12:01 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:12:01 --> Controller Class Initialized
INFO - 2024-08-09 11:12:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:12:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "idUsuario" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 38
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 43
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 49
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 55
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 61
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 67
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 74
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 75
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 76
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 83
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 90
ERROR - 2024-08-09 11:12:01 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 94
INFO - 2024-08-09 11:12:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:12:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:12:01 --> Final output sent to browser
DEBUG - 2024-08-09 11:12:01 --> Total execution time: 0.1450
INFO - 2024-08-09 11:15:57 --> Config Class Initialized
INFO - 2024-08-09 11:15:57 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:15:57 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:15:57 --> Utf8 Class Initialized
INFO - 2024-08-09 11:15:57 --> URI Class Initialized
INFO - 2024-08-09 11:15:57 --> Router Class Initialized
INFO - 2024-08-09 11:15:57 --> Output Class Initialized
INFO - 2024-08-09 11:15:57 --> Security Class Initialized
DEBUG - 2024-08-09 11:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:15:57 --> Input Class Initialized
INFO - 2024-08-09 11:15:57 --> Language Class Initialized
INFO - 2024-08-09 11:15:57 --> Loader Class Initialized
INFO - 2024-08-09 11:15:57 --> Helper loaded: url_helper
INFO - 2024-08-09 11:15:57 --> Helper loaded: form_helper
INFO - 2024-08-09 11:15:57 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:15:57 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:15:57 --> Email Class Initialized
INFO - 2024-08-09 11:15:57 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:15:57 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:15:57 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:15:57 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:15:57 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:15:57 --> Controller Class Initialized
ERROR - 2024-08-09 11:15:57 --> Severity: error --> Exception: Undefined constant "console" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 84
INFO - 2024-08-09 11:16:43 --> Config Class Initialized
INFO - 2024-08-09 11:16:43 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:16:43 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:16:43 --> Utf8 Class Initialized
INFO - 2024-08-09 11:16:43 --> URI Class Initialized
INFO - 2024-08-09 11:16:43 --> Router Class Initialized
INFO - 2024-08-09 11:16:43 --> Output Class Initialized
INFO - 2024-08-09 11:16:43 --> Security Class Initialized
DEBUG - 2024-08-09 11:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:16:43 --> Input Class Initialized
INFO - 2024-08-09 11:16:43 --> Language Class Initialized
INFO - 2024-08-09 11:16:43 --> Loader Class Initialized
INFO - 2024-08-09 11:16:43 --> Helper loaded: url_helper
INFO - 2024-08-09 11:16:43 --> Helper loaded: form_helper
INFO - 2024-08-09 11:16:43 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:16:43 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:16:43 --> Email Class Initialized
INFO - 2024-08-09 11:16:43 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:16:43 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:16:43 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:16:43 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:16:43 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:16:43 --> Controller Class Initialized
INFO - 2024-08-09 11:16:43 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:16:43 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:16:43 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:16:43 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:16:43 --> Final output sent to browser
DEBUG - 2024-08-09 11:16:43 --> Total execution time: 0.1496
INFO - 2024-08-09 11:16:43 --> Config Class Initialized
INFO - 2024-08-09 11:16:43 --> Hooks Class Initialized
INFO - 2024-08-09 11:16:43 --> Config Class Initialized
INFO - 2024-08-09 11:16:43 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:16:43 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:16:43 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:16:43 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:16:43 --> Utf8 Class Initialized
INFO - 2024-08-09 11:16:43 --> URI Class Initialized
INFO - 2024-08-09 11:16:43 --> Router Class Initialized
INFO - 2024-08-09 11:16:43 --> Output Class Initialized
INFO - 2024-08-09 11:16:43 --> Security Class Initialized
DEBUG - 2024-08-09 11:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:16:43 --> Input Class Initialized
INFO - 2024-08-09 11:16:43 --> Language Class Initialized
INFO - 2024-08-09 11:16:43 --> Loader Class Initialized
INFO - 2024-08-09 11:16:43 --> Helper loaded: url_helper
INFO - 2024-08-09 11:16:43 --> Helper loaded: form_helper
INFO - 2024-08-09 11:16:43 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:16:43 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:16:43 --> Email Class Initialized
INFO - 2024-08-09 11:16:43 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:16:43 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:16:43 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:16:43 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:16:43 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:16:43 --> Controller Class Initialized
INFO - 2024-08-09 11:16:43 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:16:43 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:16:43 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:16:43 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:16:43 --> Final output sent to browser
DEBUG - 2024-08-09 11:16:43 --> Total execution time: 0.1233
INFO - 2024-08-09 11:16:51 --> Config Class Initialized
INFO - 2024-08-09 11:16:51 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:16:51 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:16:51 --> Utf8 Class Initialized
INFO - 2024-08-09 11:16:51 --> URI Class Initialized
INFO - 2024-08-09 11:16:51 --> Router Class Initialized
INFO - 2024-08-09 11:16:51 --> Output Class Initialized
INFO - 2024-08-09 11:16:51 --> Security Class Initialized
DEBUG - 2024-08-09 11:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:16:51 --> Input Class Initialized
INFO - 2024-08-09 11:16:51 --> Language Class Initialized
INFO - 2024-08-09 11:16:51 --> Loader Class Initialized
INFO - 2024-08-09 11:16:51 --> Helper loaded: url_helper
INFO - 2024-08-09 11:16:51 --> Helper loaded: form_helper
INFO - 2024-08-09 11:16:51 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:16:51 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:16:51 --> Email Class Initialized
INFO - 2024-08-09 11:16:51 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:16:51 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:16:51 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:16:51 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:16:51 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:16:51 --> Controller Class Initialized
INFO - 2024-08-09 11:16:52 --> Config Class Initialized
INFO - 2024-08-09 11:16:52 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:16:52 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:16:52 --> Utf8 Class Initialized
INFO - 2024-08-09 11:16:52 --> URI Class Initialized
INFO - 2024-08-09 11:16:52 --> Router Class Initialized
INFO - 2024-08-09 11:16:52 --> Output Class Initialized
INFO - 2024-08-09 11:16:52 --> Security Class Initialized
DEBUG - 2024-08-09 11:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:16:52 --> Input Class Initialized
INFO - 2024-08-09 11:16:52 --> Language Class Initialized
INFO - 2024-08-09 11:16:52 --> Loader Class Initialized
INFO - 2024-08-09 11:16:52 --> Helper loaded: url_helper
INFO - 2024-08-09 11:16:52 --> Helper loaded: form_helper
INFO - 2024-08-09 11:16:52 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:16:52 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:16:52 --> Email Class Initialized
INFO - 2024-08-09 11:16:52 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:16:52 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:16:52 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:16:52 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:16:52 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:16:52 --> Controller Class Initialized
INFO - 2024-08-09 11:16:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:16:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:16:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:16:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:16:52 --> Final output sent to browser
DEBUG - 2024-08-09 11:16:52 --> Total execution time: 0.0860
INFO - 2024-08-09 11:16:52 --> Config Class Initialized
INFO - 2024-08-09 11:16:52 --> Hooks Class Initialized
INFO - 2024-08-09 11:16:52 --> Config Class Initialized
INFO - 2024-08-09 11:16:52 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:16:52 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:16:52 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:16:52 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:16:52 --> URI Class Initialized
INFO - 2024-08-09 11:16:52 --> Utf8 Class Initialized
INFO - 2024-08-09 11:16:52 --> Router Class Initialized
INFO - 2024-08-09 11:16:52 --> Output Class Initialized
INFO - 2024-08-09 11:16:52 --> Security Class Initialized
DEBUG - 2024-08-09 11:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:16:52 --> Input Class Initialized
INFO - 2024-08-09 11:16:52 --> Language Class Initialized
INFO - 2024-08-09 11:16:52 --> Loader Class Initialized
INFO - 2024-08-09 11:16:52 --> Helper loaded: url_helper
INFO - 2024-08-09 11:16:52 --> Helper loaded: form_helper
INFO - 2024-08-09 11:16:52 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:16:52 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:16:52 --> Email Class Initialized
INFO - 2024-08-09 11:16:52 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:16:52 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:16:52 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:16:52 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:16:52 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:16:52 --> Controller Class Initialized
INFO - 2024-08-09 11:16:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:16:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:16:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:16:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:16:52 --> Final output sent to browser
DEBUG - 2024-08-09 11:16:52 --> Total execution time: 0.1166
INFO - 2024-08-09 11:17:11 --> Config Class Initialized
INFO - 2024-08-09 11:17:11 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:17:11 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:17:11 --> Utf8 Class Initialized
INFO - 2024-08-09 11:17:11 --> URI Class Initialized
INFO - 2024-08-09 11:17:11 --> Router Class Initialized
INFO - 2024-08-09 11:17:11 --> Output Class Initialized
INFO - 2024-08-09 11:17:11 --> Security Class Initialized
DEBUG - 2024-08-09 11:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:17:11 --> Input Class Initialized
INFO - 2024-08-09 11:17:11 --> Language Class Initialized
INFO - 2024-08-09 11:17:11 --> Loader Class Initialized
INFO - 2024-08-09 11:17:11 --> Helper loaded: url_helper
INFO - 2024-08-09 11:17:11 --> Helper loaded: form_helper
INFO - 2024-08-09 11:17:11 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:17:11 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:17:11 --> Email Class Initialized
INFO - 2024-08-09 11:17:11 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:17:11 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:17:11 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:17:11 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:17:11 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:17:11 --> Controller Class Initialized
INFO - 2024-08-09 11:17:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:17:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:17:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:17:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:17:11 --> Final output sent to browser
DEBUG - 2024-08-09 11:17:11 --> Total execution time: 0.0996
INFO - 2024-08-09 11:17:11 --> Config Class Initialized
INFO - 2024-08-09 11:17:11 --> Hooks Class Initialized
INFO - 2024-08-09 11:17:11 --> Config Class Initialized
INFO - 2024-08-09 11:17:11 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:17:11 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:17:11 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:17:11 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:17:11 --> Utf8 Class Initialized
INFO - 2024-08-09 11:17:11 --> URI Class Initialized
INFO - 2024-08-09 11:17:11 --> Router Class Initialized
INFO - 2024-08-09 11:17:11 --> Output Class Initialized
INFO - 2024-08-09 11:17:11 --> Security Class Initialized
DEBUG - 2024-08-09 11:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:17:11 --> Input Class Initialized
INFO - 2024-08-09 11:17:11 --> Language Class Initialized
INFO - 2024-08-09 11:17:11 --> Loader Class Initialized
INFO - 2024-08-09 11:17:11 --> Helper loaded: url_helper
INFO - 2024-08-09 11:17:11 --> Helper loaded: form_helper
INFO - 2024-08-09 11:17:11 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:17:11 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:17:11 --> Email Class Initialized
INFO - 2024-08-09 11:17:11 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:17:11 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:17:11 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:17:11 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:17:11 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:17:11 --> Controller Class Initialized
INFO - 2024-08-09 11:17:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:17:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:17:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:17:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:17:11 --> Final output sent to browser
DEBUG - 2024-08-09 11:17:11 --> Total execution time: 0.1226
INFO - 2024-08-09 11:17:13 --> Config Class Initialized
INFO - 2024-08-09 11:17:13 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:17:13 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:17:13 --> Utf8 Class Initialized
INFO - 2024-08-09 11:17:13 --> URI Class Initialized
INFO - 2024-08-09 11:17:13 --> Router Class Initialized
INFO - 2024-08-09 11:17:13 --> Output Class Initialized
INFO - 2024-08-09 11:17:13 --> Security Class Initialized
DEBUG - 2024-08-09 11:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:17:13 --> Input Class Initialized
INFO - 2024-08-09 11:17:13 --> Language Class Initialized
INFO - 2024-08-09 11:17:13 --> Loader Class Initialized
INFO - 2024-08-09 11:17:13 --> Helper loaded: url_helper
INFO - 2024-08-09 11:17:13 --> Helper loaded: form_helper
INFO - 2024-08-09 11:17:13 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:17:13 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:17:13 --> Email Class Initialized
INFO - 2024-08-09 11:17:13 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:17:13 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:17:13 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:17:13 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:17:13 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:17:13 --> Controller Class Initialized
INFO - 2024-08-09 11:17:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:17:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:17:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:17:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:17:13 --> Final output sent to browser
DEBUG - 2024-08-09 11:17:13 --> Total execution time: 0.1533
INFO - 2024-08-09 11:17:14 --> Config Class Initialized
INFO - 2024-08-09 11:17:14 --> Hooks Class Initialized
INFO - 2024-08-09 11:17:14 --> Config Class Initialized
INFO - 2024-08-09 11:17:14 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:17:14 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:17:14 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:17:14 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:17:14 --> Utf8 Class Initialized
INFO - 2024-08-09 11:17:14 --> URI Class Initialized
INFO - 2024-08-09 11:17:14 --> Router Class Initialized
INFO - 2024-08-09 11:17:14 --> Output Class Initialized
INFO - 2024-08-09 11:17:14 --> Security Class Initialized
DEBUG - 2024-08-09 11:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:17:14 --> Input Class Initialized
INFO - 2024-08-09 11:17:14 --> Language Class Initialized
INFO - 2024-08-09 11:17:14 --> Loader Class Initialized
INFO - 2024-08-09 11:17:14 --> Helper loaded: url_helper
INFO - 2024-08-09 11:17:14 --> Helper loaded: form_helper
INFO - 2024-08-09 11:17:14 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:17:14 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:17:14 --> Email Class Initialized
INFO - 2024-08-09 11:17:14 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:17:14 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:17:14 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:17:14 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:17:14 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:17:14 --> Controller Class Initialized
INFO - 2024-08-09 11:17:14 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:17:14 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:17:14 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:17:14 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:17:14 --> Final output sent to browser
DEBUG - 2024-08-09 11:17:14 --> Total execution time: 0.1349
INFO - 2024-08-09 11:17:18 --> Config Class Initialized
INFO - 2024-08-09 11:17:18 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:17:18 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:17:18 --> Utf8 Class Initialized
INFO - 2024-08-09 11:17:18 --> URI Class Initialized
INFO - 2024-08-09 11:17:18 --> Router Class Initialized
INFO - 2024-08-09 11:17:18 --> Output Class Initialized
INFO - 2024-08-09 11:17:18 --> Security Class Initialized
DEBUG - 2024-08-09 11:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:17:18 --> Input Class Initialized
INFO - 2024-08-09 11:17:18 --> Language Class Initialized
INFO - 2024-08-09 11:17:18 --> Loader Class Initialized
INFO - 2024-08-09 11:17:18 --> Helper loaded: url_helper
INFO - 2024-08-09 11:17:18 --> Helper loaded: form_helper
INFO - 2024-08-09 11:17:18 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:17:18 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:17:18 --> Email Class Initialized
INFO - 2024-08-09 11:17:18 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:17:18 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:17:18 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:17:18 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:17:18 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:17:18 --> Controller Class Initialized
INFO - 2024-08-09 11:17:18 --> Config Class Initialized
INFO - 2024-08-09 11:17:18 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:17:18 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:17:18 --> Utf8 Class Initialized
INFO - 2024-08-09 11:17:18 --> URI Class Initialized
INFO - 2024-08-09 11:17:18 --> Router Class Initialized
INFO - 2024-08-09 11:17:18 --> Output Class Initialized
INFO - 2024-08-09 11:17:18 --> Security Class Initialized
DEBUG - 2024-08-09 11:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:17:18 --> Input Class Initialized
INFO - 2024-08-09 11:17:18 --> Language Class Initialized
INFO - 2024-08-09 11:17:18 --> Loader Class Initialized
INFO - 2024-08-09 11:17:18 --> Helper loaded: url_helper
INFO - 2024-08-09 11:17:18 --> Helper loaded: form_helper
INFO - 2024-08-09 11:17:18 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:17:18 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:17:18 --> Email Class Initialized
INFO - 2024-08-09 11:17:18 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:17:18 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:17:18 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:17:18 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:17:18 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:17:18 --> Controller Class Initialized
INFO - 2024-08-09 11:17:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:17:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:17:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:17:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:17:18 --> Final output sent to browser
DEBUG - 2024-08-09 11:17:18 --> Total execution time: 0.0958
INFO - 2024-08-09 11:17:19 --> Config Class Initialized
INFO - 2024-08-09 11:17:19 --> Hooks Class Initialized
INFO - 2024-08-09 11:17:19 --> Config Class Initialized
INFO - 2024-08-09 11:17:19 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:17:19 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:17:19 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:17:19 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:17:19 --> Utf8 Class Initialized
INFO - 2024-08-09 11:17:19 --> URI Class Initialized
INFO - 2024-08-09 11:17:19 --> Router Class Initialized
INFO - 2024-08-09 11:17:19 --> Output Class Initialized
INFO - 2024-08-09 11:17:19 --> Security Class Initialized
DEBUG - 2024-08-09 11:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:17:19 --> Input Class Initialized
INFO - 2024-08-09 11:17:19 --> Language Class Initialized
INFO - 2024-08-09 11:17:19 --> Loader Class Initialized
INFO - 2024-08-09 11:17:19 --> Helper loaded: url_helper
INFO - 2024-08-09 11:17:19 --> Helper loaded: form_helper
INFO - 2024-08-09 11:17:19 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:17:19 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:17:19 --> Email Class Initialized
INFO - 2024-08-09 11:17:19 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:17:19 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:17:19 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:17:19 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:17:19 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:17:19 --> Controller Class Initialized
INFO - 2024-08-09 11:17:19 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:17:19 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:17:19 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:17:19 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:17:19 --> Final output sent to browser
DEBUG - 2024-08-09 11:17:19 --> Total execution time: 0.1369
INFO - 2024-08-09 11:28:08 --> Config Class Initialized
INFO - 2024-08-09 11:28:08 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:28:08 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:28:08 --> Utf8 Class Initialized
INFO - 2024-08-09 11:28:08 --> URI Class Initialized
INFO - 2024-08-09 11:28:08 --> Router Class Initialized
INFO - 2024-08-09 11:28:08 --> Output Class Initialized
INFO - 2024-08-09 11:28:08 --> Security Class Initialized
DEBUG - 2024-08-09 11:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:28:08 --> Input Class Initialized
INFO - 2024-08-09 11:28:08 --> Language Class Initialized
INFO - 2024-08-09 11:28:08 --> Loader Class Initialized
INFO - 2024-08-09 11:28:08 --> Helper loaded: url_helper
INFO - 2024-08-09 11:28:08 --> Helper loaded: form_helper
INFO - 2024-08-09 11:28:08 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:28:08 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:28:08 --> Email Class Initialized
INFO - 2024-08-09 11:28:08 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:28:08 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:28:08 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:28:08 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:28:08 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:28:08 --> Controller Class Initialized
INFO - 2024-08-09 11:28:08 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:28:08 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:28:08 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:28:08 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:28:08 --> Final output sent to browser
DEBUG - 2024-08-09 11:28:08 --> Total execution time: 0.1607
INFO - 2024-08-09 11:28:09 --> Config Class Initialized
INFO - 2024-08-09 11:28:09 --> Hooks Class Initialized
INFO - 2024-08-09 11:28:09 --> Config Class Initialized
INFO - 2024-08-09 11:28:09 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:28:09 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:28:09 --> Utf8 Class Initialized
INFO - 2024-08-09 11:28:09 --> URI Class Initialized
DEBUG - 2024-08-09 11:28:09 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:28:09 --> Utf8 Class Initialized
INFO - 2024-08-09 11:28:09 --> Router Class Initialized
INFO - 2024-08-09 11:28:09 --> Output Class Initialized
INFO - 2024-08-09 11:28:09 --> Security Class Initialized
DEBUG - 2024-08-09 11:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:28:09 --> Input Class Initialized
INFO - 2024-08-09 11:28:09 --> Language Class Initialized
INFO - 2024-08-09 11:28:09 --> Loader Class Initialized
INFO - 2024-08-09 11:28:09 --> Helper loaded: url_helper
INFO - 2024-08-09 11:28:09 --> Helper loaded: form_helper
INFO - 2024-08-09 11:28:09 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:28:09 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:28:09 --> Email Class Initialized
INFO - 2024-08-09 11:28:09 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:28:09 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:28:09 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:28:09 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:28:09 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:28:09 --> Controller Class Initialized
INFO - 2024-08-09 11:28:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:28:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:28:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:28:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:28:09 --> Final output sent to browser
DEBUG - 2024-08-09 11:28:09 --> Total execution time: 0.1168
INFO - 2024-08-09 11:28:11 --> Config Class Initialized
INFO - 2024-08-09 11:28:11 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:28:11 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:28:11 --> Utf8 Class Initialized
INFO - 2024-08-09 11:28:11 --> URI Class Initialized
INFO - 2024-08-09 11:28:11 --> Router Class Initialized
INFO - 2024-08-09 11:28:11 --> Output Class Initialized
INFO - 2024-08-09 11:28:11 --> Security Class Initialized
DEBUG - 2024-08-09 11:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:28:11 --> Input Class Initialized
INFO - 2024-08-09 11:28:11 --> Language Class Initialized
INFO - 2024-08-09 11:28:11 --> Loader Class Initialized
INFO - 2024-08-09 11:28:11 --> Helper loaded: url_helper
INFO - 2024-08-09 11:28:11 --> Helper loaded: form_helper
INFO - 2024-08-09 11:28:11 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:28:11 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:28:11 --> Email Class Initialized
INFO - 2024-08-09 11:28:11 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:28:11 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:28:11 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:28:11 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:28:11 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:28:11 --> Controller Class Initialized
INFO - 2024-08-09 11:28:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:28:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:28:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:28:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:28:11 --> Final output sent to browser
DEBUG - 2024-08-09 11:28:11 --> Total execution time: 0.1346
INFO - 2024-08-09 11:28:12 --> Config Class Initialized
INFO - 2024-08-09 11:28:12 --> Hooks Class Initialized
INFO - 2024-08-09 11:28:12 --> Config Class Initialized
INFO - 2024-08-09 11:28:12 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:28:12 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:28:12 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:28:12 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:28:12 --> URI Class Initialized
INFO - 2024-08-09 11:28:12 --> Utf8 Class Initialized
INFO - 2024-08-09 11:28:12 --> Router Class Initialized
INFO - 2024-08-09 11:28:12 --> Output Class Initialized
INFO - 2024-08-09 11:28:12 --> Security Class Initialized
DEBUG - 2024-08-09 11:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:28:12 --> Input Class Initialized
INFO - 2024-08-09 11:28:12 --> Language Class Initialized
INFO - 2024-08-09 11:28:12 --> Loader Class Initialized
INFO - 2024-08-09 11:28:12 --> Helper loaded: url_helper
INFO - 2024-08-09 11:28:12 --> Helper loaded: form_helper
INFO - 2024-08-09 11:28:12 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:28:12 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:28:12 --> Email Class Initialized
INFO - 2024-08-09 11:28:12 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:28:12 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:28:12 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:28:12 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:28:12 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:28:12 --> Controller Class Initialized
INFO - 2024-08-09 11:28:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:28:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:28:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:28:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:28:12 --> Final output sent to browser
DEBUG - 2024-08-09 11:28:12 --> Total execution time: 0.1252
INFO - 2024-08-09 11:28:15 --> Config Class Initialized
INFO - 2024-08-09 11:28:15 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:28:16 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:28:16 --> Utf8 Class Initialized
INFO - 2024-08-09 11:28:16 --> URI Class Initialized
INFO - 2024-08-09 11:28:16 --> Router Class Initialized
INFO - 2024-08-09 11:28:16 --> Output Class Initialized
INFO - 2024-08-09 11:28:16 --> Security Class Initialized
DEBUG - 2024-08-09 11:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:28:16 --> Input Class Initialized
INFO - 2024-08-09 11:28:16 --> Language Class Initialized
INFO - 2024-08-09 11:28:16 --> Loader Class Initialized
INFO - 2024-08-09 11:28:16 --> Helper loaded: url_helper
INFO - 2024-08-09 11:28:16 --> Helper loaded: form_helper
INFO - 2024-08-09 11:28:16 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:28:16 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:28:16 --> Email Class Initialized
INFO - 2024-08-09 11:28:16 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:28:16 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:28:16 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:28:16 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:28:16 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:28:16 --> Controller Class Initialized
INFO - 2024-08-09 11:28:16 --> Config Class Initialized
INFO - 2024-08-09 11:28:16 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:28:16 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:28:16 --> Utf8 Class Initialized
INFO - 2024-08-09 11:28:16 --> URI Class Initialized
INFO - 2024-08-09 11:28:16 --> Router Class Initialized
INFO - 2024-08-09 11:28:16 --> Output Class Initialized
INFO - 2024-08-09 11:28:16 --> Security Class Initialized
DEBUG - 2024-08-09 11:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:28:16 --> Input Class Initialized
INFO - 2024-08-09 11:28:16 --> Language Class Initialized
INFO - 2024-08-09 11:28:16 --> Loader Class Initialized
INFO - 2024-08-09 11:28:16 --> Helper loaded: url_helper
INFO - 2024-08-09 11:28:16 --> Helper loaded: form_helper
INFO - 2024-08-09 11:28:16 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:28:16 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:28:16 --> Email Class Initialized
INFO - 2024-08-09 11:28:16 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:28:16 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:28:16 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:28:16 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:28:16 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:28:16 --> Controller Class Initialized
INFO - 2024-08-09 11:28:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:28:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:28:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:28:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:28:16 --> Final output sent to browser
DEBUG - 2024-08-09 11:28:16 --> Total execution time: 0.0801
INFO - 2024-08-09 11:28:16 --> Config Class Initialized
INFO - 2024-08-09 11:28:16 --> Config Class Initialized
INFO - 2024-08-09 11:28:16 --> Hooks Class Initialized
INFO - 2024-08-09 11:28:16 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:28:16 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 11:28:16 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:28:16 --> Utf8 Class Initialized
INFO - 2024-08-09 11:28:16 --> Utf8 Class Initialized
INFO - 2024-08-09 11:28:16 --> URI Class Initialized
INFO - 2024-08-09 11:28:16 --> Router Class Initialized
INFO - 2024-08-09 11:28:16 --> Output Class Initialized
INFO - 2024-08-09 11:28:16 --> Security Class Initialized
DEBUG - 2024-08-09 11:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:28:16 --> Input Class Initialized
INFO - 2024-08-09 11:28:16 --> Language Class Initialized
INFO - 2024-08-09 11:28:16 --> Loader Class Initialized
INFO - 2024-08-09 11:28:16 --> Helper loaded: url_helper
INFO - 2024-08-09 11:28:16 --> Helper loaded: form_helper
INFO - 2024-08-09 11:28:16 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:28:16 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:28:16 --> Email Class Initialized
INFO - 2024-08-09 11:28:16 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:28:16 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:28:16 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:28:16 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:28:16 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:28:16 --> Controller Class Initialized
INFO - 2024-08-09 11:28:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:28:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:28:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:28:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:28:16 --> Final output sent to browser
DEBUG - 2024-08-09 11:28:16 --> Total execution time: 0.1181
INFO - 2024-08-09 11:28:19 --> Config Class Initialized
INFO - 2024-08-09 11:28:19 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:28:19 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:28:19 --> Utf8 Class Initialized
INFO - 2024-08-09 11:28:19 --> URI Class Initialized
INFO - 2024-08-09 11:28:19 --> Router Class Initialized
INFO - 2024-08-09 11:28:19 --> Output Class Initialized
INFO - 2024-08-09 11:28:19 --> Security Class Initialized
DEBUG - 2024-08-09 11:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:28:19 --> Input Class Initialized
INFO - 2024-08-09 11:28:19 --> Language Class Initialized
INFO - 2024-08-09 11:28:19 --> Loader Class Initialized
INFO - 2024-08-09 11:28:19 --> Helper loaded: url_helper
INFO - 2024-08-09 11:28:19 --> Helper loaded: form_helper
INFO - 2024-08-09 11:28:19 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:28:19 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:28:19 --> Email Class Initialized
INFO - 2024-08-09 11:28:19 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:28:19 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:28:19 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:28:19 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:28:19 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:28:19 --> Controller Class Initialized
INFO - 2024-08-09 11:28:19 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:28:19 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:28:19 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:28:19 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:28:19 --> Final output sent to browser
DEBUG - 2024-08-09 11:28:19 --> Total execution time: 0.1023
INFO - 2024-08-09 11:28:20 --> Config Class Initialized
INFO - 2024-08-09 11:28:20 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:28:20 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:28:20 --> Utf8 Class Initialized
INFO - 2024-08-09 11:28:20 --> URI Class Initialized
INFO - 2024-08-09 11:28:20 --> Router Class Initialized
INFO - 2024-08-09 11:28:20 --> Config Class Initialized
INFO - 2024-08-09 11:28:20 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:28:20 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:28:20 --> Utf8 Class Initialized
INFO - 2024-08-09 11:28:20 --> Output Class Initialized
INFO - 2024-08-09 11:28:20 --> Security Class Initialized
DEBUG - 2024-08-09 11:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:28:20 --> Input Class Initialized
INFO - 2024-08-09 11:28:20 --> Language Class Initialized
INFO - 2024-08-09 11:28:20 --> Loader Class Initialized
INFO - 2024-08-09 11:28:20 --> Helper loaded: url_helper
INFO - 2024-08-09 11:28:20 --> Helper loaded: form_helper
INFO - 2024-08-09 11:28:20 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:28:20 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:28:20 --> Email Class Initialized
INFO - 2024-08-09 11:28:20 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:28:20 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:28:20 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:28:20 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:28:20 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:28:20 --> Controller Class Initialized
INFO - 2024-08-09 11:28:20 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:28:20 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:28:20 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:28:20 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:28:20 --> Final output sent to browser
DEBUG - 2024-08-09 11:28:20 --> Total execution time: 0.2169
INFO - 2024-08-09 11:28:23 --> Config Class Initialized
INFO - 2024-08-09 11:28:23 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:28:23 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:28:23 --> Utf8 Class Initialized
INFO - 2024-08-09 11:28:23 --> URI Class Initialized
INFO - 2024-08-09 11:28:23 --> Router Class Initialized
INFO - 2024-08-09 11:28:23 --> Output Class Initialized
INFO - 2024-08-09 11:28:23 --> Security Class Initialized
DEBUG - 2024-08-09 11:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:28:23 --> Input Class Initialized
INFO - 2024-08-09 11:28:23 --> Language Class Initialized
INFO - 2024-08-09 11:28:23 --> Loader Class Initialized
INFO - 2024-08-09 11:28:23 --> Helper loaded: url_helper
INFO - 2024-08-09 11:28:23 --> Helper loaded: form_helper
INFO - 2024-08-09 11:28:23 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:28:23 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:28:23 --> Email Class Initialized
INFO - 2024-08-09 11:28:23 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:28:23 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:28:23 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:28:23 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:28:23 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:28:23 --> Controller Class Initialized
INFO - 2024-08-09 11:29:29 --> Config Class Initialized
INFO - 2024-08-09 11:29:29 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:29:29 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:29:29 --> Utf8 Class Initialized
INFO - 2024-08-09 11:29:29 --> URI Class Initialized
INFO - 2024-08-09 11:29:29 --> Router Class Initialized
INFO - 2024-08-09 11:29:29 --> Output Class Initialized
INFO - 2024-08-09 11:29:29 --> Security Class Initialized
DEBUG - 2024-08-09 11:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:29:29 --> Input Class Initialized
INFO - 2024-08-09 11:29:29 --> Language Class Initialized
INFO - 2024-08-09 11:29:29 --> Loader Class Initialized
INFO - 2024-08-09 11:29:29 --> Helper loaded: url_helper
INFO - 2024-08-09 11:29:29 --> Helper loaded: form_helper
INFO - 2024-08-09 11:29:29 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:29:29 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:29:29 --> Email Class Initialized
INFO - 2024-08-09 11:29:29 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:29:29 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:29:29 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:29:29 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:29:29 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:29:29 --> Controller Class Initialized
INFO - 2024-08-09 11:29:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:29:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:29:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:29:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:29:29 --> Final output sent to browser
DEBUG - 2024-08-09 11:29:29 --> Total execution time: 0.1522
INFO - 2024-08-09 11:29:30 --> Config Class Initialized
INFO - 2024-08-09 11:29:30 --> Hooks Class Initialized
INFO - 2024-08-09 11:29:30 --> Config Class Initialized
INFO - 2024-08-09 11:29:30 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:29:30 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 11:29:30 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:29:30 --> Utf8 Class Initialized
INFO - 2024-08-09 11:29:30 --> Utf8 Class Initialized
INFO - 2024-08-09 11:29:30 --> URI Class Initialized
INFO - 2024-08-09 11:29:30 --> Router Class Initialized
INFO - 2024-08-09 11:29:30 --> Output Class Initialized
INFO - 2024-08-09 11:29:30 --> Security Class Initialized
DEBUG - 2024-08-09 11:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:29:30 --> Input Class Initialized
INFO - 2024-08-09 11:29:30 --> Language Class Initialized
INFO - 2024-08-09 11:29:30 --> Loader Class Initialized
INFO - 2024-08-09 11:29:30 --> Helper loaded: url_helper
INFO - 2024-08-09 11:29:30 --> Helper loaded: form_helper
INFO - 2024-08-09 11:29:30 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:29:30 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:29:30 --> Email Class Initialized
INFO - 2024-08-09 11:29:30 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:29:30 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:29:30 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:29:30 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:29:30 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:29:30 --> Controller Class Initialized
ERROR - 2024-08-09 11:29:30 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 93
ERROR - 2024-08-09 11:29:30 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 98
ERROR - 2024-08-09 11:29:30 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 99
ERROR - 2024-08-09 11:29:30 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 139
ERROR - 2024-08-09 11:29:30 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 140
ERROR - 2024-08-09 11:29:30 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 140
ERROR - 2024-08-09 11:29:30 --> Severity: Warning --> Undefined array key "primerapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 11:29:30 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 11:29:30 --> Severity: Warning --> Undefined array key "segundoapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 142
ERROR - 2024-08-09 11:29:30 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 142
ERROR - 2024-08-09 11:29:30 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 143
ERROR - 2024-08-09 11:29:30 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 144
ERROR - 2024-08-09 11:29:30 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 145
ERROR - 2024-08-09 11:29:30 --> Severity: Warning --> Undefined array key "genero" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 146
ERROR - 2024-08-09 11:29:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\core\Exceptions.php:272) C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\helpers\url_helper.php 562
INFO - 2024-08-09 11:29:39 --> Config Class Initialized
INFO - 2024-08-09 11:29:39 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:29:39 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:29:39 --> Utf8 Class Initialized
INFO - 2024-08-09 11:29:39 --> URI Class Initialized
INFO - 2024-08-09 11:29:39 --> Router Class Initialized
INFO - 2024-08-09 11:29:39 --> Output Class Initialized
INFO - 2024-08-09 11:29:39 --> Security Class Initialized
DEBUG - 2024-08-09 11:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:29:39 --> Input Class Initialized
INFO - 2024-08-09 11:29:39 --> Language Class Initialized
INFO - 2024-08-09 11:29:39 --> Loader Class Initialized
INFO - 2024-08-09 11:29:39 --> Helper loaded: url_helper
INFO - 2024-08-09 11:29:39 --> Helper loaded: form_helper
INFO - 2024-08-09 11:29:39 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:29:39 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:29:39 --> Email Class Initialized
INFO - 2024-08-09 11:29:39 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:29:39 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:29:39 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:29:39 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:29:39 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:29:39 --> Controller Class Initialized
INFO - 2024-08-09 11:29:39 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:29:39 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:29:39 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:29:39 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:29:39 --> Final output sent to browser
DEBUG - 2024-08-09 11:29:39 --> Total execution time: 0.1180
INFO - 2024-08-09 11:29:40 --> Config Class Initialized
INFO - 2024-08-09 11:29:40 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:29:40 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:29:40 --> Utf8 Class Initialized
INFO - 2024-08-09 11:29:40 --> Config Class Initialized
INFO - 2024-08-09 11:29:40 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:29:40 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:29:40 --> Utf8 Class Initialized
INFO - 2024-08-09 11:29:40 --> URI Class Initialized
INFO - 2024-08-09 11:29:40 --> Router Class Initialized
INFO - 2024-08-09 11:29:40 --> Output Class Initialized
INFO - 2024-08-09 11:29:40 --> Security Class Initialized
DEBUG - 2024-08-09 11:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:29:40 --> Input Class Initialized
INFO - 2024-08-09 11:29:40 --> Language Class Initialized
INFO - 2024-08-09 11:29:40 --> Loader Class Initialized
INFO - 2024-08-09 11:29:40 --> Helper loaded: url_helper
INFO - 2024-08-09 11:29:40 --> Helper loaded: form_helper
INFO - 2024-08-09 11:29:40 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:29:40 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:29:40 --> Email Class Initialized
INFO - 2024-08-09 11:29:40 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:29:40 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:29:40 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:29:40 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:29:40 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:29:40 --> Controller Class Initialized
ERROR - 2024-08-09 11:29:40 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 93
ERROR - 2024-08-09 11:29:40 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 98
ERROR - 2024-08-09 11:29:40 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 99
ERROR - 2024-08-09 11:29:40 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 139
ERROR - 2024-08-09 11:29:40 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 140
ERROR - 2024-08-09 11:29:40 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 140
ERROR - 2024-08-09 11:29:40 --> Severity: Warning --> Undefined array key "primerapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 11:29:40 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 11:29:40 --> Severity: Warning --> Undefined array key "segundoapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 142
ERROR - 2024-08-09 11:29:40 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 142
ERROR - 2024-08-09 11:29:40 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 143
ERROR - 2024-08-09 11:29:40 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 144
ERROR - 2024-08-09 11:29:40 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 145
ERROR - 2024-08-09 11:29:40 --> Severity: Warning --> Undefined array key "genero" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 146
ERROR - 2024-08-09 11:29:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\core\Exceptions.php:272) C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\helpers\url_helper.php 562
INFO - 2024-08-09 11:29:44 --> Config Class Initialized
INFO - 2024-08-09 11:29:44 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:29:44 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:29:44 --> Utf8 Class Initialized
INFO - 2024-08-09 11:29:45 --> URI Class Initialized
INFO - 2024-08-09 11:29:45 --> Router Class Initialized
INFO - 2024-08-09 11:29:45 --> Output Class Initialized
INFO - 2024-08-09 11:29:45 --> Security Class Initialized
DEBUG - 2024-08-09 11:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:29:45 --> Input Class Initialized
INFO - 2024-08-09 11:29:45 --> Language Class Initialized
INFO - 2024-08-09 11:29:45 --> Loader Class Initialized
INFO - 2024-08-09 11:29:45 --> Helper loaded: url_helper
INFO - 2024-08-09 11:29:45 --> Helper loaded: form_helper
INFO - 2024-08-09 11:29:45 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:29:45 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:29:45 --> Email Class Initialized
INFO - 2024-08-09 11:29:45 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:29:45 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:29:45 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:29:45 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:29:45 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:29:45 --> Controller Class Initialized
INFO - 2024-08-09 11:29:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:29:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:29:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:29:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:29:45 --> Final output sent to browser
DEBUG - 2024-08-09 11:29:45 --> Total execution time: 0.1061
INFO - 2024-08-09 11:29:45 --> Config Class Initialized
INFO - 2024-08-09 11:29:45 --> Hooks Class Initialized
INFO - 2024-08-09 11:29:45 --> Config Class Initialized
INFO - 2024-08-09 11:29:45 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:29:45 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:29:45 --> Utf8 Class Initialized
INFO - 2024-08-09 11:29:45 --> URI Class Initialized
DEBUG - 2024-08-09 11:29:45 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:29:45 --> Utf8 Class Initialized
INFO - 2024-08-09 11:29:45 --> Router Class Initialized
INFO - 2024-08-09 11:29:45 --> Output Class Initialized
INFO - 2024-08-09 11:29:45 --> Security Class Initialized
DEBUG - 2024-08-09 11:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:29:45 --> Input Class Initialized
INFO - 2024-08-09 11:29:45 --> Language Class Initialized
INFO - 2024-08-09 11:29:45 --> Loader Class Initialized
INFO - 2024-08-09 11:29:45 --> Helper loaded: url_helper
INFO - 2024-08-09 11:29:45 --> Helper loaded: form_helper
INFO - 2024-08-09 11:29:45 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:29:45 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:29:45 --> Email Class Initialized
INFO - 2024-08-09 11:29:45 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:29:45 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:29:45 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:29:45 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:29:45 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:29:45 --> Controller Class Initialized
INFO - 2024-08-09 11:29:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:29:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:29:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:29:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:29:45 --> Final output sent to browser
DEBUG - 2024-08-09 11:29:45 --> Total execution time: 0.1393
INFO - 2024-08-09 11:30:54 --> Config Class Initialized
INFO - 2024-08-09 11:30:54 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:30:54 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:30:54 --> Utf8 Class Initialized
INFO - 2024-08-09 11:30:54 --> URI Class Initialized
INFO - 2024-08-09 11:30:54 --> Router Class Initialized
INFO - 2024-08-09 11:30:54 --> Output Class Initialized
INFO - 2024-08-09 11:30:54 --> Security Class Initialized
DEBUG - 2024-08-09 11:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:30:54 --> Input Class Initialized
INFO - 2024-08-09 11:30:54 --> Language Class Initialized
INFO - 2024-08-09 11:30:54 --> Loader Class Initialized
INFO - 2024-08-09 11:30:54 --> Helper loaded: url_helper
INFO - 2024-08-09 11:30:54 --> Helper loaded: form_helper
INFO - 2024-08-09 11:30:54 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:30:54 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:30:54 --> Email Class Initialized
INFO - 2024-08-09 11:30:54 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:30:54 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:30:54 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:30:54 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:30:54 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:30:54 --> Controller Class Initialized
INFO - 2024-08-09 11:30:54 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:30:54 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:30:54 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:30:54 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:30:54 --> Final output sent to browser
DEBUG - 2024-08-09 11:30:54 --> Total execution time: 0.1405
INFO - 2024-08-09 11:30:54 --> Config Class Initialized
INFO - 2024-08-09 11:30:54 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:30:54 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:30:54 --> Utf8 Class Initialized
INFO - 2024-08-09 11:30:54 --> URI Class Initialized
INFO - 2024-08-09 11:30:54 --> Config Class Initialized
INFO - 2024-08-09 11:30:54 --> Hooks Class Initialized
INFO - 2024-08-09 11:30:54 --> Router Class Initialized
INFO - 2024-08-09 11:30:54 --> Output Class Initialized
DEBUG - 2024-08-09 11:30:54 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:30:54 --> Utf8 Class Initialized
INFO - 2024-08-09 11:30:54 --> Security Class Initialized
DEBUG - 2024-08-09 11:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:30:54 --> Input Class Initialized
INFO - 2024-08-09 11:30:54 --> Language Class Initialized
INFO - 2024-08-09 11:30:54 --> Loader Class Initialized
INFO - 2024-08-09 11:30:54 --> Helper loaded: url_helper
INFO - 2024-08-09 11:30:54 --> Helper loaded: form_helper
INFO - 2024-08-09 11:30:54 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:30:54 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:30:54 --> Email Class Initialized
INFO - 2024-08-09 11:30:54 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:30:54 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:30:54 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:30:54 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:30:54 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:30:54 --> Controller Class Initialized
INFO - 2024-08-09 11:30:54 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:30:54 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:30:54 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:30:54 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:30:54 --> Final output sent to browser
DEBUG - 2024-08-09 11:30:54 --> Total execution time: 0.1231
INFO - 2024-08-09 11:30:57 --> Config Class Initialized
INFO - 2024-08-09 11:30:57 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:30:57 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:30:57 --> Utf8 Class Initialized
INFO - 2024-08-09 11:30:57 --> URI Class Initialized
INFO - 2024-08-09 11:30:57 --> Router Class Initialized
INFO - 2024-08-09 11:30:57 --> Output Class Initialized
INFO - 2024-08-09 11:30:57 --> Security Class Initialized
DEBUG - 2024-08-09 11:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:30:57 --> Input Class Initialized
INFO - 2024-08-09 11:30:57 --> Language Class Initialized
INFO - 2024-08-09 11:30:57 --> Loader Class Initialized
INFO - 2024-08-09 11:30:57 --> Helper loaded: url_helper
INFO - 2024-08-09 11:30:57 --> Helper loaded: form_helper
INFO - 2024-08-09 11:30:57 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:30:57 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:30:57 --> Email Class Initialized
INFO - 2024-08-09 11:30:57 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:30:57 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:30:57 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:30:57 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:30:57 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:30:57 --> Controller Class Initialized
INFO - 2024-08-09 11:30:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:30:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:30:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:30:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:30:57 --> Final output sent to browser
DEBUG - 2024-08-09 11:30:57 --> Total execution time: 0.1043
INFO - 2024-08-09 11:30:57 --> Config Class Initialized
INFO - 2024-08-09 11:30:57 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:30:57 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:30:57 --> Config Class Initialized
INFO - 2024-08-09 11:30:57 --> Utf8 Class Initialized
INFO - 2024-08-09 11:30:57 --> Hooks Class Initialized
INFO - 2024-08-09 11:30:57 --> URI Class Initialized
INFO - 2024-08-09 11:30:57 --> Router Class Initialized
DEBUG - 2024-08-09 11:30:57 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:30:57 --> Utf8 Class Initialized
INFO - 2024-08-09 11:30:57 --> Output Class Initialized
INFO - 2024-08-09 11:30:57 --> Security Class Initialized
DEBUG - 2024-08-09 11:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:30:57 --> Input Class Initialized
INFO - 2024-08-09 11:30:57 --> Language Class Initialized
INFO - 2024-08-09 11:30:57 --> Loader Class Initialized
INFO - 2024-08-09 11:30:57 --> Helper loaded: url_helper
INFO - 2024-08-09 11:30:57 --> Helper loaded: form_helper
INFO - 2024-08-09 11:30:57 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:30:57 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:30:57 --> Email Class Initialized
INFO - 2024-08-09 11:30:57 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:30:57 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:30:57 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:30:57 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:30:57 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:30:57 --> Controller Class Initialized
INFO - 2024-08-09 11:30:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:30:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:30:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:30:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:30:57 --> Final output sent to browser
DEBUG - 2024-08-09 11:30:57 --> Total execution time: 0.1456
INFO - 2024-08-09 11:31:18 --> Config Class Initialized
INFO - 2024-08-09 11:31:18 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:31:18 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:31:18 --> Utf8 Class Initialized
INFO - 2024-08-09 11:31:18 --> URI Class Initialized
INFO - 2024-08-09 11:31:18 --> Router Class Initialized
INFO - 2024-08-09 11:31:18 --> Output Class Initialized
INFO - 2024-08-09 11:31:18 --> Security Class Initialized
DEBUG - 2024-08-09 11:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:31:18 --> Input Class Initialized
INFO - 2024-08-09 11:31:18 --> Language Class Initialized
INFO - 2024-08-09 11:31:18 --> Loader Class Initialized
INFO - 2024-08-09 11:31:18 --> Helper loaded: url_helper
INFO - 2024-08-09 11:31:18 --> Helper loaded: form_helper
INFO - 2024-08-09 11:31:18 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:31:18 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:31:18 --> Email Class Initialized
INFO - 2024-08-09 11:31:18 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:31:18 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:31:18 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:31:18 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:31:18 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:31:18 --> Controller Class Initialized
INFO - 2024-08-09 11:31:18 --> Config Class Initialized
INFO - 2024-08-09 11:31:18 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:31:18 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:31:18 --> Utf8 Class Initialized
INFO - 2024-08-09 11:31:18 --> URI Class Initialized
INFO - 2024-08-09 11:31:18 --> Router Class Initialized
INFO - 2024-08-09 11:31:18 --> Output Class Initialized
INFO - 2024-08-09 11:31:18 --> Security Class Initialized
DEBUG - 2024-08-09 11:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:31:18 --> Input Class Initialized
INFO - 2024-08-09 11:31:18 --> Language Class Initialized
INFO - 2024-08-09 11:31:18 --> Loader Class Initialized
INFO - 2024-08-09 11:31:18 --> Helper loaded: url_helper
INFO - 2024-08-09 11:31:18 --> Helper loaded: form_helper
INFO - 2024-08-09 11:31:18 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:31:18 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:31:18 --> Email Class Initialized
INFO - 2024-08-09 11:31:18 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:31:18 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:31:18 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:31:18 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:31:18 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:31:18 --> Controller Class Initialized
INFO - 2024-08-09 11:31:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:31:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:31:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:31:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:31:18 --> Final output sent to browser
DEBUG - 2024-08-09 11:31:18 --> Total execution time: 0.0913
INFO - 2024-08-09 11:31:18 --> Config Class Initialized
INFO - 2024-08-09 11:31:18 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:31:18 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:31:18 --> Utf8 Class Initialized
INFO - 2024-08-09 11:31:18 --> URI Class Initialized
INFO - 2024-08-09 11:31:18 --> Config Class Initialized
INFO - 2024-08-09 11:31:18 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:31:18 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:31:18 --> Utf8 Class Initialized
INFO - 2024-08-09 11:31:18 --> Router Class Initialized
INFO - 2024-08-09 11:31:18 --> Output Class Initialized
INFO - 2024-08-09 11:31:18 --> Security Class Initialized
DEBUG - 2024-08-09 11:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:31:18 --> Input Class Initialized
INFO - 2024-08-09 11:31:18 --> Language Class Initialized
INFO - 2024-08-09 11:31:18 --> Loader Class Initialized
INFO - 2024-08-09 11:31:18 --> Helper loaded: url_helper
INFO - 2024-08-09 11:31:18 --> Helper loaded: form_helper
INFO - 2024-08-09 11:31:18 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:31:18 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:31:18 --> Email Class Initialized
INFO - 2024-08-09 11:31:18 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:31:18 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:31:18 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:31:18 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:31:18 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:31:18 --> Controller Class Initialized
INFO - 2024-08-09 11:31:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:31:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:31:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:31:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:31:18 --> Final output sent to browser
DEBUG - 2024-08-09 11:31:18 --> Total execution time: 0.1228
INFO - 2024-08-09 11:35:10 --> Config Class Initialized
INFO - 2024-08-09 11:35:10 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:35:10 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:35:10 --> Utf8 Class Initialized
INFO - 2024-08-09 11:35:10 --> URI Class Initialized
INFO - 2024-08-09 11:35:10 --> Router Class Initialized
INFO - 2024-08-09 11:35:10 --> Output Class Initialized
INFO - 2024-08-09 11:35:10 --> Security Class Initialized
DEBUG - 2024-08-09 11:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:35:10 --> Input Class Initialized
INFO - 2024-08-09 11:35:10 --> Language Class Initialized
INFO - 2024-08-09 11:35:11 --> Loader Class Initialized
INFO - 2024-08-09 11:35:11 --> Helper loaded: url_helper
INFO - 2024-08-09 11:35:11 --> Helper loaded: form_helper
INFO - 2024-08-09 11:35:11 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:35:11 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:35:11 --> Email Class Initialized
INFO - 2024-08-09 11:35:11 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:35:11 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:35:11 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:35:11 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:35:11 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:35:11 --> Controller Class Initialized
INFO - 2024-08-09 11:35:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:35:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:35:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:35:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:35:11 --> Final output sent to browser
DEBUG - 2024-08-09 11:35:11 --> Total execution time: 0.1509
INFO - 2024-08-09 11:35:11 --> Config Class Initialized
INFO - 2024-08-09 11:35:11 --> Config Class Initialized
INFO - 2024-08-09 11:35:11 --> Hooks Class Initialized
INFO - 2024-08-09 11:35:11 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:35:11 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 11:35:11 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:35:11 --> Utf8 Class Initialized
INFO - 2024-08-09 11:35:11 --> Utf8 Class Initialized
INFO - 2024-08-09 11:35:11 --> URI Class Initialized
INFO - 2024-08-09 11:35:11 --> Router Class Initialized
INFO - 2024-08-09 11:35:11 --> Output Class Initialized
INFO - 2024-08-09 11:35:11 --> Security Class Initialized
DEBUG - 2024-08-09 11:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:35:11 --> Input Class Initialized
INFO - 2024-08-09 11:35:11 --> Language Class Initialized
INFO - 2024-08-09 11:35:11 --> Loader Class Initialized
INFO - 2024-08-09 11:35:11 --> Helper loaded: url_helper
INFO - 2024-08-09 11:35:11 --> Helper loaded: form_helper
INFO - 2024-08-09 11:35:11 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:35:11 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:35:11 --> Email Class Initialized
INFO - 2024-08-09 11:35:11 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:35:11 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:35:11 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:35:11 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:35:11 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:35:11 --> Controller Class Initialized
INFO - 2024-08-09 11:35:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:35:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:35:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:35:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:35:11 --> Final output sent to browser
DEBUG - 2024-08-09 11:35:11 --> Total execution time: 0.1346
INFO - 2024-08-09 11:35:14 --> Config Class Initialized
INFO - 2024-08-09 11:35:14 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:35:14 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:35:14 --> Utf8 Class Initialized
INFO - 2024-08-09 11:35:14 --> URI Class Initialized
INFO - 2024-08-09 11:35:14 --> Router Class Initialized
INFO - 2024-08-09 11:35:14 --> Output Class Initialized
INFO - 2024-08-09 11:35:14 --> Security Class Initialized
DEBUG - 2024-08-09 11:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:35:14 --> Input Class Initialized
INFO - 2024-08-09 11:35:14 --> Language Class Initialized
INFO - 2024-08-09 11:35:14 --> Loader Class Initialized
INFO - 2024-08-09 11:35:14 --> Helper loaded: url_helper
INFO - 2024-08-09 11:35:14 --> Helper loaded: form_helper
INFO - 2024-08-09 11:35:14 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:35:14 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:35:14 --> Email Class Initialized
INFO - 2024-08-09 11:35:14 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:35:14 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:35:14 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:35:14 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:35:14 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:35:14 --> Controller Class Initialized
INFO - 2024-08-09 11:35:14 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:35:14 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:35:14 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:35:14 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:35:14 --> Final output sent to browser
DEBUG - 2024-08-09 11:35:14 --> Total execution time: 0.1121
INFO - 2024-08-09 11:35:14 --> Config Class Initialized
INFO - 2024-08-09 11:35:14 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:35:14 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:35:14 --> Utf8 Class Initialized
INFO - 2024-08-09 11:35:14 --> Config Class Initialized
INFO - 2024-08-09 11:35:14 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:35:14 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:35:14 --> Utf8 Class Initialized
INFO - 2024-08-09 11:35:14 --> URI Class Initialized
INFO - 2024-08-09 11:35:14 --> Router Class Initialized
INFO - 2024-08-09 11:35:14 --> Output Class Initialized
INFO - 2024-08-09 11:35:14 --> Security Class Initialized
DEBUG - 2024-08-09 11:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:35:14 --> Input Class Initialized
INFO - 2024-08-09 11:35:14 --> Language Class Initialized
INFO - 2024-08-09 11:35:14 --> Loader Class Initialized
INFO - 2024-08-09 11:35:14 --> Helper loaded: url_helper
INFO - 2024-08-09 11:35:14 --> Helper loaded: form_helper
INFO - 2024-08-09 11:35:14 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:35:14 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:35:14 --> Email Class Initialized
INFO - 2024-08-09 11:35:14 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:35:14 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:35:14 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:35:14 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:35:14 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:35:14 --> Controller Class Initialized
INFO - 2024-08-09 11:35:14 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:35:14 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:35:14 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:35:14 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:35:14 --> Final output sent to browser
DEBUG - 2024-08-09 11:35:14 --> Total execution time: 0.1372
INFO - 2024-08-09 11:35:15 --> Config Class Initialized
INFO - 2024-08-09 11:35:15 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:35:15 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:35:15 --> Utf8 Class Initialized
INFO - 2024-08-09 11:35:15 --> URI Class Initialized
INFO - 2024-08-09 11:35:15 --> Router Class Initialized
INFO - 2024-08-09 11:35:15 --> Output Class Initialized
INFO - 2024-08-09 11:35:15 --> Security Class Initialized
DEBUG - 2024-08-09 11:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:35:15 --> Input Class Initialized
INFO - 2024-08-09 11:35:15 --> Language Class Initialized
INFO - 2024-08-09 11:35:15 --> Loader Class Initialized
INFO - 2024-08-09 11:35:15 --> Helper loaded: url_helper
INFO - 2024-08-09 11:35:15 --> Helper loaded: form_helper
INFO - 2024-08-09 11:35:15 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:35:15 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:35:15 --> Email Class Initialized
INFO - 2024-08-09 11:35:15 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:35:15 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:35:15 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:35:15 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:35:15 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:35:15 --> Controller Class Initialized
INFO - 2024-08-09 11:35:15 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:35:15 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:35:15 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:35:15 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:35:15 --> Final output sent to browser
DEBUG - 2024-08-09 11:35:15 --> Total execution time: 0.1284
INFO - 2024-08-09 11:35:16 --> Config Class Initialized
INFO - 2024-08-09 11:35:16 --> Hooks Class Initialized
INFO - 2024-08-09 11:35:16 --> Config Class Initialized
INFO - 2024-08-09 11:35:16 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:35:16 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:35:16 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:35:16 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:35:16 --> Utf8 Class Initialized
INFO - 2024-08-09 11:35:16 --> URI Class Initialized
INFO - 2024-08-09 11:35:16 --> Router Class Initialized
INFO - 2024-08-09 11:35:16 --> Output Class Initialized
INFO - 2024-08-09 11:35:16 --> Security Class Initialized
DEBUG - 2024-08-09 11:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:35:16 --> Input Class Initialized
INFO - 2024-08-09 11:35:16 --> Language Class Initialized
INFO - 2024-08-09 11:35:16 --> Loader Class Initialized
INFO - 2024-08-09 11:35:16 --> Helper loaded: url_helper
INFO - 2024-08-09 11:35:16 --> Helper loaded: form_helper
INFO - 2024-08-09 11:35:16 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:35:16 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:35:16 --> Email Class Initialized
INFO - 2024-08-09 11:35:16 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:35:16 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:35:16 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:35:16 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:35:16 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:35:16 --> Controller Class Initialized
INFO - 2024-08-09 11:35:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:35:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:35:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:35:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:35:16 --> Final output sent to browser
DEBUG - 2024-08-09 11:35:16 --> Total execution time: 0.1312
INFO - 2024-08-09 11:35:18 --> Config Class Initialized
INFO - 2024-08-09 11:35:18 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:35:18 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:35:18 --> Utf8 Class Initialized
INFO - 2024-08-09 11:35:18 --> URI Class Initialized
INFO - 2024-08-09 11:35:18 --> Router Class Initialized
INFO - 2024-08-09 11:35:18 --> Output Class Initialized
INFO - 2024-08-09 11:35:18 --> Security Class Initialized
DEBUG - 2024-08-09 11:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:35:18 --> Input Class Initialized
INFO - 2024-08-09 11:35:18 --> Language Class Initialized
INFO - 2024-08-09 11:35:18 --> Loader Class Initialized
INFO - 2024-08-09 11:35:18 --> Helper loaded: url_helper
INFO - 2024-08-09 11:35:18 --> Helper loaded: form_helper
INFO - 2024-08-09 11:35:18 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:35:18 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:35:18 --> Email Class Initialized
INFO - 2024-08-09 11:35:18 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:35:18 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:35:18 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:35:18 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:35:18 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:35:18 --> Controller Class Initialized
INFO - 2024-08-09 11:35:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:35:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:35:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:35:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:35:18 --> Final output sent to browser
DEBUG - 2024-08-09 11:35:18 --> Total execution time: 0.1140
INFO - 2024-08-09 11:35:18 --> Config Class Initialized
INFO - 2024-08-09 11:35:18 --> Hooks Class Initialized
INFO - 2024-08-09 11:35:18 --> Config Class Initialized
INFO - 2024-08-09 11:35:18 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:35:18 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:35:18 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:35:18 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:35:18 --> Utf8 Class Initialized
INFO - 2024-08-09 11:35:18 --> URI Class Initialized
INFO - 2024-08-09 11:35:18 --> Router Class Initialized
INFO - 2024-08-09 11:35:18 --> Output Class Initialized
INFO - 2024-08-09 11:35:18 --> Security Class Initialized
DEBUG - 2024-08-09 11:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:35:18 --> Input Class Initialized
INFO - 2024-08-09 11:35:18 --> Language Class Initialized
INFO - 2024-08-09 11:35:18 --> Loader Class Initialized
INFO - 2024-08-09 11:35:18 --> Helper loaded: url_helper
INFO - 2024-08-09 11:35:18 --> Helper loaded: form_helper
INFO - 2024-08-09 11:35:18 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:35:18 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:35:18 --> Email Class Initialized
INFO - 2024-08-09 11:35:18 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:35:18 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:35:18 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:35:18 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:35:18 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:35:18 --> Controller Class Initialized
INFO - 2024-08-09 11:35:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:35:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:35:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:35:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:35:18 --> Final output sent to browser
DEBUG - 2024-08-09 11:35:18 --> Total execution time: 0.1196
INFO - 2024-08-09 11:35:36 --> Config Class Initialized
INFO - 2024-08-09 11:35:36 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:35:36 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:35:36 --> Utf8 Class Initialized
INFO - 2024-08-09 11:35:36 --> URI Class Initialized
INFO - 2024-08-09 11:35:36 --> Router Class Initialized
INFO - 2024-08-09 11:35:36 --> Output Class Initialized
INFO - 2024-08-09 11:35:36 --> Security Class Initialized
DEBUG - 2024-08-09 11:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:35:36 --> Input Class Initialized
INFO - 2024-08-09 11:35:36 --> Language Class Initialized
INFO - 2024-08-09 11:35:36 --> Loader Class Initialized
INFO - 2024-08-09 11:35:36 --> Helper loaded: url_helper
INFO - 2024-08-09 11:35:36 --> Helper loaded: form_helper
INFO - 2024-08-09 11:35:36 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:35:36 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:35:36 --> Email Class Initialized
INFO - 2024-08-09 11:35:36 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:35:36 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:35:36 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:35:36 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:35:36 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:35:36 --> Controller Class Initialized
INFO - 2024-08-09 11:35:36 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:35:36 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "idUsuario" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 38
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 43
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 49
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 55
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 61
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 67
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 74
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 75
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 76
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 83
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 90
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 94
INFO - 2024-08-09 11:35:36 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:35:36 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:35:36 --> Final output sent to browser
DEBUG - 2024-08-09 11:35:36 --> Total execution time: 0.1418
INFO - 2024-08-09 11:35:36 --> Config Class Initialized
INFO - 2024-08-09 11:35:36 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:35:36 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:35:36 --> Utf8 Class Initialized
INFO - 2024-08-09 11:35:36 --> Config Class Initialized
INFO - 2024-08-09 11:35:36 --> URI Class Initialized
INFO - 2024-08-09 11:35:36 --> Hooks Class Initialized
INFO - 2024-08-09 11:35:36 --> Router Class Initialized
DEBUG - 2024-08-09 11:35:36 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:35:36 --> Utf8 Class Initialized
INFO - 2024-08-09 11:35:36 --> Output Class Initialized
INFO - 2024-08-09 11:35:36 --> Security Class Initialized
DEBUG - 2024-08-09 11:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:35:36 --> Input Class Initialized
INFO - 2024-08-09 11:35:36 --> Language Class Initialized
INFO - 2024-08-09 11:35:36 --> Loader Class Initialized
INFO - 2024-08-09 11:35:36 --> Helper loaded: url_helper
INFO - 2024-08-09 11:35:36 --> Helper loaded: form_helper
INFO - 2024-08-09 11:35:36 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:35:36 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:35:36 --> Email Class Initialized
INFO - 2024-08-09 11:35:36 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:35:36 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:35:36 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:35:36 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:35:36 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:35:36 --> Controller Class Initialized
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 93
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 98
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 99
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 139
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 140
ERROR - 2024-08-09 11:35:36 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 140
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "primerapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 11:35:36 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "segundoapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 142
ERROR - 2024-08-09 11:35:36 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 142
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 143
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 144
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 145
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Undefined array key "genero" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 146
ERROR - 2024-08-09 11:35:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\core\Exceptions.php:272) C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\helpers\url_helper.php 562
INFO - 2024-08-09 11:35:51 --> Config Class Initialized
INFO - 2024-08-09 11:35:51 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:35:51 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:35:51 --> Utf8 Class Initialized
INFO - 2024-08-09 11:35:51 --> URI Class Initialized
INFO - 2024-08-09 11:35:51 --> Router Class Initialized
INFO - 2024-08-09 11:35:51 --> Output Class Initialized
INFO - 2024-08-09 11:35:51 --> Security Class Initialized
DEBUG - 2024-08-09 11:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:35:51 --> Input Class Initialized
INFO - 2024-08-09 11:35:51 --> Language Class Initialized
INFO - 2024-08-09 11:35:51 --> Loader Class Initialized
INFO - 2024-08-09 11:35:51 --> Helper loaded: url_helper
INFO - 2024-08-09 11:35:51 --> Helper loaded: form_helper
INFO - 2024-08-09 11:35:51 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:35:51 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:35:51 --> Email Class Initialized
INFO - 2024-08-09 11:35:51 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:35:51 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:35:51 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:35:51 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:35:51 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:35:51 --> Controller Class Initialized
INFO - 2024-08-09 11:35:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:35:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:35:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:35:51 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:35:51 --> Final output sent to browser
DEBUG - 2024-08-09 11:35:51 --> Total execution time: 0.1270
INFO - 2024-08-09 11:35:52 --> Config Class Initialized
INFO - 2024-08-09 11:35:52 --> Config Class Initialized
INFO - 2024-08-09 11:35:52 --> Hooks Class Initialized
INFO - 2024-08-09 11:35:52 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:35:52 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 11:35:52 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:35:52 --> Utf8 Class Initialized
INFO - 2024-08-09 11:35:52 --> Utf8 Class Initialized
INFO - 2024-08-09 11:35:52 --> URI Class Initialized
INFO - 2024-08-09 11:35:52 --> Router Class Initialized
INFO - 2024-08-09 11:35:52 --> Output Class Initialized
INFO - 2024-08-09 11:35:52 --> Security Class Initialized
DEBUG - 2024-08-09 11:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:35:52 --> Input Class Initialized
INFO - 2024-08-09 11:35:52 --> Language Class Initialized
INFO - 2024-08-09 11:35:52 --> Loader Class Initialized
INFO - 2024-08-09 11:35:52 --> Helper loaded: url_helper
INFO - 2024-08-09 11:35:52 --> Helper loaded: form_helper
INFO - 2024-08-09 11:35:52 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:35:52 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:35:52 --> Email Class Initialized
INFO - 2024-08-09 11:35:52 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:35:52 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:35:52 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:35:52 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:35:52 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:35:52 --> Controller Class Initialized
ERROR - 2024-08-09 11:35:52 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 93
ERROR - 2024-08-09 11:35:52 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 98
ERROR - 2024-08-09 11:35:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 99
ERROR - 2024-08-09 11:35:52 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 139
ERROR - 2024-08-09 11:35:52 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 140
ERROR - 2024-08-09 11:35:52 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 140
ERROR - 2024-08-09 11:35:52 --> Severity: Warning --> Undefined array key "primerapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 11:35:52 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 11:35:52 --> Severity: Warning --> Undefined array key "segundoapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 142
ERROR - 2024-08-09 11:35:52 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 142
ERROR - 2024-08-09 11:35:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 143
ERROR - 2024-08-09 11:35:52 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 144
ERROR - 2024-08-09 11:35:52 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 145
ERROR - 2024-08-09 11:35:52 --> Severity: Warning --> Undefined array key "genero" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 146
ERROR - 2024-08-09 11:35:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\core\Exceptions.php:272) C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\helpers\url_helper.php 562
INFO - 2024-08-09 11:37:05 --> Config Class Initialized
INFO - 2024-08-09 11:37:05 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:37:05 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:37:05 --> Utf8 Class Initialized
INFO - 2024-08-09 11:37:05 --> URI Class Initialized
INFO - 2024-08-09 11:37:05 --> Router Class Initialized
INFO - 2024-08-09 11:37:05 --> Output Class Initialized
INFO - 2024-08-09 11:37:05 --> Security Class Initialized
DEBUG - 2024-08-09 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:37:05 --> Input Class Initialized
INFO - 2024-08-09 11:37:05 --> Language Class Initialized
INFO - 2024-08-09 11:37:05 --> Loader Class Initialized
INFO - 2024-08-09 11:37:05 --> Helper loaded: url_helper
INFO - 2024-08-09 11:37:05 --> Helper loaded: form_helper
INFO - 2024-08-09 11:37:05 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:37:05 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:37:05 --> Email Class Initialized
INFO - 2024-08-09 11:37:05 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:37:05 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:37:05 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:37:05 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:37:05 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:37:05 --> Controller Class Initialized
INFO - 2024-08-09 11:37:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:37:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:37:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:37:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:37:05 --> Final output sent to browser
DEBUG - 2024-08-09 11:37:05 --> Total execution time: 0.1729
INFO - 2024-08-09 11:37:05 --> Config Class Initialized
INFO - 2024-08-09 11:37:05 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:37:05 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:37:05 --> Utf8 Class Initialized
INFO - 2024-08-09 11:37:05 --> URI Class Initialized
INFO - 2024-08-09 11:37:05 --> Router Class Initialized
INFO - 2024-08-09 11:37:05 --> Config Class Initialized
INFO - 2024-08-09 11:37:05 --> Hooks Class Initialized
INFO - 2024-08-09 11:37:05 --> Output Class Initialized
INFO - 2024-08-09 11:37:05 --> Security Class Initialized
DEBUG - 2024-08-09 11:37:05 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:37:05 --> Utf8 Class Initialized
INFO - 2024-08-09 11:37:05 --> Input Class Initialized
INFO - 2024-08-09 11:37:05 --> Language Class Initialized
INFO - 2024-08-09 11:37:05 --> Loader Class Initialized
INFO - 2024-08-09 11:37:05 --> Helper loaded: url_helper
INFO - 2024-08-09 11:37:05 --> Helper loaded: form_helper
INFO - 2024-08-09 11:37:05 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:37:05 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:37:05 --> Email Class Initialized
INFO - 2024-08-09 11:37:05 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:37:05 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:37:05 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:37:05 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:37:05 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:37:05 --> Controller Class Initialized
ERROR - 2024-08-09 11:37:05 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 93
ERROR - 2024-08-09 11:37:05 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 98
ERROR - 2024-08-09 11:37:05 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 99
ERROR - 2024-08-09 11:37:05 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 140
ERROR - 2024-08-09 11:37:05 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 11:37:05 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 11:37:05 --> Severity: Warning --> Undefined array key "primerapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 142
ERROR - 2024-08-09 11:37:05 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 142
ERROR - 2024-08-09 11:37:05 --> Severity: Warning --> Undefined array key "segundoapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 143
ERROR - 2024-08-09 11:37:05 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 143
ERROR - 2024-08-09 11:37:05 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 144
ERROR - 2024-08-09 11:37:05 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 145
ERROR - 2024-08-09 11:37:05 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 146
ERROR - 2024-08-09 11:37:05 --> Severity: Warning --> Undefined array key "genero" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 147
ERROR - 2024-08-09 11:37:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\core\Exceptions.php:272) C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\helpers\url_helper.php 562
INFO - 2024-08-09 11:37:39 --> Config Class Initialized
INFO - 2024-08-09 11:37:39 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:37:39 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:37:39 --> Utf8 Class Initialized
INFO - 2024-08-09 11:37:39 --> URI Class Initialized
INFO - 2024-08-09 11:37:39 --> Router Class Initialized
INFO - 2024-08-09 11:37:39 --> Output Class Initialized
INFO - 2024-08-09 11:37:39 --> Security Class Initialized
DEBUG - 2024-08-09 11:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:37:39 --> Input Class Initialized
INFO - 2024-08-09 11:37:39 --> Language Class Initialized
INFO - 2024-08-09 11:37:39 --> Loader Class Initialized
INFO - 2024-08-09 11:37:39 --> Helper loaded: url_helper
INFO - 2024-08-09 11:37:39 --> Helper loaded: form_helper
INFO - 2024-08-09 11:37:39 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:37:39 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:37:39 --> Email Class Initialized
INFO - 2024-08-09 11:37:39 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:37:39 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:37:39 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:37:39 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:37:39 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:37:39 --> Controller Class Initialized
INFO - 2024-08-09 11:37:39 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:37:39 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:37:39 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:37:39 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:37:39 --> Final output sent to browser
DEBUG - 2024-08-09 11:37:39 --> Total execution time: 0.2177
INFO - 2024-08-09 11:37:40 --> Config Class Initialized
INFO - 2024-08-09 11:37:40 --> Hooks Class Initialized
INFO - 2024-08-09 11:37:40 --> Config Class Initialized
INFO - 2024-08-09 11:37:40 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:37:40 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:37:40 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:37:40 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:37:40 --> Utf8 Class Initialized
INFO - 2024-08-09 11:37:40 --> URI Class Initialized
INFO - 2024-08-09 11:37:40 --> Router Class Initialized
INFO - 2024-08-09 11:37:40 --> Output Class Initialized
INFO - 2024-08-09 11:37:40 --> Security Class Initialized
DEBUG - 2024-08-09 11:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:37:40 --> Input Class Initialized
INFO - 2024-08-09 11:37:40 --> Language Class Initialized
INFO - 2024-08-09 11:37:40 --> Loader Class Initialized
INFO - 2024-08-09 11:37:40 --> Helper loaded: url_helper
INFO - 2024-08-09 11:37:40 --> Helper loaded: form_helper
INFO - 2024-08-09 11:37:40 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:37:40 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:37:40 --> Email Class Initialized
INFO - 2024-08-09 11:37:40 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:37:40 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:37:40 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:37:40 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:37:40 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:37:40 --> Controller Class Initialized
ERROR - 2024-08-09 11:37:40 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 93
ERROR - 2024-08-09 11:37:40 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 98
ERROR - 2024-08-09 11:37:40 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 99
ERROR - 2024-08-09 11:37:40 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 140
ERROR - 2024-08-09 11:37:40 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 11:37:40 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 11:37:40 --> Severity: Warning --> Undefined array key "primerapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 142
ERROR - 2024-08-09 11:37:40 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 142
ERROR - 2024-08-09 11:37:40 --> Severity: Warning --> Undefined array key "segundoapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 143
ERROR - 2024-08-09 11:37:40 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 143
ERROR - 2024-08-09 11:37:40 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 144
ERROR - 2024-08-09 11:37:40 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 145
ERROR - 2024-08-09 11:37:40 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 146
ERROR - 2024-08-09 11:37:40 --> Severity: Warning --> Undefined array key "genero" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 147
ERROR - 2024-08-09 11:37:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\core\Exceptions.php:272) C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\helpers\url_helper.php 562
INFO - 2024-08-09 11:37:43 --> Config Class Initialized
INFO - 2024-08-09 11:37:43 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:37:43 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:37:43 --> Utf8 Class Initialized
INFO - 2024-08-09 11:37:43 --> URI Class Initialized
INFO - 2024-08-09 11:37:43 --> Router Class Initialized
INFO - 2024-08-09 11:37:43 --> Output Class Initialized
INFO - 2024-08-09 11:37:43 --> Security Class Initialized
DEBUG - 2024-08-09 11:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:37:43 --> Input Class Initialized
INFO - 2024-08-09 11:37:43 --> Language Class Initialized
INFO - 2024-08-09 11:37:43 --> Loader Class Initialized
INFO - 2024-08-09 11:37:43 --> Helper loaded: url_helper
INFO - 2024-08-09 11:37:43 --> Helper loaded: form_helper
INFO - 2024-08-09 11:37:43 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:37:43 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:37:43 --> Email Class Initialized
INFO - 2024-08-09 11:37:43 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:37:43 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:37:43 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:37:43 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:37:43 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:37:43 --> Controller Class Initialized
INFO - 2024-08-09 11:37:43 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:37:43 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:37:43 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:37:43 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:37:43 --> Final output sent to browser
DEBUG - 2024-08-09 11:37:43 --> Total execution time: 0.1062
INFO - 2024-08-09 11:37:44 --> Config Class Initialized
INFO - 2024-08-09 11:37:44 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:37:44 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:37:44 --> Utf8 Class Initialized
INFO - 2024-08-09 11:37:44 --> Config Class Initialized
INFO - 2024-08-09 11:37:44 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:37:44 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:37:44 --> Utf8 Class Initialized
INFO - 2024-08-09 11:37:44 --> URI Class Initialized
INFO - 2024-08-09 11:37:44 --> Router Class Initialized
INFO - 2024-08-09 11:37:44 --> Output Class Initialized
INFO - 2024-08-09 11:37:44 --> Security Class Initialized
DEBUG - 2024-08-09 11:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:37:44 --> Input Class Initialized
INFO - 2024-08-09 11:37:44 --> Language Class Initialized
INFO - 2024-08-09 11:37:44 --> Loader Class Initialized
INFO - 2024-08-09 11:37:44 --> Helper loaded: url_helper
INFO - 2024-08-09 11:37:44 --> Helper loaded: form_helper
INFO - 2024-08-09 11:37:44 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:37:44 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:37:44 --> Email Class Initialized
INFO - 2024-08-09 11:37:44 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:37:44 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:37:44 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:37:44 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:37:44 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:37:44 --> Controller Class Initialized
INFO - 2024-08-09 11:37:44 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:37:44 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:37:44 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:37:44 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:37:44 --> Final output sent to browser
DEBUG - 2024-08-09 11:37:44 --> Total execution time: 0.1409
INFO - 2024-08-09 11:37:50 --> Config Class Initialized
INFO - 2024-08-09 11:37:50 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:37:50 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:37:50 --> Utf8 Class Initialized
INFO - 2024-08-09 11:37:50 --> URI Class Initialized
INFO - 2024-08-09 11:37:50 --> Router Class Initialized
INFO - 2024-08-09 11:37:50 --> Output Class Initialized
INFO - 2024-08-09 11:37:50 --> Security Class Initialized
DEBUG - 2024-08-09 11:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:37:50 --> Input Class Initialized
INFO - 2024-08-09 11:37:50 --> Language Class Initialized
INFO - 2024-08-09 11:37:50 --> Loader Class Initialized
INFO - 2024-08-09 11:37:50 --> Helper loaded: url_helper
INFO - 2024-08-09 11:37:50 --> Helper loaded: form_helper
INFO - 2024-08-09 11:37:50 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:37:50 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:37:50 --> Email Class Initialized
INFO - 2024-08-09 11:37:50 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:37:50 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:37:50 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:37:50 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:37:50 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:37:50 --> Controller Class Initialized
INFO - 2024-08-09 11:37:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:37:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:37:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:37:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:37:50 --> Final output sent to browser
DEBUG - 2024-08-09 11:37:50 --> Total execution time: 0.1089
INFO - 2024-08-09 11:37:50 --> Config Class Initialized
INFO - 2024-08-09 11:37:50 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:37:50 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:37:50 --> Utf8 Class Initialized
INFO - 2024-08-09 11:37:50 --> Config Class Initialized
INFO - 2024-08-09 11:37:50 --> URI Class Initialized
INFO - 2024-08-09 11:37:50 --> Hooks Class Initialized
INFO - 2024-08-09 11:37:50 --> Router Class Initialized
INFO - 2024-08-09 11:37:50 --> Output Class Initialized
DEBUG - 2024-08-09 11:37:50 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:37:50 --> Utf8 Class Initialized
INFO - 2024-08-09 11:37:50 --> Security Class Initialized
DEBUG - 2024-08-09 11:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:37:50 --> Input Class Initialized
INFO - 2024-08-09 11:37:50 --> Language Class Initialized
INFO - 2024-08-09 11:37:50 --> Loader Class Initialized
INFO - 2024-08-09 11:37:50 --> Helper loaded: url_helper
INFO - 2024-08-09 11:37:50 --> Helper loaded: form_helper
INFO - 2024-08-09 11:37:50 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:37:50 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:37:50 --> Email Class Initialized
INFO - 2024-08-09 11:37:50 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:37:50 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:37:50 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:37:50 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:37:50 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:37:50 --> Controller Class Initialized
INFO - 2024-08-09 11:37:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:37:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:37:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:37:50 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:37:50 --> Final output sent to browser
DEBUG - 2024-08-09 11:37:50 --> Total execution time: 0.1377
INFO - 2024-08-09 11:38:08 --> Config Class Initialized
INFO - 2024-08-09 11:38:08 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:38:08 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:38:08 --> Utf8 Class Initialized
INFO - 2024-08-09 11:38:08 --> URI Class Initialized
INFO - 2024-08-09 11:38:08 --> Router Class Initialized
INFO - 2024-08-09 11:38:08 --> Output Class Initialized
INFO - 2024-08-09 11:38:08 --> Security Class Initialized
DEBUG - 2024-08-09 11:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:38:08 --> Input Class Initialized
INFO - 2024-08-09 11:38:08 --> Language Class Initialized
INFO - 2024-08-09 11:38:08 --> Loader Class Initialized
INFO - 2024-08-09 11:38:08 --> Helper loaded: url_helper
INFO - 2024-08-09 11:38:08 --> Helper loaded: form_helper
INFO - 2024-08-09 11:38:08 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:38:08 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:38:08 --> Email Class Initialized
INFO - 2024-08-09 11:38:08 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:38:08 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:38:08 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:38:08 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:38:08 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:38:08 --> Controller Class Initialized
INFO - 2024-08-09 11:38:08 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:38:08 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:38:08 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:38:08 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:38:08 --> Final output sent to browser
DEBUG - 2024-08-09 11:38:08 --> Total execution time: 0.1168
INFO - 2024-08-09 11:38:08 --> Config Class Initialized
INFO - 2024-08-09 11:38:08 --> Hooks Class Initialized
INFO - 2024-08-09 11:38:08 --> Config Class Initialized
INFO - 2024-08-09 11:38:08 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:38:08 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:38:08 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:38:08 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:38:08 --> URI Class Initialized
INFO - 2024-08-09 11:38:08 --> Utf8 Class Initialized
INFO - 2024-08-09 11:38:08 --> Router Class Initialized
INFO - 2024-08-09 11:38:08 --> Output Class Initialized
INFO - 2024-08-09 11:38:08 --> Security Class Initialized
DEBUG - 2024-08-09 11:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:38:08 --> Input Class Initialized
INFO - 2024-08-09 11:38:08 --> Language Class Initialized
INFO - 2024-08-09 11:38:08 --> Loader Class Initialized
INFO - 2024-08-09 11:38:08 --> Helper loaded: url_helper
INFO - 2024-08-09 11:38:08 --> Helper loaded: form_helper
INFO - 2024-08-09 11:38:08 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:38:08 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:38:08 --> Email Class Initialized
INFO - 2024-08-09 11:38:08 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:38:08 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:38:08 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:38:08 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:38:08 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:38:08 --> Controller Class Initialized
ERROR - 2024-08-09 11:38:08 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 93
ERROR - 2024-08-09 11:38:08 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 98
ERROR - 2024-08-09 11:38:08 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 99
ERROR - 2024-08-09 11:38:08 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 140
ERROR - 2024-08-09 11:38:08 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 11:38:08 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 11:38:08 --> Severity: Warning --> Undefined array key "primerapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 142
ERROR - 2024-08-09 11:38:08 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 142
ERROR - 2024-08-09 11:38:08 --> Severity: Warning --> Undefined array key "segundoapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 143
ERROR - 2024-08-09 11:38:08 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 143
ERROR - 2024-08-09 11:38:08 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 144
ERROR - 2024-08-09 11:38:08 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 145
ERROR - 2024-08-09 11:38:08 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 146
ERROR - 2024-08-09 11:38:08 --> Severity: Warning --> Undefined array key "genero" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 147
ERROR - 2024-08-09 11:38:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\core\Exceptions.php:272) C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\helpers\url_helper.php 562
INFO - 2024-08-09 11:45:13 --> Config Class Initialized
INFO - 2024-08-09 11:45:13 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:13 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:13 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:13 --> URI Class Initialized
INFO - 2024-08-09 11:45:13 --> Router Class Initialized
INFO - 2024-08-09 11:45:13 --> Output Class Initialized
INFO - 2024-08-09 11:45:13 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:13 --> Input Class Initialized
INFO - 2024-08-09 11:45:13 --> Language Class Initialized
INFO - 2024-08-09 11:45:13 --> Loader Class Initialized
INFO - 2024-08-09 11:45:13 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:13 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:13 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:13 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:13 --> Email Class Initialized
INFO - 2024-08-09 11:45:13 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:13 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:13 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:13 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:13 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:13 --> Controller Class Initialized
INFO - 2024-08-09 11:45:13 --> Config Class Initialized
INFO - 2024-08-09 11:45:13 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:13 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:13 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:13 --> URI Class Initialized
INFO - 2024-08-09 11:45:13 --> Router Class Initialized
INFO - 2024-08-09 11:45:13 --> Output Class Initialized
INFO - 2024-08-09 11:45:13 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:13 --> Input Class Initialized
INFO - 2024-08-09 11:45:13 --> Language Class Initialized
INFO - 2024-08-09 11:45:13 --> Loader Class Initialized
INFO - 2024-08-09 11:45:13 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:13 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:13 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:13 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:13 --> Email Class Initialized
INFO - 2024-08-09 11:45:13 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:13 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:13 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:13 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:13 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:13 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:13 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:13 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:13 --> Total execution time: 0.0967
INFO - 2024-08-09 11:45:14 --> Config Class Initialized
INFO - 2024-08-09 11:45:14 --> Hooks Class Initialized
INFO - 2024-08-09 11:45:14 --> Config Class Initialized
INFO - 2024-08-09 11:45:14 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:14 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:14 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:45:14 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:14 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:14 --> URI Class Initialized
INFO - 2024-08-09 11:45:14 --> Router Class Initialized
INFO - 2024-08-09 11:45:14 --> Output Class Initialized
INFO - 2024-08-09 11:45:14 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:14 --> Input Class Initialized
INFO - 2024-08-09 11:45:14 --> Language Class Initialized
INFO - 2024-08-09 11:45:14 --> Loader Class Initialized
INFO - 2024-08-09 11:45:14 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:14 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:14 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:14 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:14 --> Email Class Initialized
INFO - 2024-08-09 11:45:14 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:14 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:14 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:14 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:14 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:14 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:14 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:14 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:14 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:14 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:14 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:14 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:14 --> Total execution time: 0.1188
INFO - 2024-08-09 11:45:15 --> Config Class Initialized
INFO - 2024-08-09 11:45:15 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:15 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:15 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:15 --> URI Class Initialized
INFO - 2024-08-09 11:45:15 --> Router Class Initialized
INFO - 2024-08-09 11:45:15 --> Output Class Initialized
INFO - 2024-08-09 11:45:15 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:15 --> Input Class Initialized
INFO - 2024-08-09 11:45:15 --> Language Class Initialized
INFO - 2024-08-09 11:45:15 --> Loader Class Initialized
INFO - 2024-08-09 11:45:15 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:15 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:15 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:15 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:15 --> Email Class Initialized
INFO - 2024-08-09 11:45:15 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:15 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:15 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:15 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:15 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:15 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:15 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:15 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:15 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:15 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:15 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:15 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:15 --> Total execution time: 0.1297
INFO - 2024-08-09 11:45:16 --> Config Class Initialized
INFO - 2024-08-09 11:45:16 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:16 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:16 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:16 --> URI Class Initialized
INFO - 2024-08-09 11:45:16 --> Router Class Initialized
INFO - 2024-08-09 11:45:16 --> Config Class Initialized
INFO - 2024-08-09 11:45:16 --> Hooks Class Initialized
INFO - 2024-08-09 11:45:16 --> Output Class Initialized
INFO - 2024-08-09 11:45:16 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:16 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 11:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:16 --> Input Class Initialized
INFO - 2024-08-09 11:45:16 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:16 --> Language Class Initialized
INFO - 2024-08-09 11:45:16 --> Loader Class Initialized
INFO - 2024-08-09 11:45:16 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:16 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:16 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:16 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:16 --> Email Class Initialized
INFO - 2024-08-09 11:45:16 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:16 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:16 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:16 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:16 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:16 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:16 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:16 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:16 --> Total execution time: 0.1192
INFO - 2024-08-09 11:45:16 --> Config Class Initialized
INFO - 2024-08-09 11:45:16 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:16 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:16 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:16 --> URI Class Initialized
INFO - 2024-08-09 11:45:16 --> Router Class Initialized
INFO - 2024-08-09 11:45:16 --> Output Class Initialized
INFO - 2024-08-09 11:45:16 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:16 --> Input Class Initialized
INFO - 2024-08-09 11:45:16 --> Language Class Initialized
INFO - 2024-08-09 11:45:16 --> Loader Class Initialized
INFO - 2024-08-09 11:45:16 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:16 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:16 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:16 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:16 --> Email Class Initialized
INFO - 2024-08-09 11:45:16 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:16 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:16 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:16 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:16 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:16 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:16 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:16 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:16 --> Total execution time: 0.0965
INFO - 2024-08-09 11:45:17 --> Config Class Initialized
INFO - 2024-08-09 11:45:17 --> Hooks Class Initialized
INFO - 2024-08-09 11:45:17 --> Config Class Initialized
INFO - 2024-08-09 11:45:17 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:17 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 11:45:17 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:17 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:17 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:17 --> URI Class Initialized
INFO - 2024-08-09 11:45:17 --> Router Class Initialized
INFO - 2024-08-09 11:45:17 --> Output Class Initialized
INFO - 2024-08-09 11:45:17 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:17 --> Input Class Initialized
INFO - 2024-08-09 11:45:17 --> Language Class Initialized
INFO - 2024-08-09 11:45:17 --> Loader Class Initialized
INFO - 2024-08-09 11:45:17 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:17 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:17 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:17 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:17 --> Email Class Initialized
INFO - 2024-08-09 11:45:17 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:17 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:17 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:17 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:17 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:17 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:17 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:17 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:17 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:17 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:17 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:17 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:17 --> Total execution time: 0.1381
INFO - 2024-08-09 11:45:17 --> Config Class Initialized
INFO - 2024-08-09 11:45:17 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:17 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:17 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:17 --> URI Class Initialized
INFO - 2024-08-09 11:45:17 --> Router Class Initialized
INFO - 2024-08-09 11:45:17 --> Output Class Initialized
INFO - 2024-08-09 11:45:17 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:17 --> Input Class Initialized
INFO - 2024-08-09 11:45:17 --> Language Class Initialized
INFO - 2024-08-09 11:45:17 --> Loader Class Initialized
INFO - 2024-08-09 11:45:17 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:17 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:17 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:17 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:17 --> Email Class Initialized
INFO - 2024-08-09 11:45:17 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:17 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:17 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:17 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:17 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:17 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:17 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:17 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:17 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:17 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:17 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:17 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:17 --> Total execution time: 0.1165
INFO - 2024-08-09 11:45:18 --> Config Class Initialized
INFO - 2024-08-09 11:45:18 --> Hooks Class Initialized
INFO - 2024-08-09 11:45:18 --> Config Class Initialized
INFO - 2024-08-09 11:45:18 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:18 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 11:45:18 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:18 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:18 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:18 --> URI Class Initialized
INFO - 2024-08-09 11:45:18 --> Router Class Initialized
INFO - 2024-08-09 11:45:18 --> Output Class Initialized
INFO - 2024-08-09 11:45:18 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:18 --> Input Class Initialized
INFO - 2024-08-09 11:45:18 --> Language Class Initialized
INFO - 2024-08-09 11:45:18 --> Loader Class Initialized
INFO - 2024-08-09 11:45:18 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:18 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:18 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:18 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:18 --> Email Class Initialized
INFO - 2024-08-09 11:45:18 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:18 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:18 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:18 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:18 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:18 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:18 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:18 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:18 --> Total execution time: 0.1488
INFO - 2024-08-09 11:45:18 --> Config Class Initialized
INFO - 2024-08-09 11:45:19 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:19 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:19 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:19 --> URI Class Initialized
INFO - 2024-08-09 11:45:19 --> Router Class Initialized
INFO - 2024-08-09 11:45:19 --> Output Class Initialized
INFO - 2024-08-09 11:45:19 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:19 --> Input Class Initialized
INFO - 2024-08-09 11:45:19 --> Language Class Initialized
INFO - 2024-08-09 11:45:19 --> Loader Class Initialized
INFO - 2024-08-09 11:45:19 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:19 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:19 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:19 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:19 --> Email Class Initialized
INFO - 2024-08-09 11:45:19 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:19 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:19 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:19 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:19 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:19 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:19 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:19 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:19 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:19 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:19 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:19 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:19 --> Total execution time: 0.1078
INFO - 2024-08-09 11:45:19 --> Config Class Initialized
INFO - 2024-08-09 11:45:19 --> Hooks Class Initialized
INFO - 2024-08-09 11:45:19 --> Config Class Initialized
INFO - 2024-08-09 11:45:19 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:19 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:19 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:45:19 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:19 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:19 --> URI Class Initialized
INFO - 2024-08-09 11:45:19 --> Router Class Initialized
INFO - 2024-08-09 11:45:19 --> Output Class Initialized
INFO - 2024-08-09 11:45:19 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:19 --> Input Class Initialized
INFO - 2024-08-09 11:45:19 --> Language Class Initialized
INFO - 2024-08-09 11:45:19 --> Loader Class Initialized
INFO - 2024-08-09 11:45:19 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:19 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:19 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:19 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:19 --> Email Class Initialized
INFO - 2024-08-09 11:45:19 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:19 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:19 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:19 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:19 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:19 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:19 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:19 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:19 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:19 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:19 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:19 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:19 --> Total execution time: 0.1851
INFO - 2024-08-09 11:45:21 --> Config Class Initialized
INFO - 2024-08-09 11:45:21 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:21 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:21 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:21 --> URI Class Initialized
INFO - 2024-08-09 11:45:21 --> Router Class Initialized
INFO - 2024-08-09 11:45:21 --> Output Class Initialized
INFO - 2024-08-09 11:45:21 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:21 --> Input Class Initialized
INFO - 2024-08-09 11:45:21 --> Language Class Initialized
INFO - 2024-08-09 11:45:21 --> Loader Class Initialized
INFO - 2024-08-09 11:45:21 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:21 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:21 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:21 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:21 --> Email Class Initialized
INFO - 2024-08-09 11:45:21 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:21 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:21 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:21 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:21 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:21 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:21 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:21 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:21 --> Total execution time: 0.0926
INFO - 2024-08-09 11:45:21 --> Config Class Initialized
INFO - 2024-08-09 11:45:21 --> Config Class Initialized
INFO - 2024-08-09 11:45:21 --> Hooks Class Initialized
INFO - 2024-08-09 11:45:21 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:21 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 11:45:21 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:21 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:21 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:21 --> URI Class Initialized
INFO - 2024-08-09 11:45:21 --> Router Class Initialized
INFO - 2024-08-09 11:45:21 --> Output Class Initialized
INFO - 2024-08-09 11:45:21 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:21 --> Input Class Initialized
INFO - 2024-08-09 11:45:21 --> Language Class Initialized
INFO - 2024-08-09 11:45:21 --> Loader Class Initialized
INFO - 2024-08-09 11:45:21 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:21 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:21 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:21 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:21 --> Config Class Initialized
INFO - 2024-08-09 11:45:21 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:21 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:21 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:21 --> URI Class Initialized
INFO - 2024-08-09 11:45:21 --> Router Class Initialized
INFO - 2024-08-09 11:45:21 --> Output Class Initialized
INFO - 2024-08-09 11:45:21 --> Email Class Initialized
INFO - 2024-08-09 11:45:21 --> Security Class Initialized
INFO - 2024-08-09 11:45:21 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:21 --> Model "Pais_model" initialized
DEBUG - 2024-08-09 11:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:21 --> Input Class Initialized
INFO - 2024-08-09 11:45:21 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:21 --> Language Class Initialized
INFO - 2024-08-09 11:45:21 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:21 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:21 --> Controller Class Initialized
INFO - 2024-08-09 11:45:21 --> Loader Class Initialized
ERROR - 2024-08-09 11:45:21 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:21 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:21 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:21 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:21 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:21 --> Total execution time: 0.1695
INFO - 2024-08-09 11:45:21 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:21 --> Email Class Initialized
INFO - 2024-08-09 11:45:21 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:21 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:21 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:21 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:21 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:21 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:21 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:21 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:21 --> Total execution time: 0.1290
INFO - 2024-08-09 11:45:21 --> Config Class Initialized
INFO - 2024-08-09 11:45:21 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:21 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:21 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:21 --> URI Class Initialized
INFO - 2024-08-09 11:45:21 --> Router Class Initialized
INFO - 2024-08-09 11:45:21 --> Output Class Initialized
INFO - 2024-08-09 11:45:21 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:21 --> Input Class Initialized
INFO - 2024-08-09 11:45:21 --> Language Class Initialized
INFO - 2024-08-09 11:45:21 --> Loader Class Initialized
INFO - 2024-08-09 11:45:21 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:21 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:21 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:21 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:21 --> Email Class Initialized
INFO - 2024-08-09 11:45:21 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:21 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:21 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:21 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:21 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:21 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:21 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:21 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:21 --> Total execution time: 0.1235
INFO - 2024-08-09 11:45:22 --> Config Class Initialized
INFO - 2024-08-09 11:45:22 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:22 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:22 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:22 --> URI Class Initialized
INFO - 2024-08-09 11:45:22 --> Router Class Initialized
INFO - 2024-08-09 11:45:22 --> Output Class Initialized
INFO - 2024-08-09 11:45:22 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:22 --> Input Class Initialized
INFO - 2024-08-09 11:45:22 --> Language Class Initialized
INFO - 2024-08-09 11:45:22 --> Loader Class Initialized
INFO - 2024-08-09 11:45:22 --> Config Class Initialized
INFO - 2024-08-09 11:45:22 --> Hooks Class Initialized
INFO - 2024-08-09 11:45:22 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:22 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:22 --> Helper loaded: funciones_helper
DEBUG - 2024-08-09 11:45:22 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:22 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:22 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:22 --> Email Class Initialized
INFO - 2024-08-09 11:45:22 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:22 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:22 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:22 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:22 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:22 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:22 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:22 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:22 --> Total execution time: 0.1229
INFO - 2024-08-09 11:45:22 --> Config Class Initialized
INFO - 2024-08-09 11:45:22 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:22 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:22 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:22 --> URI Class Initialized
INFO - 2024-08-09 11:45:22 --> Router Class Initialized
INFO - 2024-08-09 11:45:22 --> Output Class Initialized
INFO - 2024-08-09 11:45:22 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:22 --> Input Class Initialized
INFO - 2024-08-09 11:45:22 --> Language Class Initialized
INFO - 2024-08-09 11:45:22 --> Loader Class Initialized
INFO - 2024-08-09 11:45:22 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:22 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:22 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:22 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:22 --> Email Class Initialized
INFO - 2024-08-09 11:45:22 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:22 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:22 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:22 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:22 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:22 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:22 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:22 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:22 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:22 --> Total execution time: 0.1874
INFO - 2024-08-09 11:45:23 --> Config Class Initialized
INFO - 2024-08-09 11:45:23 --> Hooks Class Initialized
INFO - 2024-08-09 11:45:23 --> Config Class Initialized
INFO - 2024-08-09 11:45:23 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:23 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:23 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:45:23 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:23 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:23 --> URI Class Initialized
INFO - 2024-08-09 11:45:23 --> Router Class Initialized
INFO - 2024-08-09 11:45:23 --> Output Class Initialized
INFO - 2024-08-09 11:45:23 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:23 --> Input Class Initialized
INFO - 2024-08-09 11:45:23 --> Language Class Initialized
INFO - 2024-08-09 11:45:23 --> Loader Class Initialized
INFO - 2024-08-09 11:45:23 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:23 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:23 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:23 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:23 --> Email Class Initialized
INFO - 2024-08-09 11:45:23 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:23 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:23 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:23 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:23 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:23 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:23 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:23 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:23 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:23 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:23 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:23 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:23 --> Total execution time: 0.1170
INFO - 2024-08-09 11:45:23 --> Config Class Initialized
INFO - 2024-08-09 11:45:23 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:23 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:23 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:23 --> URI Class Initialized
INFO - 2024-08-09 11:45:23 --> Router Class Initialized
INFO - 2024-08-09 11:45:23 --> Output Class Initialized
INFO - 2024-08-09 11:45:23 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:23 --> Input Class Initialized
INFO - 2024-08-09 11:45:23 --> Language Class Initialized
INFO - 2024-08-09 11:45:23 --> Loader Class Initialized
INFO - 2024-08-09 11:45:23 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:23 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:23 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:23 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:23 --> Email Class Initialized
INFO - 2024-08-09 11:45:23 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:23 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:23 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:23 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:23 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:23 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:23 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:23 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:23 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:23 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:23 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:23 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:23 --> Total execution time: 0.1209
INFO - 2024-08-09 11:45:23 --> Config Class Initialized
INFO - 2024-08-09 11:45:23 --> Hooks Class Initialized
INFO - 2024-08-09 11:45:23 --> Config Class Initialized
DEBUG - 2024-08-09 11:45:23 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:23 --> Hooks Class Initialized
INFO - 2024-08-09 11:45:23 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:45:23 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:23 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:23 --> URI Class Initialized
INFO - 2024-08-09 11:45:23 --> Router Class Initialized
INFO - 2024-08-09 11:45:23 --> Output Class Initialized
INFO - 2024-08-09 11:45:23 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:23 --> Input Class Initialized
INFO - 2024-08-09 11:45:23 --> Language Class Initialized
INFO - 2024-08-09 11:45:23 --> Loader Class Initialized
INFO - 2024-08-09 11:45:23 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:23 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:23 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:24 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:24 --> Email Class Initialized
INFO - 2024-08-09 11:45:24 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:24 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:24 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:24 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:24 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:24 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:24 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:24 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:24 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:24 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:24 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:24 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:24 --> Total execution time: 0.1221
INFO - 2024-08-09 11:45:24 --> Config Class Initialized
INFO - 2024-08-09 11:45:24 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:24 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:24 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:24 --> URI Class Initialized
INFO - 2024-08-09 11:45:24 --> Router Class Initialized
INFO - 2024-08-09 11:45:24 --> Output Class Initialized
INFO - 2024-08-09 11:45:24 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:24 --> Input Class Initialized
INFO - 2024-08-09 11:45:24 --> Language Class Initialized
INFO - 2024-08-09 11:45:24 --> Loader Class Initialized
INFO - 2024-08-09 11:45:24 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:24 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:24 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:24 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:24 --> Email Class Initialized
INFO - 2024-08-09 11:45:24 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:24 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:24 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:24 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:24 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:24 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:24 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:24 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:24 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:24 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:24 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:24 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:24 --> Total execution time: 0.1067
INFO - 2024-08-09 11:45:24 --> Config Class Initialized
INFO - 2024-08-09 11:45:24 --> Hooks Class Initialized
INFO - 2024-08-09 11:45:24 --> Config Class Initialized
INFO - 2024-08-09 11:45:24 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:24 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:24 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:24 --> URI Class Initialized
INFO - 2024-08-09 11:45:24 --> Router Class Initialized
DEBUG - 2024-08-09 11:45:24 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:24 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:24 --> Output Class Initialized
INFO - 2024-08-09 11:45:24 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:24 --> Input Class Initialized
INFO - 2024-08-09 11:45:24 --> Language Class Initialized
INFO - 2024-08-09 11:45:24 --> Loader Class Initialized
INFO - 2024-08-09 11:45:24 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:24 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:24 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:24 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:24 --> Email Class Initialized
INFO - 2024-08-09 11:45:24 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:24 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:24 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:24 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:24 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:24 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:24 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:24 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:24 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:24 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:24 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:24 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:24 --> Total execution time: 0.1443
INFO - 2024-08-09 11:45:25 --> Config Class Initialized
INFO - 2024-08-09 11:45:25 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:25 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:25 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:25 --> URI Class Initialized
INFO - 2024-08-09 11:45:25 --> Router Class Initialized
INFO - 2024-08-09 11:45:25 --> Output Class Initialized
INFO - 2024-08-09 11:45:25 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:25 --> Input Class Initialized
INFO - 2024-08-09 11:45:25 --> Language Class Initialized
INFO - 2024-08-09 11:45:25 --> Loader Class Initialized
INFO - 2024-08-09 11:45:25 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:25 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:25 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:25 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:25 --> Email Class Initialized
INFO - 2024-08-09 11:45:25 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:25 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:25 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:25 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:25 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:25 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:25 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:25 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:25 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:25 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:25 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:25 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:25 --> Total execution time: 0.1226
INFO - 2024-08-09 11:45:25 --> Config Class Initialized
INFO - 2024-08-09 11:45:25 --> Hooks Class Initialized
INFO - 2024-08-09 11:45:25 --> Config Class Initialized
DEBUG - 2024-08-09 11:45:25 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:25 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:25 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:25 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:25 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:25 --> URI Class Initialized
INFO - 2024-08-09 11:45:25 --> Router Class Initialized
INFO - 2024-08-09 11:45:25 --> Output Class Initialized
INFO - 2024-08-09 11:45:25 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:25 --> Input Class Initialized
INFO - 2024-08-09 11:45:25 --> Language Class Initialized
INFO - 2024-08-09 11:45:25 --> Loader Class Initialized
INFO - 2024-08-09 11:45:25 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:25 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:25 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:25 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:25 --> Email Class Initialized
INFO - 2024-08-09 11:45:25 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:25 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:25 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:25 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:25 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:25 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:25 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:25 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:25 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:25 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:25 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:25 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:25 --> Total execution time: 0.1763
INFO - 2024-08-09 11:45:26 --> Config Class Initialized
INFO - 2024-08-09 11:45:26 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:26 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:26 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:26 --> URI Class Initialized
INFO - 2024-08-09 11:45:26 --> Router Class Initialized
INFO - 2024-08-09 11:45:26 --> Output Class Initialized
INFO - 2024-08-09 11:45:26 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:26 --> Input Class Initialized
INFO - 2024-08-09 11:45:26 --> Language Class Initialized
INFO - 2024-08-09 11:45:26 --> Loader Class Initialized
INFO - 2024-08-09 11:45:26 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:26 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:26 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:26 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:26 --> Email Class Initialized
INFO - 2024-08-09 11:45:26 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:26 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:26 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:26 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:26 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:26 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:26 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:26 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:26 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:26 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:26 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:26 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:26 --> Total execution time: 0.1124
INFO - 2024-08-09 11:45:26 --> Config Class Initialized
INFO - 2024-08-09 11:45:26 --> Hooks Class Initialized
INFO - 2024-08-09 11:45:26 --> Config Class Initialized
INFO - 2024-08-09 11:45:26 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:45:26 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:26 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:45:26 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:45:26 --> Utf8 Class Initialized
INFO - 2024-08-09 11:45:26 --> URI Class Initialized
INFO - 2024-08-09 11:45:26 --> Router Class Initialized
INFO - 2024-08-09 11:45:26 --> Output Class Initialized
INFO - 2024-08-09 11:45:26 --> Security Class Initialized
DEBUG - 2024-08-09 11:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:45:26 --> Input Class Initialized
INFO - 2024-08-09 11:45:26 --> Language Class Initialized
INFO - 2024-08-09 11:45:26 --> Loader Class Initialized
INFO - 2024-08-09 11:45:26 --> Helper loaded: url_helper
INFO - 2024-08-09 11:45:26 --> Helper loaded: form_helper
INFO - 2024-08-09 11:45:26 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:45:26 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:45:26 --> Email Class Initialized
INFO - 2024-08-09 11:45:26 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:45:26 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:45:26 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:45:26 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:45:26 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:45:26 --> Controller Class Initialized
ERROR - 2024-08-09 11:45:26 --> Severity: Warning --> Undefined variable $newid C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 78
INFO - 2024-08-09 11:45:26 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:45:26 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:45:26 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:45:26 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:45:26 --> Final output sent to browser
DEBUG - 2024-08-09 11:45:26 --> Total execution time: 0.1370
INFO - 2024-08-09 11:46:53 --> Config Class Initialized
INFO - 2024-08-09 11:46:53 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:46:53 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:46:53 --> Utf8 Class Initialized
INFO - 2024-08-09 11:46:53 --> URI Class Initialized
INFO - 2024-08-09 11:46:53 --> Router Class Initialized
INFO - 2024-08-09 11:46:53 --> Output Class Initialized
INFO - 2024-08-09 11:46:53 --> Security Class Initialized
DEBUG - 2024-08-09 11:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:46:53 --> Input Class Initialized
INFO - 2024-08-09 11:46:53 --> Language Class Initialized
INFO - 2024-08-09 11:46:53 --> Loader Class Initialized
INFO - 2024-08-09 11:46:53 --> Helper loaded: url_helper
INFO - 2024-08-09 11:46:53 --> Helper loaded: form_helper
INFO - 2024-08-09 11:46:53 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:46:53 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:46:53 --> Email Class Initialized
INFO - 2024-08-09 11:46:53 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:46:53 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:46:53 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:46:53 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:46:53 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:46:53 --> Controller Class Initialized
INFO - 2024-08-09 11:46:53 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:46:53 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:46:53 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:46:53 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:46:53 --> Final output sent to browser
DEBUG - 2024-08-09 11:46:53 --> Total execution time: 0.1441
INFO - 2024-08-09 11:46:54 --> Config Class Initialized
INFO - 2024-08-09 11:46:54 --> Hooks Class Initialized
INFO - 2024-08-09 11:46:54 --> Config Class Initialized
INFO - 2024-08-09 11:46:54 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:46:54 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 11:46:54 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:46:54 --> Utf8 Class Initialized
INFO - 2024-08-09 11:46:54 --> Utf8 Class Initialized
INFO - 2024-08-09 11:46:54 --> URI Class Initialized
INFO - 2024-08-09 11:46:54 --> Router Class Initialized
INFO - 2024-08-09 11:46:54 --> Output Class Initialized
INFO - 2024-08-09 11:46:54 --> Security Class Initialized
DEBUG - 2024-08-09 11:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:46:54 --> Input Class Initialized
INFO - 2024-08-09 11:46:54 --> Language Class Initialized
INFO - 2024-08-09 11:46:54 --> Loader Class Initialized
INFO - 2024-08-09 11:46:54 --> Helper loaded: url_helper
INFO - 2024-08-09 11:46:54 --> Helper loaded: form_helper
INFO - 2024-08-09 11:46:54 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:46:54 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:46:54 --> Email Class Initialized
INFO - 2024-08-09 11:46:54 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:46:54 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:46:54 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:46:54 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:46:54 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:46:54 --> Controller Class Initialized
INFO - 2024-08-09 11:46:54 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:46:54 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:46:54 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:46:54 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:46:54 --> Final output sent to browser
DEBUG - 2024-08-09 11:46:54 --> Total execution time: 0.1181
INFO - 2024-08-09 11:46:55 --> Config Class Initialized
INFO - 2024-08-09 11:46:55 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:46:55 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:46:55 --> Utf8 Class Initialized
INFO - 2024-08-09 11:46:55 --> URI Class Initialized
INFO - 2024-08-09 11:46:55 --> Router Class Initialized
INFO - 2024-08-09 11:46:55 --> Output Class Initialized
INFO - 2024-08-09 11:46:55 --> Security Class Initialized
DEBUG - 2024-08-09 11:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:46:55 --> Input Class Initialized
INFO - 2024-08-09 11:46:55 --> Language Class Initialized
INFO - 2024-08-09 11:46:55 --> Loader Class Initialized
INFO - 2024-08-09 11:46:55 --> Helper loaded: url_helper
INFO - 2024-08-09 11:46:55 --> Helper loaded: form_helper
INFO - 2024-08-09 11:46:55 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:46:55 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:46:55 --> Email Class Initialized
INFO - 2024-08-09 11:46:55 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:46:55 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:46:55 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:46:55 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:46:55 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:46:55 --> Controller Class Initialized
INFO - 2024-08-09 11:46:55 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:46:55 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:46:55 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:46:55 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:46:55 --> Final output sent to browser
DEBUG - 2024-08-09 11:46:55 --> Total execution time: 0.1162
INFO - 2024-08-09 11:46:55 --> Config Class Initialized
INFO - 2024-08-09 11:46:55 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:46:55 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:46:55 --> Utf8 Class Initialized
INFO - 2024-08-09 11:46:55 --> Config Class Initialized
INFO - 2024-08-09 11:46:55 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:46:55 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:46:55 --> Utf8 Class Initialized
INFO - 2024-08-09 11:46:55 --> URI Class Initialized
INFO - 2024-08-09 11:46:55 --> Router Class Initialized
INFO - 2024-08-09 11:46:55 --> Output Class Initialized
INFO - 2024-08-09 11:46:55 --> Security Class Initialized
DEBUG - 2024-08-09 11:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:46:55 --> Input Class Initialized
INFO - 2024-08-09 11:46:55 --> Language Class Initialized
INFO - 2024-08-09 11:46:55 --> Loader Class Initialized
INFO - 2024-08-09 11:46:55 --> Helper loaded: url_helper
INFO - 2024-08-09 11:46:55 --> Helper loaded: form_helper
INFO - 2024-08-09 11:46:55 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:46:55 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:46:55 --> Email Class Initialized
INFO - 2024-08-09 11:46:55 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:46:55 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:46:55 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:46:55 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:46:55 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:46:55 --> Controller Class Initialized
INFO - 2024-08-09 11:46:55 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:46:55 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:46:55 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:46:55 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:46:55 --> Final output sent to browser
DEBUG - 2024-08-09 11:46:55 --> Total execution time: 0.1260
INFO - 2024-08-09 11:46:57 --> Config Class Initialized
INFO - 2024-08-09 11:46:57 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:46:57 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:46:57 --> Utf8 Class Initialized
INFO - 2024-08-09 11:46:57 --> URI Class Initialized
INFO - 2024-08-09 11:46:57 --> Router Class Initialized
INFO - 2024-08-09 11:46:57 --> Output Class Initialized
INFO - 2024-08-09 11:46:57 --> Security Class Initialized
DEBUG - 2024-08-09 11:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:46:57 --> Input Class Initialized
INFO - 2024-08-09 11:46:57 --> Language Class Initialized
INFO - 2024-08-09 11:46:57 --> Loader Class Initialized
INFO - 2024-08-09 11:46:57 --> Helper loaded: url_helper
INFO - 2024-08-09 11:46:57 --> Helper loaded: form_helper
INFO - 2024-08-09 11:46:57 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:46:57 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:46:57 --> Email Class Initialized
INFO - 2024-08-09 11:46:57 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:46:57 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:46:57 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:46:57 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:46:57 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:46:57 --> Controller Class Initialized
INFO - 2024-08-09 11:46:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:46:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:46:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:46:57 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:46:57 --> Final output sent to browser
DEBUG - 2024-08-09 11:46:57 --> Total execution time: 0.1042
INFO - 2024-08-09 11:46:58 --> Config Class Initialized
INFO - 2024-08-09 11:46:58 --> Config Class Initialized
INFO - 2024-08-09 11:46:58 --> Hooks Class Initialized
INFO - 2024-08-09 11:46:58 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:46:58 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:46:58 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:46:58 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:46:58 --> URI Class Initialized
INFO - 2024-08-09 11:46:58 --> Utf8 Class Initialized
INFO - 2024-08-09 11:46:58 --> Router Class Initialized
INFO - 2024-08-09 11:46:58 --> Output Class Initialized
INFO - 2024-08-09 11:46:58 --> Security Class Initialized
DEBUG - 2024-08-09 11:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:46:58 --> Input Class Initialized
INFO - 2024-08-09 11:46:58 --> Language Class Initialized
INFO - 2024-08-09 11:46:58 --> Loader Class Initialized
INFO - 2024-08-09 11:46:58 --> Helper loaded: url_helper
INFO - 2024-08-09 11:46:58 --> Helper loaded: form_helper
INFO - 2024-08-09 11:46:58 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:46:58 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:46:58 --> Email Class Initialized
INFO - 2024-08-09 11:46:58 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:46:58 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:46:58 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:46:58 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:46:58 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:46:58 --> Controller Class Initialized
INFO - 2024-08-09 11:46:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:46:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:46:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:46:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:46:58 --> Final output sent to browser
DEBUG - 2024-08-09 11:46:58 --> Total execution time: 0.1266
INFO - 2024-08-09 11:46:59 --> Config Class Initialized
INFO - 2024-08-09 11:46:59 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:46:59 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:46:59 --> Utf8 Class Initialized
INFO - 2024-08-09 11:46:59 --> URI Class Initialized
INFO - 2024-08-09 11:46:59 --> Router Class Initialized
INFO - 2024-08-09 11:46:59 --> Output Class Initialized
INFO - 2024-08-09 11:46:59 --> Security Class Initialized
DEBUG - 2024-08-09 11:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:46:59 --> Input Class Initialized
INFO - 2024-08-09 11:46:59 --> Language Class Initialized
INFO - 2024-08-09 11:46:59 --> Loader Class Initialized
INFO - 2024-08-09 11:46:59 --> Helper loaded: url_helper
INFO - 2024-08-09 11:46:59 --> Helper loaded: form_helper
INFO - 2024-08-09 11:46:59 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:46:59 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:46:59 --> Email Class Initialized
INFO - 2024-08-09 11:46:59 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:46:59 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:46:59 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:46:59 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:46:59 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:46:59 --> Controller Class Initialized
INFO - 2024-08-09 11:46:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:46:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:46:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:46:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:46:59 --> Final output sent to browser
DEBUG - 2024-08-09 11:46:59 --> Total execution time: 0.1134
INFO - 2024-08-09 11:46:59 --> Config Class Initialized
INFO - 2024-08-09 11:46:59 --> Config Class Initialized
INFO - 2024-08-09 11:46:59 --> Hooks Class Initialized
INFO - 2024-08-09 11:46:59 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:46:59 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:46:59 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:46:59 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:46:59 --> Utf8 Class Initialized
INFO - 2024-08-09 11:46:59 --> URI Class Initialized
INFO - 2024-08-09 11:46:59 --> Router Class Initialized
INFO - 2024-08-09 11:46:59 --> Output Class Initialized
INFO - 2024-08-09 11:46:59 --> Security Class Initialized
DEBUG - 2024-08-09 11:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:46:59 --> Input Class Initialized
INFO - 2024-08-09 11:46:59 --> Language Class Initialized
INFO - 2024-08-09 11:46:59 --> Loader Class Initialized
INFO - 2024-08-09 11:46:59 --> Helper loaded: url_helper
INFO - 2024-08-09 11:46:59 --> Helper loaded: form_helper
INFO - 2024-08-09 11:46:59 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:46:59 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:46:59 --> Email Class Initialized
INFO - 2024-08-09 11:46:59 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:46:59 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:46:59 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:46:59 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:46:59 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:46:59 --> Controller Class Initialized
INFO - 2024-08-09 11:46:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:46:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:46:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:46:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:46:59 --> Final output sent to browser
DEBUG - 2024-08-09 11:46:59 --> Total execution time: 0.1369
INFO - 2024-08-09 11:47:00 --> Config Class Initialized
INFO - 2024-08-09 11:47:00 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:47:00 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:47:00 --> Utf8 Class Initialized
INFO - 2024-08-09 11:47:00 --> URI Class Initialized
INFO - 2024-08-09 11:47:00 --> Router Class Initialized
INFO - 2024-08-09 11:47:00 --> Output Class Initialized
INFO - 2024-08-09 11:47:00 --> Security Class Initialized
DEBUG - 2024-08-09 11:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:47:00 --> Input Class Initialized
INFO - 2024-08-09 11:47:00 --> Language Class Initialized
INFO - 2024-08-09 11:47:00 --> Loader Class Initialized
INFO - 2024-08-09 11:47:00 --> Helper loaded: url_helper
INFO - 2024-08-09 11:47:00 --> Helper loaded: form_helper
INFO - 2024-08-09 11:47:00 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:47:00 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:47:00 --> Email Class Initialized
INFO - 2024-08-09 11:47:00 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:47:00 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:47:00 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:47:00 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:47:00 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:47:00 --> Controller Class Initialized
INFO - 2024-08-09 11:47:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:47:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:47:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:47:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:47:00 --> Final output sent to browser
DEBUG - 2024-08-09 11:47:00 --> Total execution time: 0.1161
INFO - 2024-08-09 11:47:01 --> Config Class Initialized
INFO - 2024-08-09 11:47:01 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:47:01 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:47:01 --> Utf8 Class Initialized
INFO - 2024-08-09 11:47:01 --> URI Class Initialized
INFO - 2024-08-09 11:47:01 --> Router Class Initialized
INFO - 2024-08-09 11:47:01 --> Output Class Initialized
INFO - 2024-08-09 11:47:01 --> Security Class Initialized
DEBUG - 2024-08-09 11:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:47:01 --> Input Class Initialized
INFO - 2024-08-09 11:47:01 --> Language Class Initialized
INFO - 2024-08-09 11:47:01 --> Loader Class Initialized
INFO - 2024-08-09 11:47:01 --> Helper loaded: url_helper
INFO - 2024-08-09 11:47:01 --> Helper loaded: form_helper
INFO - 2024-08-09 11:47:01 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:47:01 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:47:01 --> Email Class Initialized
INFO - 2024-08-09 11:47:01 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:47:01 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:47:01 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:47:01 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:47:01 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:47:01 --> Controller Class Initialized
INFO - 2024-08-09 11:47:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:47:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:47:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:47:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:47:01 --> Final output sent to browser
DEBUG - 2024-08-09 11:47:01 --> Total execution time: 0.2605
INFO - 2024-08-09 11:47:02 --> Config Class Initialized
INFO - 2024-08-09 11:47:02 --> Hooks Class Initialized
INFO - 2024-08-09 11:47:02 --> Config Class Initialized
INFO - 2024-08-09 11:47:02 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:47:02 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:47:02 --> Utf8 Class Initialized
INFO - 2024-08-09 11:47:02 --> URI Class Initialized
DEBUG - 2024-08-09 11:47:02 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:47:02 --> Utf8 Class Initialized
INFO - 2024-08-09 11:47:02 --> Router Class Initialized
INFO - 2024-08-09 11:47:02 --> Output Class Initialized
INFO - 2024-08-09 11:47:02 --> Security Class Initialized
DEBUG - 2024-08-09 11:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:47:02 --> Input Class Initialized
INFO - 2024-08-09 11:47:02 --> Language Class Initialized
INFO - 2024-08-09 11:47:02 --> Loader Class Initialized
INFO - 2024-08-09 11:47:02 --> Helper loaded: url_helper
INFO - 2024-08-09 11:47:02 --> Helper loaded: form_helper
INFO - 2024-08-09 11:47:02 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:47:02 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:47:02 --> Email Class Initialized
INFO - 2024-08-09 11:47:02 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:47:02 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:47:02 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:47:02 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:47:02 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:47:02 --> Controller Class Initialized
INFO - 2024-08-09 11:47:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:47:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:47:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:47:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:47:02 --> Final output sent to browser
DEBUG - 2024-08-09 11:47:02 --> Total execution time: 0.1290
INFO - 2024-08-09 11:47:05 --> Config Class Initialized
INFO - 2024-08-09 11:47:05 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:47:05 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:47:05 --> Utf8 Class Initialized
INFO - 2024-08-09 11:47:05 --> URI Class Initialized
INFO - 2024-08-09 11:47:05 --> Router Class Initialized
INFO - 2024-08-09 11:47:05 --> Output Class Initialized
INFO - 2024-08-09 11:47:05 --> Security Class Initialized
DEBUG - 2024-08-09 11:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:47:05 --> Input Class Initialized
INFO - 2024-08-09 11:47:05 --> Language Class Initialized
INFO - 2024-08-09 11:47:05 --> Loader Class Initialized
INFO - 2024-08-09 11:47:05 --> Helper loaded: url_helper
INFO - 2024-08-09 11:47:05 --> Helper loaded: form_helper
INFO - 2024-08-09 11:47:05 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:47:05 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:47:05 --> Email Class Initialized
INFO - 2024-08-09 11:47:05 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:47:05 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:47:05 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:47:05 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:47:05 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:47:05 --> Controller Class Initialized
INFO - 2024-08-09 11:47:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:47:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:47:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:47:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:47:05 --> Final output sent to browser
DEBUG - 2024-08-09 11:47:05 --> Total execution time: 0.1105
INFO - 2024-08-09 11:47:06 --> Config Class Initialized
INFO - 2024-08-09 11:47:06 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:47:06 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:47:06 --> Utf8 Class Initialized
INFO - 2024-08-09 11:47:06 --> URI Class Initialized
INFO - 2024-08-09 11:47:06 --> Router Class Initialized
INFO - 2024-08-09 11:47:06 --> Config Class Initialized
INFO - 2024-08-09 11:47:06 --> Hooks Class Initialized
INFO - 2024-08-09 11:47:06 --> Output Class Initialized
INFO - 2024-08-09 11:47:06 --> Security Class Initialized
DEBUG - 2024-08-09 11:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:47:06 --> Input Class Initialized
DEBUG - 2024-08-09 11:47:06 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:47:06 --> Utf8 Class Initialized
INFO - 2024-08-09 11:47:06 --> Language Class Initialized
INFO - 2024-08-09 11:47:06 --> Loader Class Initialized
INFO - 2024-08-09 11:47:06 --> Helper loaded: url_helper
INFO - 2024-08-09 11:47:06 --> Helper loaded: form_helper
INFO - 2024-08-09 11:47:06 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:47:06 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:47:06 --> Email Class Initialized
INFO - 2024-08-09 11:47:06 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:47:06 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:47:06 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:47:06 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:47:06 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:47:06 --> Controller Class Initialized
INFO - 2024-08-09 11:47:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:47:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:47:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:47:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:47:06 --> Final output sent to browser
DEBUG - 2024-08-09 11:47:06 --> Total execution time: 0.1292
INFO - 2024-08-09 11:47:28 --> Config Class Initialized
INFO - 2024-08-09 11:47:28 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:47:28 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:47:28 --> Utf8 Class Initialized
INFO - 2024-08-09 11:47:28 --> URI Class Initialized
INFO - 2024-08-09 11:47:28 --> Router Class Initialized
INFO - 2024-08-09 11:47:28 --> Output Class Initialized
INFO - 2024-08-09 11:47:28 --> Security Class Initialized
DEBUG - 2024-08-09 11:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:47:28 --> Input Class Initialized
INFO - 2024-08-09 11:47:28 --> Language Class Initialized
INFO - 2024-08-09 11:47:28 --> Loader Class Initialized
INFO - 2024-08-09 11:47:28 --> Helper loaded: url_helper
INFO - 2024-08-09 11:47:28 --> Helper loaded: form_helper
INFO - 2024-08-09 11:47:28 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:47:28 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:47:28 --> Email Class Initialized
INFO - 2024-08-09 11:47:28 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:47:28 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:47:28 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:47:28 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:47:28 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:47:28 --> Controller Class Initialized
INFO - 2024-08-09 11:47:28 --> Config Class Initialized
INFO - 2024-08-09 11:47:28 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:47:28 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:47:28 --> Utf8 Class Initialized
INFO - 2024-08-09 11:47:28 --> URI Class Initialized
INFO - 2024-08-09 11:47:28 --> Router Class Initialized
INFO - 2024-08-09 11:47:28 --> Output Class Initialized
INFO - 2024-08-09 11:47:28 --> Security Class Initialized
DEBUG - 2024-08-09 11:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:47:28 --> Input Class Initialized
INFO - 2024-08-09 11:47:28 --> Language Class Initialized
INFO - 2024-08-09 11:47:28 --> Loader Class Initialized
INFO - 2024-08-09 11:47:28 --> Helper loaded: url_helper
INFO - 2024-08-09 11:47:28 --> Helper loaded: form_helper
INFO - 2024-08-09 11:47:28 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:47:28 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:47:28 --> Email Class Initialized
INFO - 2024-08-09 11:47:28 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:47:28 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:47:28 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:47:28 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:47:28 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:47:28 --> Controller Class Initialized
INFO - 2024-08-09 11:47:28 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:47:28 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:47:28 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:47:28 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:47:28 --> Final output sent to browser
DEBUG - 2024-08-09 11:47:28 --> Total execution time: 0.0868
INFO - 2024-08-09 11:47:28 --> Config Class Initialized
INFO - 2024-08-09 11:47:28 --> Hooks Class Initialized
INFO - 2024-08-09 11:47:28 --> Config Class Initialized
INFO - 2024-08-09 11:47:28 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:47:28 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:47:28 --> Utf8 Class Initialized
INFO - 2024-08-09 11:47:28 --> URI Class Initialized
INFO - 2024-08-09 11:47:28 --> Router Class Initialized
DEBUG - 2024-08-09 11:47:28 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:47:28 --> Output Class Initialized
INFO - 2024-08-09 11:47:28 --> Utf8 Class Initialized
INFO - 2024-08-09 11:47:28 --> Security Class Initialized
DEBUG - 2024-08-09 11:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:47:28 --> Input Class Initialized
INFO - 2024-08-09 11:47:28 --> Language Class Initialized
INFO - 2024-08-09 11:47:28 --> Loader Class Initialized
INFO - 2024-08-09 11:47:28 --> Helper loaded: url_helper
INFO - 2024-08-09 11:47:28 --> Helper loaded: form_helper
INFO - 2024-08-09 11:47:28 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:47:28 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:47:28 --> Email Class Initialized
INFO - 2024-08-09 11:47:28 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:47:28 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:47:28 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:47:28 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:47:28 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:47:28 --> Controller Class Initialized
INFO - 2024-08-09 11:47:28 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:47:28 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:47:28 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:47:28 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:47:28 --> Final output sent to browser
DEBUG - 2024-08-09 11:47:28 --> Total execution time: 0.1097
INFO - 2024-08-09 11:53:42 --> Config Class Initialized
INFO - 2024-08-09 11:53:42 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:53:42 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:53:42 --> Utf8 Class Initialized
INFO - 2024-08-09 11:53:42 --> URI Class Initialized
INFO - 2024-08-09 11:53:42 --> Router Class Initialized
INFO - 2024-08-09 11:53:42 --> Output Class Initialized
INFO - 2024-08-09 11:53:42 --> Security Class Initialized
DEBUG - 2024-08-09 11:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:53:42 --> Input Class Initialized
INFO - 2024-08-09 11:53:42 --> Language Class Initialized
INFO - 2024-08-09 11:53:42 --> Loader Class Initialized
INFO - 2024-08-09 11:53:42 --> Helper loaded: url_helper
INFO - 2024-08-09 11:53:42 --> Helper loaded: form_helper
INFO - 2024-08-09 11:53:42 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:53:42 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:53:42 --> Email Class Initialized
INFO - 2024-08-09 11:53:42 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:53:42 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:53:42 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:53:42 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:53:42 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:53:42 --> Controller Class Initialized
INFO - 2024-08-09 11:53:42 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:53:42 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:53:42 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:53:42 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:53:42 --> Final output sent to browser
DEBUG - 2024-08-09 11:53:42 --> Total execution time: 0.1453
INFO - 2024-08-09 11:53:42 --> Config Class Initialized
INFO - 2024-08-09 11:53:42 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:53:42 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:53:42 --> Utf8 Class Initialized
INFO - 2024-08-09 11:53:42 --> URI Class Initialized
INFO - 2024-08-09 11:53:42 --> Router Class Initialized
INFO - 2024-08-09 11:53:42 --> Output Class Initialized
INFO - 2024-08-09 11:53:42 --> Security Class Initialized
INFO - 2024-08-09 11:53:42 --> Config Class Initialized
DEBUG - 2024-08-09 11:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:53:42 --> Hooks Class Initialized
INFO - 2024-08-09 11:53:42 --> Input Class Initialized
INFO - 2024-08-09 11:53:42 --> Language Class Initialized
DEBUG - 2024-08-09 11:53:42 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:53:42 --> Utf8 Class Initialized
INFO - 2024-08-09 11:53:42 --> Loader Class Initialized
INFO - 2024-08-09 11:53:42 --> Helper loaded: url_helper
INFO - 2024-08-09 11:53:42 --> Helper loaded: form_helper
INFO - 2024-08-09 11:53:42 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:53:42 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:53:42 --> Email Class Initialized
INFO - 2024-08-09 11:53:42 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:53:42 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:53:42 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:53:42 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:53:42 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:53:42 --> Controller Class Initialized
INFO - 2024-08-09 11:53:42 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:53:42 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:53:42 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:53:42 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:53:42 --> Final output sent to browser
DEBUG - 2024-08-09 11:53:42 --> Total execution time: 0.1365
INFO - 2024-08-09 11:53:45 --> Config Class Initialized
INFO - 2024-08-09 11:53:45 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:53:45 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:53:45 --> Utf8 Class Initialized
INFO - 2024-08-09 11:53:45 --> URI Class Initialized
INFO - 2024-08-09 11:53:45 --> Router Class Initialized
INFO - 2024-08-09 11:53:45 --> Output Class Initialized
INFO - 2024-08-09 11:53:45 --> Security Class Initialized
DEBUG - 2024-08-09 11:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:53:45 --> Input Class Initialized
INFO - 2024-08-09 11:53:45 --> Language Class Initialized
INFO - 2024-08-09 11:53:45 --> Loader Class Initialized
INFO - 2024-08-09 11:53:45 --> Helper loaded: url_helper
INFO - 2024-08-09 11:53:45 --> Helper loaded: form_helper
INFO - 2024-08-09 11:53:45 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:53:45 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:53:45 --> Email Class Initialized
INFO - 2024-08-09 11:53:45 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:53:45 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:53:45 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:53:45 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:53:45 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:53:45 --> Controller Class Initialized
INFO - 2024-08-09 11:53:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:53:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:53:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:53:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:53:45 --> Final output sent to browser
DEBUG - 2024-08-09 11:53:45 --> Total execution time: 0.0999
INFO - 2024-08-09 11:53:45 --> Config Class Initialized
INFO - 2024-08-09 11:53:45 --> Hooks Class Initialized
INFO - 2024-08-09 11:53:45 --> Config Class Initialized
INFO - 2024-08-09 11:53:45 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:53:45 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:53:45 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:53:45 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:53:45 --> Utf8 Class Initialized
INFO - 2024-08-09 11:53:45 --> URI Class Initialized
INFO - 2024-08-09 11:53:45 --> Router Class Initialized
INFO - 2024-08-09 11:53:45 --> Output Class Initialized
INFO - 2024-08-09 11:53:45 --> Security Class Initialized
DEBUG - 2024-08-09 11:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:53:45 --> Input Class Initialized
INFO - 2024-08-09 11:53:45 --> Language Class Initialized
INFO - 2024-08-09 11:53:45 --> Loader Class Initialized
INFO - 2024-08-09 11:53:45 --> Helper loaded: url_helper
INFO - 2024-08-09 11:53:45 --> Helper loaded: form_helper
INFO - 2024-08-09 11:53:45 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:53:45 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:53:45 --> Email Class Initialized
INFO - 2024-08-09 11:53:45 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:53:45 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:53:45 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:53:45 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:53:45 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:53:45 --> Controller Class Initialized
INFO - 2024-08-09 11:53:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:53:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:53:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:53:45 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:53:45 --> Final output sent to browser
DEBUG - 2024-08-09 11:53:45 --> Total execution time: 0.1466
INFO - 2024-08-09 11:53:48 --> Config Class Initialized
INFO - 2024-08-09 11:53:48 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:53:48 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:53:48 --> Utf8 Class Initialized
INFO - 2024-08-09 11:53:48 --> URI Class Initialized
INFO - 2024-08-09 11:53:48 --> Router Class Initialized
INFO - 2024-08-09 11:53:48 --> Output Class Initialized
INFO - 2024-08-09 11:53:48 --> Security Class Initialized
DEBUG - 2024-08-09 11:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:53:48 --> Input Class Initialized
INFO - 2024-08-09 11:53:48 --> Language Class Initialized
INFO - 2024-08-09 11:53:48 --> Loader Class Initialized
INFO - 2024-08-09 11:53:48 --> Helper loaded: url_helper
INFO - 2024-08-09 11:53:48 --> Helper loaded: form_helper
INFO - 2024-08-09 11:53:48 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:53:48 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:53:48 --> Email Class Initialized
INFO - 2024-08-09 11:53:48 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:53:48 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:53:48 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:53:48 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:53:48 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:53:48 --> Controller Class Initialized
INFO - 2024-08-09 11:53:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:53:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:53:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:53:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:53:48 --> Final output sent to browser
DEBUG - 2024-08-09 11:53:48 --> Total execution time: 0.0970
INFO - 2024-08-09 11:53:48 --> Config Class Initialized
INFO - 2024-08-09 11:53:48 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:53:48 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:53:48 --> Config Class Initialized
INFO - 2024-08-09 11:53:48 --> Utf8 Class Initialized
INFO - 2024-08-09 11:53:48 --> Hooks Class Initialized
INFO - 2024-08-09 11:53:48 --> URI Class Initialized
INFO - 2024-08-09 11:53:48 --> Router Class Initialized
INFO - 2024-08-09 11:53:48 --> Output Class Initialized
DEBUG - 2024-08-09 11:53:48 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:53:48 --> Utf8 Class Initialized
INFO - 2024-08-09 11:53:48 --> Security Class Initialized
DEBUG - 2024-08-09 11:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:53:48 --> Input Class Initialized
INFO - 2024-08-09 11:53:48 --> Language Class Initialized
INFO - 2024-08-09 11:53:48 --> Loader Class Initialized
INFO - 2024-08-09 11:53:48 --> Helper loaded: url_helper
INFO - 2024-08-09 11:53:48 --> Helper loaded: form_helper
INFO - 2024-08-09 11:53:48 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:53:48 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:53:48 --> Email Class Initialized
INFO - 2024-08-09 11:53:48 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:53:48 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:53:48 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:53:48 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:53:48 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:53:48 --> Controller Class Initialized
INFO - 2024-08-09 11:53:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:53:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:53:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:53:48 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:53:48 --> Final output sent to browser
DEBUG - 2024-08-09 11:53:48 --> Total execution time: 0.1210
INFO - 2024-08-09 11:54:05 --> Config Class Initialized
INFO - 2024-08-09 11:54:05 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:54:05 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:54:05 --> Utf8 Class Initialized
INFO - 2024-08-09 11:54:05 --> URI Class Initialized
INFO - 2024-08-09 11:54:05 --> Router Class Initialized
INFO - 2024-08-09 11:54:05 --> Output Class Initialized
INFO - 2024-08-09 11:54:05 --> Security Class Initialized
DEBUG - 2024-08-09 11:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:54:05 --> Input Class Initialized
INFO - 2024-08-09 11:54:05 --> Language Class Initialized
INFO - 2024-08-09 11:54:05 --> Loader Class Initialized
INFO - 2024-08-09 11:54:05 --> Helper loaded: url_helper
INFO - 2024-08-09 11:54:05 --> Helper loaded: form_helper
INFO - 2024-08-09 11:54:05 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:54:05 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:54:05 --> Email Class Initialized
INFO - 2024-08-09 11:54:05 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:54:05 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:54:05 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:54:05 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:54:05 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:54:05 --> Controller Class Initialized
INFO - 2024-08-09 11:54:05 --> Config Class Initialized
INFO - 2024-08-09 11:54:05 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:54:05 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:54:05 --> Utf8 Class Initialized
INFO - 2024-08-09 11:54:05 --> URI Class Initialized
INFO - 2024-08-09 11:54:05 --> Router Class Initialized
INFO - 2024-08-09 11:54:05 --> Output Class Initialized
INFO - 2024-08-09 11:54:05 --> Security Class Initialized
DEBUG - 2024-08-09 11:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:54:05 --> Input Class Initialized
INFO - 2024-08-09 11:54:05 --> Language Class Initialized
INFO - 2024-08-09 11:54:05 --> Loader Class Initialized
INFO - 2024-08-09 11:54:05 --> Helper loaded: url_helper
INFO - 2024-08-09 11:54:05 --> Helper loaded: form_helper
INFO - 2024-08-09 11:54:05 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:54:05 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:54:05 --> Email Class Initialized
INFO - 2024-08-09 11:54:05 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:54:05 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:54:05 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:54:05 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:54:05 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:54:05 --> Controller Class Initialized
INFO - 2024-08-09 11:54:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:54:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:54:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:54:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:54:05 --> Final output sent to browser
DEBUG - 2024-08-09 11:54:05 --> Total execution time: 0.0870
INFO - 2024-08-09 11:54:05 --> Config Class Initialized
INFO - 2024-08-09 11:54:05 --> Hooks Class Initialized
INFO - 2024-08-09 11:54:05 --> Config Class Initialized
INFO - 2024-08-09 11:54:05 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:54:05 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 11:54:05 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:54:05 --> Utf8 Class Initialized
INFO - 2024-08-09 11:54:05 --> Utf8 Class Initialized
INFO - 2024-08-09 11:54:05 --> URI Class Initialized
INFO - 2024-08-09 11:54:05 --> Router Class Initialized
INFO - 2024-08-09 11:54:05 --> Output Class Initialized
INFO - 2024-08-09 11:54:05 --> Security Class Initialized
DEBUG - 2024-08-09 11:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:54:05 --> Input Class Initialized
INFO - 2024-08-09 11:54:05 --> Language Class Initialized
INFO - 2024-08-09 11:54:05 --> Loader Class Initialized
INFO - 2024-08-09 11:54:05 --> Helper loaded: url_helper
INFO - 2024-08-09 11:54:05 --> Helper loaded: form_helper
INFO - 2024-08-09 11:54:05 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:54:05 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:54:05 --> Email Class Initialized
INFO - 2024-08-09 11:54:05 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:54:05 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:54:05 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:54:05 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:54:05 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:54:05 --> Controller Class Initialized
INFO - 2024-08-09 11:54:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:54:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:54:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:54:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:54:05 --> Final output sent to browser
DEBUG - 2024-08-09 11:54:05 --> Total execution time: 0.1328
INFO - 2024-08-09 11:54:11 --> Config Class Initialized
INFO - 2024-08-09 11:54:11 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:54:11 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:54:11 --> Utf8 Class Initialized
INFO - 2024-08-09 11:54:11 --> URI Class Initialized
INFO - 2024-08-09 11:54:11 --> Router Class Initialized
INFO - 2024-08-09 11:54:11 --> Output Class Initialized
INFO - 2024-08-09 11:54:11 --> Security Class Initialized
DEBUG - 2024-08-09 11:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:54:11 --> Input Class Initialized
INFO - 2024-08-09 11:54:11 --> Language Class Initialized
INFO - 2024-08-09 11:54:11 --> Loader Class Initialized
INFO - 2024-08-09 11:54:11 --> Helper loaded: url_helper
INFO - 2024-08-09 11:54:11 --> Helper loaded: form_helper
INFO - 2024-08-09 11:54:11 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:54:11 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:54:11 --> Email Class Initialized
INFO - 2024-08-09 11:54:11 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:54:11 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:54:11 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:54:11 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:54:11 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:54:11 --> Controller Class Initialized
INFO - 2024-08-09 11:54:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:54:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:54:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:54:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:54:11 --> Final output sent to browser
DEBUG - 2024-08-09 11:54:11 --> Total execution time: 0.1006
INFO - 2024-08-09 11:54:11 --> Config Class Initialized
INFO - 2024-08-09 11:54:11 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:54:11 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:54:11 --> Utf8 Class Initialized
INFO - 2024-08-09 11:54:11 --> URI Class Initialized
INFO - 2024-08-09 11:54:11 --> Router Class Initialized
INFO - 2024-08-09 11:54:11 --> Config Class Initialized
INFO - 2024-08-09 11:54:11 --> Output Class Initialized
INFO - 2024-08-09 11:54:11 --> Hooks Class Initialized
INFO - 2024-08-09 11:54:11 --> Security Class Initialized
DEBUG - 2024-08-09 11:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:54:11 --> Input Class Initialized
INFO - 2024-08-09 11:54:11 --> Language Class Initialized
DEBUG - 2024-08-09 11:54:11 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:54:11 --> Utf8 Class Initialized
INFO - 2024-08-09 11:54:11 --> Loader Class Initialized
INFO - 2024-08-09 11:54:11 --> Helper loaded: url_helper
INFO - 2024-08-09 11:54:11 --> Helper loaded: form_helper
INFO - 2024-08-09 11:54:11 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:54:11 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:54:11 --> Email Class Initialized
INFO - 2024-08-09 11:54:11 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:54:11 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:54:11 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:54:11 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:54:11 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:54:11 --> Controller Class Initialized
INFO - 2024-08-09 11:54:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:54:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:54:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:54:11 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:54:11 --> Final output sent to browser
DEBUG - 2024-08-09 11:54:11 --> Total execution time: 0.1241
INFO - 2024-08-09 11:54:16 --> Config Class Initialized
INFO - 2024-08-09 11:54:16 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:54:16 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:54:16 --> Utf8 Class Initialized
INFO - 2024-08-09 11:54:16 --> URI Class Initialized
INFO - 2024-08-09 11:54:16 --> Router Class Initialized
INFO - 2024-08-09 11:54:16 --> Output Class Initialized
INFO - 2024-08-09 11:54:16 --> Security Class Initialized
DEBUG - 2024-08-09 11:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:54:16 --> Input Class Initialized
INFO - 2024-08-09 11:54:16 --> Language Class Initialized
INFO - 2024-08-09 11:54:16 --> Loader Class Initialized
INFO - 2024-08-09 11:54:16 --> Helper loaded: url_helper
INFO - 2024-08-09 11:54:16 --> Helper loaded: form_helper
INFO - 2024-08-09 11:54:16 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:54:16 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:54:16 --> Email Class Initialized
INFO - 2024-08-09 11:54:16 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:54:16 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:54:16 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:54:16 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:54:16 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:54:16 --> Controller Class Initialized
INFO - 2024-08-09 11:54:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:54:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "idUsuario" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 38
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "nickName" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 43
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 49
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "primerApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 55
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "segundoApellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 61
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 67
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 74
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 75
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 76
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 83
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 90
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "sexo" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php 94
INFO - 2024-08-09 11:54:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:54:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:54:16 --> Final output sent to browser
DEBUG - 2024-08-09 11:54:16 --> Total execution time: 0.1351
INFO - 2024-08-09 11:54:16 --> Config Class Initialized
INFO - 2024-08-09 11:54:16 --> Hooks Class Initialized
INFO - 2024-08-09 11:54:16 --> Config Class Initialized
INFO - 2024-08-09 11:54:16 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:54:16 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:54:16 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:54:16 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:54:16 --> Utf8 Class Initialized
INFO - 2024-08-09 11:54:16 --> URI Class Initialized
INFO - 2024-08-09 11:54:16 --> Router Class Initialized
INFO - 2024-08-09 11:54:16 --> Output Class Initialized
INFO - 2024-08-09 11:54:16 --> Security Class Initialized
DEBUG - 2024-08-09 11:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:54:16 --> Input Class Initialized
INFO - 2024-08-09 11:54:16 --> Language Class Initialized
INFO - 2024-08-09 11:54:16 --> Loader Class Initialized
INFO - 2024-08-09 11:54:16 --> Helper loaded: url_helper
INFO - 2024-08-09 11:54:16 --> Helper loaded: form_helper
INFO - 2024-08-09 11:54:16 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:54:16 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:54:16 --> Email Class Initialized
INFO - 2024-08-09 11:54:16 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:54:16 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:54:16 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:54:16 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:54:16 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:54:16 --> Controller Class Initialized
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 95
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 97
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 98
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 139
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 140
ERROR - 2024-08-09 11:54:16 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 140
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "primerapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 11:54:16 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "segundoapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 142
ERROR - 2024-08-09 11:54:16 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 142
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 143
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 144
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 145
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Undefined array key "genero" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 146
ERROR - 2024-08-09 11:54:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\core\Exceptions.php:272) C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\helpers\url_helper.php 562
INFO - 2024-08-09 11:59:17 --> Config Class Initialized
INFO - 2024-08-09 11:59:17 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:59:18 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:59:18 --> Utf8 Class Initialized
INFO - 2024-08-09 11:59:18 --> URI Class Initialized
INFO - 2024-08-09 11:59:18 --> Router Class Initialized
INFO - 2024-08-09 11:59:18 --> Output Class Initialized
INFO - 2024-08-09 11:59:18 --> Security Class Initialized
DEBUG - 2024-08-09 11:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:59:18 --> Input Class Initialized
INFO - 2024-08-09 11:59:18 --> Language Class Initialized
INFO - 2024-08-09 11:59:18 --> Loader Class Initialized
INFO - 2024-08-09 11:59:18 --> Helper loaded: url_helper
INFO - 2024-08-09 11:59:18 --> Helper loaded: form_helper
INFO - 2024-08-09 11:59:18 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:59:18 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:59:18 --> Email Class Initialized
INFO - 2024-08-09 11:59:18 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:59:18 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:59:18 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:59:18 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:59:18 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:59:18 --> Controller Class Initialized
INFO - 2024-08-09 11:59:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:59:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:59:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:59:18 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:59:18 --> Final output sent to browser
DEBUG - 2024-08-09 11:59:18 --> Total execution time: 0.1853
INFO - 2024-08-09 11:59:18 --> Config Class Initialized
INFO - 2024-08-09 11:59:18 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:59:18 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:59:18 --> Utf8 Class Initialized
INFO - 2024-08-09 11:59:18 --> URI Class Initialized
INFO - 2024-08-09 11:59:18 --> Router Class Initialized
INFO - 2024-08-09 11:59:18 --> Output Class Initialized
INFO - 2024-08-09 11:59:18 --> Config Class Initialized
INFO - 2024-08-09 11:59:18 --> Hooks Class Initialized
INFO - 2024-08-09 11:59:18 --> Security Class Initialized
DEBUG - 2024-08-09 11:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:59:18 --> Input Class Initialized
DEBUG - 2024-08-09 11:59:18 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:59:18 --> Utf8 Class Initialized
INFO - 2024-08-09 11:59:18 --> Language Class Initialized
INFO - 2024-08-09 11:59:18 --> Loader Class Initialized
INFO - 2024-08-09 11:59:18 --> Helper loaded: url_helper
INFO - 2024-08-09 11:59:18 --> Helper loaded: form_helper
INFO - 2024-08-09 11:59:18 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:59:18 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:59:18 --> Email Class Initialized
INFO - 2024-08-09 11:59:18 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:59:18 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:59:18 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:59:18 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:59:18 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:59:18 --> Controller Class Initialized
ERROR - 2024-08-09 11:59:18 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 94
ERROR - 2024-08-09 11:59:18 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 96
ERROR - 2024-08-09 11:59:18 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 97
ERROR - 2024-08-09 11:59:18 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 138
ERROR - 2024-08-09 11:59:18 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 139
ERROR - 2024-08-09 11:59:18 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 139
ERROR - 2024-08-09 11:59:18 --> Severity: Warning --> Undefined array key "primerapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 140
ERROR - 2024-08-09 11:59:18 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 140
ERROR - 2024-08-09 11:59:18 --> Severity: Warning --> Undefined array key "segundoapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 11:59:18 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 11:59:18 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 142
ERROR - 2024-08-09 11:59:18 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 143
ERROR - 2024-08-09 11:59:18 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 144
ERROR - 2024-08-09 11:59:18 --> Severity: Warning --> Undefined array key "genero" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 145
ERROR - 2024-08-09 11:59:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\core\Exceptions.php:272) C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\helpers\url_helper.php 562
INFO - 2024-08-09 11:59:30 --> Config Class Initialized
INFO - 2024-08-09 11:59:30 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:59:30 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:59:30 --> Utf8 Class Initialized
INFO - 2024-08-09 11:59:30 --> URI Class Initialized
INFO - 2024-08-09 11:59:30 --> Router Class Initialized
INFO - 2024-08-09 11:59:30 --> Output Class Initialized
INFO - 2024-08-09 11:59:30 --> Security Class Initialized
DEBUG - 2024-08-09 11:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:59:30 --> Input Class Initialized
INFO - 2024-08-09 11:59:30 --> Language Class Initialized
INFO - 2024-08-09 11:59:30 --> Loader Class Initialized
INFO - 2024-08-09 11:59:30 --> Helper loaded: url_helper
INFO - 2024-08-09 11:59:30 --> Helper loaded: form_helper
INFO - 2024-08-09 11:59:30 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:59:31 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:59:31 --> Email Class Initialized
INFO - 2024-08-09 11:59:31 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:59:31 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:59:31 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:59:31 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:59:31 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:59:31 --> Controller Class Initialized
INFO - 2024-08-09 11:59:31 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:59:31 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:59:31 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:59:31 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:59:31 --> Final output sent to browser
DEBUG - 2024-08-09 11:59:31 --> Total execution time: 0.0989
INFO - 2024-08-09 11:59:31 --> Config Class Initialized
INFO - 2024-08-09 11:59:31 --> Hooks Class Initialized
INFO - 2024-08-09 11:59:31 --> Config Class Initialized
INFO - 2024-08-09 11:59:31 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:59:31 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:59:31 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:59:31 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:59:31 --> Utf8 Class Initialized
INFO - 2024-08-09 11:59:31 --> URI Class Initialized
INFO - 2024-08-09 11:59:31 --> Router Class Initialized
INFO - 2024-08-09 11:59:31 --> Output Class Initialized
INFO - 2024-08-09 11:59:31 --> Security Class Initialized
DEBUG - 2024-08-09 11:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:59:31 --> Input Class Initialized
INFO - 2024-08-09 11:59:31 --> Language Class Initialized
INFO - 2024-08-09 11:59:31 --> Loader Class Initialized
INFO - 2024-08-09 11:59:31 --> Helper loaded: url_helper
INFO - 2024-08-09 11:59:31 --> Helper loaded: form_helper
INFO - 2024-08-09 11:59:31 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:59:31 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:59:31 --> Email Class Initialized
INFO - 2024-08-09 11:59:31 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:59:31 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:59:31 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:59:31 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:59:31 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:59:31 --> Controller Class Initialized
INFO - 2024-08-09 11:59:31 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:59:31 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:59:31 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:59:31 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:59:31 --> Final output sent to browser
DEBUG - 2024-08-09 11:59:31 --> Total execution time: 0.1254
INFO - 2024-08-09 11:59:35 --> Config Class Initialized
INFO - 2024-08-09 11:59:35 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:59:35 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:59:35 --> Utf8 Class Initialized
INFO - 2024-08-09 11:59:35 --> URI Class Initialized
INFO - 2024-08-09 11:59:35 --> Router Class Initialized
INFO - 2024-08-09 11:59:35 --> Output Class Initialized
INFO - 2024-08-09 11:59:35 --> Security Class Initialized
DEBUG - 2024-08-09 11:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:59:35 --> Input Class Initialized
INFO - 2024-08-09 11:59:35 --> Language Class Initialized
INFO - 2024-08-09 11:59:35 --> Loader Class Initialized
INFO - 2024-08-09 11:59:35 --> Helper loaded: url_helper
INFO - 2024-08-09 11:59:35 --> Helper loaded: form_helper
INFO - 2024-08-09 11:59:35 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:59:35 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:59:35 --> Email Class Initialized
INFO - 2024-08-09 11:59:35 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:59:35 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:59:35 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:59:35 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:59:35 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:59:35 --> Controller Class Initialized
INFO - 2024-08-09 11:59:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:59:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:59:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:59:35 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:59:35 --> Final output sent to browser
DEBUG - 2024-08-09 11:59:35 --> Total execution time: 0.1015
INFO - 2024-08-09 11:59:35 --> Config Class Initialized
INFO - 2024-08-09 11:59:35 --> Hooks Class Initialized
INFO - 2024-08-09 11:59:35 --> Config Class Initialized
INFO - 2024-08-09 11:59:35 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:59:35 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:59:35 --> Utf8 Class Initialized
INFO - 2024-08-09 11:59:35 --> URI Class Initialized
INFO - 2024-08-09 11:59:35 --> Router Class Initialized
INFO - 2024-08-09 11:59:35 --> Output Class Initialized
DEBUG - 2024-08-09 11:59:35 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:59:35 --> Utf8 Class Initialized
INFO - 2024-08-09 11:59:35 --> Security Class Initialized
DEBUG - 2024-08-09 11:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:59:35 --> Input Class Initialized
INFO - 2024-08-09 11:59:35 --> Language Class Initialized
INFO - 2024-08-09 11:59:35 --> Loader Class Initialized
INFO - 2024-08-09 11:59:35 --> Helper loaded: url_helper
INFO - 2024-08-09 11:59:35 --> Helper loaded: form_helper
INFO - 2024-08-09 11:59:35 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:59:35 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:59:35 --> Email Class Initialized
INFO - 2024-08-09 11:59:35 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:59:35 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:59:35 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:59:35 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:59:35 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:59:35 --> Controller Class Initialized
INFO - 2024-08-09 11:59:36 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:59:36 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:59:36 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:59:36 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:59:36 --> Final output sent to browser
DEBUG - 2024-08-09 11:59:36 --> Total execution time: 0.1144
INFO - 2024-08-09 11:59:39 --> Config Class Initialized
INFO - 2024-08-09 11:59:39 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:59:39 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:59:39 --> Utf8 Class Initialized
INFO - 2024-08-09 11:59:39 --> URI Class Initialized
INFO - 2024-08-09 11:59:39 --> Router Class Initialized
INFO - 2024-08-09 11:59:39 --> Output Class Initialized
INFO - 2024-08-09 11:59:39 --> Security Class Initialized
DEBUG - 2024-08-09 11:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:59:39 --> Input Class Initialized
INFO - 2024-08-09 11:59:39 --> Language Class Initialized
INFO - 2024-08-09 11:59:39 --> Loader Class Initialized
INFO - 2024-08-09 11:59:39 --> Helper loaded: url_helper
INFO - 2024-08-09 11:59:39 --> Helper loaded: form_helper
INFO - 2024-08-09 11:59:39 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:59:39 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:59:39 --> Email Class Initialized
INFO - 2024-08-09 11:59:39 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:59:39 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:59:39 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:59:39 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:59:39 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:59:39 --> Controller Class Initialized
INFO - 2024-08-09 11:59:39 --> Config Class Initialized
INFO - 2024-08-09 11:59:39 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:59:39 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:59:39 --> Utf8 Class Initialized
INFO - 2024-08-09 11:59:39 --> URI Class Initialized
INFO - 2024-08-09 11:59:39 --> Router Class Initialized
INFO - 2024-08-09 11:59:39 --> Output Class Initialized
INFO - 2024-08-09 11:59:39 --> Security Class Initialized
DEBUG - 2024-08-09 11:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:59:39 --> Input Class Initialized
INFO - 2024-08-09 11:59:39 --> Language Class Initialized
INFO - 2024-08-09 11:59:39 --> Loader Class Initialized
INFO - 2024-08-09 11:59:39 --> Helper loaded: url_helper
INFO - 2024-08-09 11:59:39 --> Helper loaded: form_helper
INFO - 2024-08-09 11:59:39 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:59:39 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:59:39 --> Email Class Initialized
INFO - 2024-08-09 11:59:39 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:59:39 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:59:39 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:59:39 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:59:39 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:59:39 --> Controller Class Initialized
INFO - 2024-08-09 11:59:39 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:59:39 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:59:39 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:59:39 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:59:39 --> Final output sent to browser
DEBUG - 2024-08-09 11:59:39 --> Total execution time: 0.0964
INFO - 2024-08-09 11:59:39 --> Config Class Initialized
INFO - 2024-08-09 11:59:39 --> Hooks Class Initialized
INFO - 2024-08-09 11:59:39 --> Config Class Initialized
INFO - 2024-08-09 11:59:39 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:59:39 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:59:39 --> Utf8 Class Initialized
INFO - 2024-08-09 11:59:39 --> URI Class Initialized
DEBUG - 2024-08-09 11:59:39 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:59:39 --> Utf8 Class Initialized
INFO - 2024-08-09 11:59:39 --> Router Class Initialized
INFO - 2024-08-09 11:59:39 --> Output Class Initialized
INFO - 2024-08-09 11:59:39 --> Security Class Initialized
DEBUG - 2024-08-09 11:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:59:39 --> Input Class Initialized
INFO - 2024-08-09 11:59:39 --> Language Class Initialized
INFO - 2024-08-09 11:59:39 --> Loader Class Initialized
INFO - 2024-08-09 11:59:40 --> Helper loaded: url_helper
INFO - 2024-08-09 11:59:40 --> Helper loaded: form_helper
INFO - 2024-08-09 11:59:40 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:59:40 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:59:40 --> Email Class Initialized
INFO - 2024-08-09 11:59:40 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:59:40 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:59:40 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:59:40 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:59:40 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:59:40 --> Controller Class Initialized
INFO - 2024-08-09 11:59:40 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:59:40 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:59:40 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 11:59:40 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:59:40 --> Final output sent to browser
DEBUG - 2024-08-09 11:59:40 --> Total execution time: 0.1158
INFO - 2024-08-09 11:59:44 --> Config Class Initialized
INFO - 2024-08-09 11:59:44 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:59:44 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:59:44 --> Utf8 Class Initialized
INFO - 2024-08-09 11:59:44 --> URI Class Initialized
INFO - 2024-08-09 11:59:44 --> Router Class Initialized
INFO - 2024-08-09 11:59:44 --> Output Class Initialized
INFO - 2024-08-09 11:59:44 --> Security Class Initialized
DEBUG - 2024-08-09 11:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:59:44 --> Input Class Initialized
INFO - 2024-08-09 11:59:44 --> Language Class Initialized
INFO - 2024-08-09 11:59:44 --> Loader Class Initialized
INFO - 2024-08-09 11:59:44 --> Helper loaded: url_helper
INFO - 2024-08-09 11:59:44 --> Helper loaded: form_helper
INFO - 2024-08-09 11:59:44 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:59:44 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:59:44 --> Email Class Initialized
INFO - 2024-08-09 11:59:44 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:59:44 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:59:44 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:59:44 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:59:44 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:59:44 --> Controller Class Initialized
INFO - 2024-08-09 11:59:44 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:59:44 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:59:44 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:59:44 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:59:44 --> Final output sent to browser
DEBUG - 2024-08-09 11:59:44 --> Total execution time: 0.0993
INFO - 2024-08-09 11:59:44 --> Config Class Initialized
INFO - 2024-08-09 11:59:44 --> Hooks Class Initialized
INFO - 2024-08-09 11:59:44 --> Config Class Initialized
DEBUG - 2024-08-09 11:59:44 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:59:44 --> Utf8 Class Initialized
INFO - 2024-08-09 11:59:44 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:59:44 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:59:44 --> Utf8 Class Initialized
INFO - 2024-08-09 11:59:44 --> URI Class Initialized
INFO - 2024-08-09 11:59:44 --> Router Class Initialized
INFO - 2024-08-09 11:59:44 --> Output Class Initialized
INFO - 2024-08-09 11:59:44 --> Security Class Initialized
DEBUG - 2024-08-09 11:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:59:44 --> Input Class Initialized
INFO - 2024-08-09 11:59:44 --> Language Class Initialized
INFO - 2024-08-09 11:59:44 --> Loader Class Initialized
INFO - 2024-08-09 11:59:44 --> Helper loaded: url_helper
INFO - 2024-08-09 11:59:44 --> Helper loaded: form_helper
INFO - 2024-08-09 11:59:44 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:59:44 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:59:44 --> Email Class Initialized
INFO - 2024-08-09 11:59:44 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:59:44 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:59:44 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:59:44 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:59:44 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:59:44 --> Controller Class Initialized
INFO - 2024-08-09 11:59:44 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:59:44 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:59:44 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:59:44 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:59:44 --> Final output sent to browser
DEBUG - 2024-08-09 11:59:44 --> Total execution time: 0.1390
INFO - 2024-08-09 11:59:49 --> Config Class Initialized
INFO - 2024-08-09 11:59:49 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:59:49 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:59:49 --> Utf8 Class Initialized
INFO - 2024-08-09 11:59:49 --> URI Class Initialized
INFO - 2024-08-09 11:59:49 --> Router Class Initialized
INFO - 2024-08-09 11:59:49 --> Output Class Initialized
INFO - 2024-08-09 11:59:49 --> Security Class Initialized
DEBUG - 2024-08-09 11:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:59:49 --> Input Class Initialized
INFO - 2024-08-09 11:59:49 --> Language Class Initialized
INFO - 2024-08-09 11:59:49 --> Loader Class Initialized
INFO - 2024-08-09 11:59:49 --> Helper loaded: url_helper
INFO - 2024-08-09 11:59:49 --> Helper loaded: form_helper
INFO - 2024-08-09 11:59:49 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:59:49 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:59:49 --> Email Class Initialized
INFO - 2024-08-09 11:59:49 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:59:49 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:59:49 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:59:49 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:59:49 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:59:49 --> Controller Class Initialized
INFO - 2024-08-09 11:59:49 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 11:59:49 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 11:59:49 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 11:59:49 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 11:59:49 --> Final output sent to browser
DEBUG - 2024-08-09 11:59:49 --> Total execution time: 0.1247
INFO - 2024-08-09 11:59:49 --> Config Class Initialized
INFO - 2024-08-09 11:59:49 --> Hooks Class Initialized
INFO - 2024-08-09 11:59:49 --> Config Class Initialized
INFO - 2024-08-09 11:59:49 --> Hooks Class Initialized
DEBUG - 2024-08-09 11:59:49 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:59:49 --> Utf8 Class Initialized
DEBUG - 2024-08-09 11:59:49 --> UTF-8 Support Enabled
INFO - 2024-08-09 11:59:49 --> Utf8 Class Initialized
INFO - 2024-08-09 11:59:49 --> URI Class Initialized
INFO - 2024-08-09 11:59:49 --> Router Class Initialized
INFO - 2024-08-09 11:59:49 --> Output Class Initialized
INFO - 2024-08-09 11:59:49 --> Security Class Initialized
DEBUG - 2024-08-09 11:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 11:59:49 --> Input Class Initialized
INFO - 2024-08-09 11:59:49 --> Language Class Initialized
INFO - 2024-08-09 11:59:49 --> Loader Class Initialized
INFO - 2024-08-09 11:59:49 --> Helper loaded: url_helper
INFO - 2024-08-09 11:59:49 --> Helper loaded: form_helper
INFO - 2024-08-09 11:59:49 --> Helper loaded: funciones_helper
INFO - 2024-08-09 11:59:50 --> Database Driver Class Initialized
DEBUG - 2024-08-09 11:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 11:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 11:59:50 --> Email Class Initialized
INFO - 2024-08-09 11:59:50 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 11:59:50 --> Model "Pais_model" initialized
INFO - 2024-08-09 11:59:50 --> Model "Libro_model" initialized
INFO - 2024-08-09 11:59:50 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 11:59:50 --> Model "Usuario_model" initialized
INFO - 2024-08-09 11:59:50 --> Controller Class Initialized
ERROR - 2024-08-09 11:59:50 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 94
ERROR - 2024-08-09 11:59:50 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 96
ERROR - 2024-08-09 11:59:50 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 97
ERROR - 2024-08-09 11:59:50 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 138
ERROR - 2024-08-09 11:59:50 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 139
ERROR - 2024-08-09 11:59:50 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 139
ERROR - 2024-08-09 11:59:50 --> Severity: Warning --> Undefined array key "primerapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 140
ERROR - 2024-08-09 11:59:50 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 140
ERROR - 2024-08-09 11:59:50 --> Severity: Warning --> Undefined array key "segundoapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 11:59:50 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 11:59:50 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 142
ERROR - 2024-08-09 11:59:50 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 143
ERROR - 2024-08-09 11:59:50 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 144
ERROR - 2024-08-09 11:59:50 --> Severity: Warning --> Undefined array key "genero" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 145
ERROR - 2024-08-09 11:59:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\core\Exceptions.php:272) C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\helpers\url_helper.php 562
INFO - 2024-08-09 12:02:58 --> Config Class Initialized
INFO - 2024-08-09 12:02:58 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:02:58 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:02:58 --> Utf8 Class Initialized
INFO - 2024-08-09 12:02:58 --> URI Class Initialized
INFO - 2024-08-09 12:02:58 --> Router Class Initialized
INFO - 2024-08-09 12:02:58 --> Output Class Initialized
INFO - 2024-08-09 12:02:58 --> Security Class Initialized
DEBUG - 2024-08-09 12:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:02:58 --> Input Class Initialized
INFO - 2024-08-09 12:02:58 --> Language Class Initialized
INFO - 2024-08-09 12:02:58 --> Loader Class Initialized
INFO - 2024-08-09 12:02:58 --> Helper loaded: url_helper
INFO - 2024-08-09 12:02:58 --> Helper loaded: form_helper
INFO - 2024-08-09 12:02:58 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:02:58 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:02:58 --> Email Class Initialized
INFO - 2024-08-09 12:02:58 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:02:58 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:02:58 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:02:58 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:02:58 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:02:58 --> Controller Class Initialized
INFO - 2024-08-09 12:02:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:02:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:02:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:02:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:02:58 --> Final output sent to browser
DEBUG - 2024-08-09 12:02:58 --> Total execution time: 0.1681
INFO - 2024-08-09 12:02:59 --> Config Class Initialized
INFO - 2024-08-09 12:02:59 --> Hooks Class Initialized
INFO - 2024-08-09 12:02:59 --> Config Class Initialized
INFO - 2024-08-09 12:02:59 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:02:59 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:02:59 --> Utf8 Class Initialized
DEBUG - 2024-08-09 12:02:59 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:02:59 --> Utf8 Class Initialized
INFO - 2024-08-09 12:02:59 --> URI Class Initialized
INFO - 2024-08-09 12:02:59 --> Router Class Initialized
INFO - 2024-08-09 12:02:59 --> Output Class Initialized
INFO - 2024-08-09 12:02:59 --> Security Class Initialized
DEBUG - 2024-08-09 12:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:02:59 --> Input Class Initialized
INFO - 2024-08-09 12:02:59 --> Language Class Initialized
INFO - 2024-08-09 12:02:59 --> Loader Class Initialized
INFO - 2024-08-09 12:02:59 --> Helper loaded: url_helper
INFO - 2024-08-09 12:02:59 --> Helper loaded: form_helper
INFO - 2024-08-09 12:02:59 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:02:59 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:02:59 --> Email Class Initialized
INFO - 2024-08-09 12:02:59 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:02:59 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:02:59 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:02:59 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:02:59 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:02:59 --> Controller Class Initialized
ERROR - 2024-08-09 12:02:59 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 90
ERROR - 2024-08-09 12:02:59 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 92
ERROR - 2024-08-09 12:02:59 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 93
ERROR - 2024-08-09 12:02:59 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 134
ERROR - 2024-08-09 12:02:59 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 135
ERROR - 2024-08-09 12:02:59 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 135
ERROR - 2024-08-09 12:02:59 --> Severity: Warning --> Undefined array key "primerapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 136
ERROR - 2024-08-09 12:02:59 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 136
ERROR - 2024-08-09 12:02:59 --> Severity: Warning --> Undefined array key "segundoapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 137
ERROR - 2024-08-09 12:02:59 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 137
ERROR - 2024-08-09 12:02:59 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 138
ERROR - 2024-08-09 12:02:59 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 139
ERROR - 2024-08-09 12:02:59 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 140
ERROR - 2024-08-09 12:02:59 --> Severity: Warning --> Undefined array key "genero" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 12:02:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\core\Exceptions.php:272) C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\helpers\url_helper.php 562
INFO - 2024-08-09 12:03:02 --> Config Class Initialized
INFO - 2024-08-09 12:03:02 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:03:02 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:03:02 --> Utf8 Class Initialized
INFO - 2024-08-09 12:03:02 --> URI Class Initialized
INFO - 2024-08-09 12:03:02 --> Router Class Initialized
INFO - 2024-08-09 12:03:02 --> Output Class Initialized
INFO - 2024-08-09 12:03:02 --> Security Class Initialized
DEBUG - 2024-08-09 12:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:03:02 --> Input Class Initialized
INFO - 2024-08-09 12:03:02 --> Language Class Initialized
INFO - 2024-08-09 12:03:02 --> Loader Class Initialized
INFO - 2024-08-09 12:03:02 --> Helper loaded: url_helper
INFO - 2024-08-09 12:03:02 --> Helper loaded: form_helper
INFO - 2024-08-09 12:03:02 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:03:02 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:03:02 --> Email Class Initialized
INFO - 2024-08-09 12:03:02 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:03:02 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:03:02 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:03:02 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:03:02 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:03:02 --> Controller Class Initialized
INFO - 2024-08-09 12:03:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:03:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:03:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 12:03:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:03:02 --> Final output sent to browser
DEBUG - 2024-08-09 12:03:02 --> Total execution time: 0.0973
INFO - 2024-08-09 12:03:02 --> Config Class Initialized
INFO - 2024-08-09 12:03:02 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:03:02 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:03:02 --> Utf8 Class Initialized
INFO - 2024-08-09 12:03:02 --> Config Class Initialized
INFO - 2024-08-09 12:03:02 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:03:02 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:03:02 --> Utf8 Class Initialized
INFO - 2024-08-09 12:03:02 --> URI Class Initialized
INFO - 2024-08-09 12:03:02 --> Router Class Initialized
INFO - 2024-08-09 12:03:02 --> Output Class Initialized
INFO - 2024-08-09 12:03:02 --> Security Class Initialized
DEBUG - 2024-08-09 12:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:03:02 --> Input Class Initialized
INFO - 2024-08-09 12:03:02 --> Language Class Initialized
INFO - 2024-08-09 12:03:02 --> Loader Class Initialized
INFO - 2024-08-09 12:03:02 --> Helper loaded: url_helper
INFO - 2024-08-09 12:03:02 --> Helper loaded: form_helper
INFO - 2024-08-09 12:03:02 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:03:02 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:03:02 --> Email Class Initialized
INFO - 2024-08-09 12:03:02 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:03:02 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:03:02 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:03:02 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:03:02 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:03:02 --> Controller Class Initialized
INFO - 2024-08-09 12:03:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:03:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:03:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 12:03:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:03:02 --> Final output sent to browser
DEBUG - 2024-08-09 12:03:02 --> Total execution time: 0.1411
INFO - 2024-08-09 12:03:05 --> Config Class Initialized
INFO - 2024-08-09 12:03:05 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:03:05 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:03:05 --> Utf8 Class Initialized
INFO - 2024-08-09 12:03:05 --> URI Class Initialized
INFO - 2024-08-09 12:03:05 --> Router Class Initialized
INFO - 2024-08-09 12:03:05 --> Output Class Initialized
INFO - 2024-08-09 12:03:05 --> Security Class Initialized
DEBUG - 2024-08-09 12:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:03:05 --> Input Class Initialized
INFO - 2024-08-09 12:03:05 --> Language Class Initialized
INFO - 2024-08-09 12:03:05 --> Loader Class Initialized
INFO - 2024-08-09 12:03:05 --> Helper loaded: url_helper
INFO - 2024-08-09 12:03:05 --> Helper loaded: form_helper
INFO - 2024-08-09 12:03:05 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:03:05 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:03:05 --> Email Class Initialized
INFO - 2024-08-09 12:03:05 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:03:05 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:03:05 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:03:05 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:03:05 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:03:05 --> Controller Class Initialized
INFO - 2024-08-09 12:03:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:03:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:03:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:03:05 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:03:05 --> Final output sent to browser
DEBUG - 2024-08-09 12:03:05 --> Total execution time: 0.0959
INFO - 2024-08-09 12:03:05 --> Config Class Initialized
INFO - 2024-08-09 12:03:05 --> Config Class Initialized
INFO - 2024-08-09 12:03:05 --> Hooks Class Initialized
INFO - 2024-08-09 12:03:05 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:03:06 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 12:03:06 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:03:06 --> Utf8 Class Initialized
INFO - 2024-08-09 12:03:06 --> Utf8 Class Initialized
INFO - 2024-08-09 12:03:06 --> URI Class Initialized
INFO - 2024-08-09 12:03:06 --> Router Class Initialized
INFO - 2024-08-09 12:03:06 --> Output Class Initialized
INFO - 2024-08-09 12:03:06 --> Security Class Initialized
DEBUG - 2024-08-09 12:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:03:06 --> Input Class Initialized
INFO - 2024-08-09 12:03:06 --> Language Class Initialized
INFO - 2024-08-09 12:03:06 --> Loader Class Initialized
INFO - 2024-08-09 12:03:06 --> Helper loaded: url_helper
INFO - 2024-08-09 12:03:06 --> Helper loaded: form_helper
INFO - 2024-08-09 12:03:06 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:03:06 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:03:06 --> Email Class Initialized
INFO - 2024-08-09 12:03:06 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:03:06 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:03:06 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:03:06 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:03:06 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:03:06 --> Controller Class Initialized
INFO - 2024-08-09 12:03:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:03:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:03:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:03:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:03:06 --> Final output sent to browser
DEBUG - 2024-08-09 12:03:06 --> Total execution time: 0.1411
INFO - 2024-08-09 12:03:10 --> Config Class Initialized
INFO - 2024-08-09 12:03:10 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:03:10 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:03:10 --> Utf8 Class Initialized
INFO - 2024-08-09 12:03:10 --> URI Class Initialized
INFO - 2024-08-09 12:03:10 --> Router Class Initialized
INFO - 2024-08-09 12:03:10 --> Output Class Initialized
INFO - 2024-08-09 12:03:10 --> Security Class Initialized
DEBUG - 2024-08-09 12:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:03:10 --> Input Class Initialized
INFO - 2024-08-09 12:03:10 --> Language Class Initialized
INFO - 2024-08-09 12:03:10 --> Loader Class Initialized
INFO - 2024-08-09 12:03:10 --> Helper loaded: url_helper
INFO - 2024-08-09 12:03:10 --> Helper loaded: form_helper
INFO - 2024-08-09 12:03:10 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:03:10 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:03:10 --> Email Class Initialized
INFO - 2024-08-09 12:03:10 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:03:10 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:03:10 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:03:10 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:03:10 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:03:10 --> Controller Class Initialized
INFO - 2024-08-09 12:03:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:03:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:03:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:03:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:03:10 --> Final output sent to browser
DEBUG - 2024-08-09 12:03:10 --> Total execution time: 0.1174
INFO - 2024-08-09 12:03:10 --> Config Class Initialized
INFO - 2024-08-09 12:03:10 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:03:10 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:03:10 --> Utf8 Class Initialized
INFO - 2024-08-09 12:03:10 --> Config Class Initialized
INFO - 2024-08-09 12:03:10 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:03:10 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:03:10 --> Utf8 Class Initialized
INFO - 2024-08-09 12:03:10 --> URI Class Initialized
INFO - 2024-08-09 12:03:10 --> Router Class Initialized
INFO - 2024-08-09 12:03:10 --> Output Class Initialized
INFO - 2024-08-09 12:03:10 --> Security Class Initialized
DEBUG - 2024-08-09 12:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:03:10 --> Input Class Initialized
INFO - 2024-08-09 12:03:10 --> Language Class Initialized
INFO - 2024-08-09 12:03:10 --> Loader Class Initialized
INFO - 2024-08-09 12:03:10 --> Helper loaded: url_helper
INFO - 2024-08-09 12:03:10 --> Helper loaded: form_helper
INFO - 2024-08-09 12:03:10 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:03:10 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:03:10 --> Email Class Initialized
INFO - 2024-08-09 12:03:10 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:03:10 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:03:10 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:03:10 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:03:10 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:03:10 --> Controller Class Initialized
ERROR - 2024-08-09 12:03:10 --> Severity: Warning --> Undefined array key "id" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 90
ERROR - 2024-08-09 12:03:10 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 92
ERROR - 2024-08-09 12:03:10 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 93
ERROR - 2024-08-09 12:03:10 --> Severity: Warning --> Undefined array key "nickname" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 134
ERROR - 2024-08-09 12:03:10 --> Severity: Warning --> Undefined array key "nombre" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 135
ERROR - 2024-08-09 12:03:10 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 135
ERROR - 2024-08-09 12:03:10 --> Severity: Warning --> Undefined array key "primerapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 136
ERROR - 2024-08-09 12:03:10 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 136
ERROR - 2024-08-09 12:03:10 --> Severity: Warning --> Undefined array key "segundoapellido" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 137
ERROR - 2024-08-09 12:03:10 --> Severity: 8192 --> strtoupper(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 137
ERROR - 2024-08-09 12:03:10 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 138
ERROR - 2024-08-09 12:03:10 --> Severity: Warning --> Undefined array key "rol" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 139
ERROR - 2024-08-09 12:03:10 --> Severity: Warning --> Undefined array key "fono" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 140
ERROR - 2024-08-09 12:03:10 --> Severity: Warning --> Undefined array key "genero" C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 141
ERROR - 2024-08-09 12:03:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\core\Exceptions.php:272) C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\system\helpers\url_helper.php 562
INFO - 2024-08-09 12:05:46 --> Config Class Initialized
INFO - 2024-08-09 12:05:46 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:05:46 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:05:46 --> Utf8 Class Initialized
INFO - 2024-08-09 12:05:46 --> URI Class Initialized
INFO - 2024-08-09 12:05:46 --> Router Class Initialized
INFO - 2024-08-09 12:05:46 --> Output Class Initialized
INFO - 2024-08-09 12:05:46 --> Security Class Initialized
DEBUG - 2024-08-09 12:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:05:46 --> Input Class Initialized
INFO - 2024-08-09 12:05:46 --> Language Class Initialized
ERROR - 2024-08-09 12:05:46 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\controllers\crudusers.php 81
INFO - 2024-08-09 12:07:01 --> Config Class Initialized
INFO - 2024-08-09 12:07:01 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:07:01 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:01 --> Utf8 Class Initialized
INFO - 2024-08-09 12:07:01 --> URI Class Initialized
INFO - 2024-08-09 12:07:01 --> Router Class Initialized
INFO - 2024-08-09 12:07:01 --> Output Class Initialized
INFO - 2024-08-09 12:07:01 --> Security Class Initialized
DEBUG - 2024-08-09 12:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:07:01 --> Input Class Initialized
INFO - 2024-08-09 12:07:01 --> Language Class Initialized
INFO - 2024-08-09 12:07:01 --> Loader Class Initialized
INFO - 2024-08-09 12:07:01 --> Helper loaded: url_helper
INFO - 2024-08-09 12:07:01 --> Helper loaded: form_helper
INFO - 2024-08-09 12:07:01 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:07:01 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:07:01 --> Email Class Initialized
INFO - 2024-08-09 12:07:01 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:07:01 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:07:01 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:07:01 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:07:01 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:07:01 --> Controller Class Initialized
INFO - 2024-08-09 12:07:01 --> Config Class Initialized
INFO - 2024-08-09 12:07:01 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:07:01 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:01 --> Utf8 Class Initialized
INFO - 2024-08-09 12:07:01 --> URI Class Initialized
INFO - 2024-08-09 12:07:01 --> Router Class Initialized
INFO - 2024-08-09 12:07:01 --> Output Class Initialized
INFO - 2024-08-09 12:07:01 --> Security Class Initialized
DEBUG - 2024-08-09 12:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:07:01 --> Input Class Initialized
INFO - 2024-08-09 12:07:01 --> Language Class Initialized
INFO - 2024-08-09 12:07:01 --> Loader Class Initialized
INFO - 2024-08-09 12:07:01 --> Helper loaded: url_helper
INFO - 2024-08-09 12:07:01 --> Helper loaded: form_helper
INFO - 2024-08-09 12:07:01 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:07:01 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:07:01 --> Email Class Initialized
INFO - 2024-08-09 12:07:01 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:07:01 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:07:01 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:07:01 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:07:01 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:07:01 --> Controller Class Initialized
INFO - 2024-08-09 12:07:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:07:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:07:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:07:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:07:01 --> Final output sent to browser
DEBUG - 2024-08-09 12:07:01 --> Total execution time: 0.1089
INFO - 2024-08-09 12:07:02 --> Config Class Initialized
INFO - 2024-08-09 12:07:02 --> Config Class Initialized
INFO - 2024-08-09 12:07:02 --> Hooks Class Initialized
INFO - 2024-08-09 12:07:02 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:07:02 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 12:07:02 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:02 --> Utf8 Class Initialized
INFO - 2024-08-09 12:07:02 --> Utf8 Class Initialized
INFO - 2024-08-09 12:07:02 --> URI Class Initialized
INFO - 2024-08-09 12:07:02 --> Router Class Initialized
INFO - 2024-08-09 12:07:02 --> Output Class Initialized
INFO - 2024-08-09 12:07:02 --> Security Class Initialized
DEBUG - 2024-08-09 12:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:07:02 --> Input Class Initialized
INFO - 2024-08-09 12:07:02 --> Language Class Initialized
INFO - 2024-08-09 12:07:02 --> Loader Class Initialized
INFO - 2024-08-09 12:07:02 --> Helper loaded: url_helper
INFO - 2024-08-09 12:07:02 --> Helper loaded: form_helper
INFO - 2024-08-09 12:07:02 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:07:02 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:07:02 --> Email Class Initialized
INFO - 2024-08-09 12:07:02 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:07:02 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:07:02 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:07:02 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:07:02 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:07:02 --> Controller Class Initialized
INFO - 2024-08-09 12:07:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:07:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:07:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:07:02 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:07:02 --> Final output sent to browser
DEBUG - 2024-08-09 12:07:02 --> Total execution time: 0.1170
INFO - 2024-08-09 12:07:09 --> Config Class Initialized
INFO - 2024-08-09 12:07:09 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:07:09 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:09 --> Utf8 Class Initialized
INFO - 2024-08-09 12:07:09 --> URI Class Initialized
INFO - 2024-08-09 12:07:09 --> Router Class Initialized
INFO - 2024-08-09 12:07:09 --> Output Class Initialized
INFO - 2024-08-09 12:07:09 --> Security Class Initialized
DEBUG - 2024-08-09 12:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:07:09 --> Input Class Initialized
INFO - 2024-08-09 12:07:09 --> Language Class Initialized
INFO - 2024-08-09 12:07:09 --> Loader Class Initialized
INFO - 2024-08-09 12:07:09 --> Helper loaded: url_helper
INFO - 2024-08-09 12:07:09 --> Helper loaded: form_helper
INFO - 2024-08-09 12:07:09 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:07:09 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:07:09 --> Email Class Initialized
INFO - 2024-08-09 12:07:09 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:07:09 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:07:09 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:07:09 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:07:09 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:07:09 --> Controller Class Initialized
INFO - 2024-08-09 12:07:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:07:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:07:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 12:07:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:07:09 --> Final output sent to browser
DEBUG - 2024-08-09 12:07:09 --> Total execution time: 0.1210
INFO - 2024-08-09 12:07:10 --> Config Class Initialized
INFO - 2024-08-09 12:07:10 --> Hooks Class Initialized
INFO - 2024-08-09 12:07:10 --> Config Class Initialized
INFO - 2024-08-09 12:07:10 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:07:10 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:10 --> Utf8 Class Initialized
DEBUG - 2024-08-09 12:07:10 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:10 --> URI Class Initialized
INFO - 2024-08-09 12:07:10 --> Utf8 Class Initialized
INFO - 2024-08-09 12:07:10 --> Router Class Initialized
INFO - 2024-08-09 12:07:10 --> Output Class Initialized
INFO - 2024-08-09 12:07:10 --> Security Class Initialized
DEBUG - 2024-08-09 12:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:07:10 --> Input Class Initialized
INFO - 2024-08-09 12:07:10 --> Language Class Initialized
INFO - 2024-08-09 12:07:10 --> Loader Class Initialized
INFO - 2024-08-09 12:07:10 --> Helper loaded: url_helper
INFO - 2024-08-09 12:07:10 --> Helper loaded: form_helper
INFO - 2024-08-09 12:07:10 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:07:10 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:07:10 --> Email Class Initialized
INFO - 2024-08-09 12:07:10 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:07:10 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:07:10 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:07:10 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:07:10 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:07:10 --> Controller Class Initialized
INFO - 2024-08-09 12:07:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:07:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:07:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 12:07:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:07:10 --> Final output sent to browser
DEBUG - 2024-08-09 12:07:10 --> Total execution time: 0.1253
INFO - 2024-08-09 12:07:12 --> Config Class Initialized
INFO - 2024-08-09 12:07:12 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:07:12 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:12 --> Utf8 Class Initialized
INFO - 2024-08-09 12:07:12 --> URI Class Initialized
INFO - 2024-08-09 12:07:12 --> Router Class Initialized
INFO - 2024-08-09 12:07:12 --> Output Class Initialized
INFO - 2024-08-09 12:07:12 --> Security Class Initialized
DEBUG - 2024-08-09 12:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:07:12 --> Input Class Initialized
INFO - 2024-08-09 12:07:12 --> Language Class Initialized
INFO - 2024-08-09 12:07:12 --> Loader Class Initialized
INFO - 2024-08-09 12:07:12 --> Helper loaded: url_helper
INFO - 2024-08-09 12:07:12 --> Helper loaded: form_helper
INFO - 2024-08-09 12:07:12 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:07:12 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:07:12 --> Email Class Initialized
INFO - 2024-08-09 12:07:12 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:07:12 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:07:12 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:07:12 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:07:12 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:07:12 --> Controller Class Initialized
INFO - 2024-08-09 12:07:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:07:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:07:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:07:12 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:07:12 --> Final output sent to browser
DEBUG - 2024-08-09 12:07:12 --> Total execution time: 0.1061
INFO - 2024-08-09 12:07:13 --> Config Class Initialized
INFO - 2024-08-09 12:07:13 --> Hooks Class Initialized
INFO - 2024-08-09 12:07:13 --> Config Class Initialized
INFO - 2024-08-09 12:07:13 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:07:13 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:13 --> Utf8 Class Initialized
DEBUG - 2024-08-09 12:07:13 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:13 --> Utf8 Class Initialized
INFO - 2024-08-09 12:07:13 --> URI Class Initialized
INFO - 2024-08-09 12:07:13 --> Router Class Initialized
INFO - 2024-08-09 12:07:13 --> Output Class Initialized
INFO - 2024-08-09 12:07:13 --> Security Class Initialized
DEBUG - 2024-08-09 12:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:07:13 --> Input Class Initialized
INFO - 2024-08-09 12:07:13 --> Language Class Initialized
INFO - 2024-08-09 12:07:13 --> Loader Class Initialized
INFO - 2024-08-09 12:07:13 --> Helper loaded: url_helper
INFO - 2024-08-09 12:07:13 --> Helper loaded: form_helper
INFO - 2024-08-09 12:07:13 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:07:13 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:07:13 --> Email Class Initialized
INFO - 2024-08-09 12:07:13 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:07:13 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:07:13 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:07:13 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:07:13 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:07:13 --> Controller Class Initialized
INFO - 2024-08-09 12:07:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:07:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:07:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:07:13 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:07:13 --> Final output sent to browser
DEBUG - 2024-08-09 12:07:13 --> Total execution time: 0.1300
INFO - 2024-08-09 12:07:16 --> Config Class Initialized
INFO - 2024-08-09 12:07:16 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:07:16 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:16 --> Utf8 Class Initialized
INFO - 2024-08-09 12:07:16 --> URI Class Initialized
INFO - 2024-08-09 12:07:16 --> Router Class Initialized
INFO - 2024-08-09 12:07:16 --> Output Class Initialized
INFO - 2024-08-09 12:07:16 --> Security Class Initialized
DEBUG - 2024-08-09 12:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:07:16 --> Input Class Initialized
INFO - 2024-08-09 12:07:16 --> Language Class Initialized
INFO - 2024-08-09 12:07:16 --> Loader Class Initialized
INFO - 2024-08-09 12:07:16 --> Helper loaded: url_helper
INFO - 2024-08-09 12:07:16 --> Helper loaded: form_helper
INFO - 2024-08-09 12:07:16 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:07:16 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:07:17 --> Email Class Initialized
INFO - 2024-08-09 12:07:17 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:07:17 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:07:17 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:07:17 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:07:17 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:07:17 --> Controller Class Initialized
INFO - 2024-08-09 12:07:17 --> Config Class Initialized
INFO - 2024-08-09 12:07:17 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:07:17 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:17 --> Utf8 Class Initialized
INFO - 2024-08-09 12:07:17 --> URI Class Initialized
INFO - 2024-08-09 12:07:17 --> Router Class Initialized
INFO - 2024-08-09 12:07:17 --> Output Class Initialized
INFO - 2024-08-09 12:07:17 --> Security Class Initialized
DEBUG - 2024-08-09 12:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:07:17 --> Input Class Initialized
INFO - 2024-08-09 12:07:17 --> Language Class Initialized
INFO - 2024-08-09 12:07:17 --> Loader Class Initialized
INFO - 2024-08-09 12:07:17 --> Helper loaded: url_helper
INFO - 2024-08-09 12:07:17 --> Helper loaded: form_helper
INFO - 2024-08-09 12:07:17 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:07:17 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:07:17 --> Email Class Initialized
INFO - 2024-08-09 12:07:17 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:07:17 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:07:17 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:07:17 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:07:17 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:07:17 --> Controller Class Initialized
INFO - 2024-08-09 12:07:17 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:07:17 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:07:17 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:07:17 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:07:17 --> Final output sent to browser
DEBUG - 2024-08-09 12:07:17 --> Total execution time: 0.0865
INFO - 2024-08-09 12:07:17 --> Config Class Initialized
INFO - 2024-08-09 12:07:17 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:07:17 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:17 --> Config Class Initialized
INFO - 2024-08-09 12:07:17 --> Utf8 Class Initialized
INFO - 2024-08-09 12:07:17 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:07:17 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:17 --> Utf8 Class Initialized
INFO - 2024-08-09 12:07:17 --> URI Class Initialized
INFO - 2024-08-09 12:07:17 --> Router Class Initialized
INFO - 2024-08-09 12:07:17 --> Output Class Initialized
INFO - 2024-08-09 12:07:17 --> Security Class Initialized
DEBUG - 2024-08-09 12:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:07:17 --> Input Class Initialized
INFO - 2024-08-09 12:07:17 --> Language Class Initialized
INFO - 2024-08-09 12:07:17 --> Loader Class Initialized
INFO - 2024-08-09 12:07:17 --> Helper loaded: url_helper
INFO - 2024-08-09 12:07:17 --> Helper loaded: form_helper
INFO - 2024-08-09 12:07:17 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:07:17 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:07:17 --> Email Class Initialized
INFO - 2024-08-09 12:07:17 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:07:17 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:07:17 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:07:17 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:07:17 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:07:17 --> Controller Class Initialized
INFO - 2024-08-09 12:07:17 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:07:17 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:07:17 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:07:17 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:07:17 --> Final output sent to browser
DEBUG - 2024-08-09 12:07:17 --> Total execution time: 0.1178
INFO - 2024-08-09 12:07:21 --> Config Class Initialized
INFO - 2024-08-09 12:07:21 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:07:21 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:21 --> Utf8 Class Initialized
INFO - 2024-08-09 12:07:21 --> URI Class Initialized
INFO - 2024-08-09 12:07:21 --> Router Class Initialized
INFO - 2024-08-09 12:07:21 --> Output Class Initialized
INFO - 2024-08-09 12:07:21 --> Security Class Initialized
DEBUG - 2024-08-09 12:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:07:21 --> Input Class Initialized
INFO - 2024-08-09 12:07:21 --> Language Class Initialized
INFO - 2024-08-09 12:07:21 --> Loader Class Initialized
INFO - 2024-08-09 12:07:21 --> Helper loaded: url_helper
INFO - 2024-08-09 12:07:21 --> Helper loaded: form_helper
INFO - 2024-08-09 12:07:21 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:07:21 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:07:21 --> Email Class Initialized
INFO - 2024-08-09 12:07:21 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:07:21 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:07:21 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:07:21 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:07:21 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:07:21 --> Controller Class Initialized
INFO - 2024-08-09 12:07:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:07:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:07:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 12:07:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:07:21 --> Final output sent to browser
DEBUG - 2024-08-09 12:07:21 --> Total execution time: 0.1049
INFO - 2024-08-09 12:07:21 --> Config Class Initialized
INFO - 2024-08-09 12:07:21 --> Hooks Class Initialized
INFO - 2024-08-09 12:07:21 --> Config Class Initialized
DEBUG - 2024-08-09 12:07:21 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:21 --> Hooks Class Initialized
INFO - 2024-08-09 12:07:21 --> Utf8 Class Initialized
DEBUG - 2024-08-09 12:07:21 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:21 --> Utf8 Class Initialized
INFO - 2024-08-09 12:07:21 --> URI Class Initialized
INFO - 2024-08-09 12:07:21 --> Router Class Initialized
INFO - 2024-08-09 12:07:21 --> Output Class Initialized
INFO - 2024-08-09 12:07:21 --> Security Class Initialized
DEBUG - 2024-08-09 12:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:07:21 --> Input Class Initialized
INFO - 2024-08-09 12:07:21 --> Language Class Initialized
INFO - 2024-08-09 12:07:21 --> Loader Class Initialized
INFO - 2024-08-09 12:07:21 --> Helper loaded: url_helper
INFO - 2024-08-09 12:07:21 --> Helper loaded: form_helper
INFO - 2024-08-09 12:07:21 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:07:21 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:07:21 --> Email Class Initialized
INFO - 2024-08-09 12:07:21 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:07:21 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:07:21 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:07:21 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:07:21 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:07:21 --> Controller Class Initialized
INFO - 2024-08-09 12:07:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:07:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:07:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 12:07:21 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:07:21 --> Final output sent to browser
DEBUG - 2024-08-09 12:07:21 --> Total execution time: 0.1336
INFO - 2024-08-09 12:07:23 --> Config Class Initialized
INFO - 2024-08-09 12:07:23 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:07:23 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:23 --> Utf8 Class Initialized
INFO - 2024-08-09 12:07:23 --> URI Class Initialized
INFO - 2024-08-09 12:07:23 --> Router Class Initialized
INFO - 2024-08-09 12:07:23 --> Output Class Initialized
INFO - 2024-08-09 12:07:23 --> Security Class Initialized
DEBUG - 2024-08-09 12:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:07:23 --> Input Class Initialized
INFO - 2024-08-09 12:07:23 --> Language Class Initialized
INFO - 2024-08-09 12:07:23 --> Loader Class Initialized
INFO - 2024-08-09 12:07:23 --> Helper loaded: url_helper
INFO - 2024-08-09 12:07:23 --> Helper loaded: form_helper
INFO - 2024-08-09 12:07:23 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:07:23 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:07:23 --> Email Class Initialized
INFO - 2024-08-09 12:07:23 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:07:23 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:07:23 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:07:23 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:07:23 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:07:23 --> Controller Class Initialized
INFO - 2024-08-09 12:07:23 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:07:23 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:07:23 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:07:23 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:07:23 --> Final output sent to browser
DEBUG - 2024-08-09 12:07:23 --> Total execution time: 0.1138
INFO - 2024-08-09 12:07:24 --> Config Class Initialized
INFO - 2024-08-09 12:07:24 --> Hooks Class Initialized
INFO - 2024-08-09 12:07:24 --> Config Class Initialized
INFO - 2024-08-09 12:07:24 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:07:24 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:24 --> Utf8 Class Initialized
DEBUG - 2024-08-09 12:07:24 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:24 --> Utf8 Class Initialized
INFO - 2024-08-09 12:07:24 --> URI Class Initialized
INFO - 2024-08-09 12:07:24 --> Router Class Initialized
INFO - 2024-08-09 12:07:24 --> Output Class Initialized
INFO - 2024-08-09 12:07:24 --> Security Class Initialized
DEBUG - 2024-08-09 12:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:07:24 --> Input Class Initialized
INFO - 2024-08-09 12:07:24 --> Language Class Initialized
INFO - 2024-08-09 12:07:24 --> Loader Class Initialized
INFO - 2024-08-09 12:07:24 --> Helper loaded: url_helper
INFO - 2024-08-09 12:07:24 --> Helper loaded: form_helper
INFO - 2024-08-09 12:07:24 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:07:24 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:07:24 --> Email Class Initialized
INFO - 2024-08-09 12:07:24 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:07:24 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:07:24 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:07:24 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:07:24 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:07:24 --> Controller Class Initialized
INFO - 2024-08-09 12:07:24 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:07:24 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:07:24 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:07:24 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:07:24 --> Final output sent to browser
DEBUG - 2024-08-09 12:07:24 --> Total execution time: 0.1159
INFO - 2024-08-09 12:07:29 --> Config Class Initialized
INFO - 2024-08-09 12:07:29 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:07:29 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:29 --> Utf8 Class Initialized
INFO - 2024-08-09 12:07:29 --> URI Class Initialized
INFO - 2024-08-09 12:07:29 --> Router Class Initialized
INFO - 2024-08-09 12:07:29 --> Output Class Initialized
INFO - 2024-08-09 12:07:29 --> Security Class Initialized
DEBUG - 2024-08-09 12:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:07:29 --> Input Class Initialized
INFO - 2024-08-09 12:07:29 --> Language Class Initialized
INFO - 2024-08-09 12:07:29 --> Loader Class Initialized
INFO - 2024-08-09 12:07:29 --> Helper loaded: url_helper
INFO - 2024-08-09 12:07:29 --> Helper loaded: form_helper
INFO - 2024-08-09 12:07:29 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:07:29 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:07:29 --> Email Class Initialized
INFO - 2024-08-09 12:07:29 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:07:29 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:07:29 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:07:29 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:07:29 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:07:29 --> Controller Class Initialized
INFO - 2024-08-09 12:07:29 --> Config Class Initialized
INFO - 2024-08-09 12:07:29 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:07:29 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:29 --> Utf8 Class Initialized
INFO - 2024-08-09 12:07:29 --> URI Class Initialized
INFO - 2024-08-09 12:07:29 --> Router Class Initialized
INFO - 2024-08-09 12:07:29 --> Output Class Initialized
INFO - 2024-08-09 12:07:29 --> Security Class Initialized
DEBUG - 2024-08-09 12:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:07:29 --> Input Class Initialized
INFO - 2024-08-09 12:07:29 --> Language Class Initialized
INFO - 2024-08-09 12:07:29 --> Loader Class Initialized
INFO - 2024-08-09 12:07:29 --> Helper loaded: url_helper
INFO - 2024-08-09 12:07:29 --> Helper loaded: form_helper
INFO - 2024-08-09 12:07:29 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:07:29 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:07:29 --> Email Class Initialized
INFO - 2024-08-09 12:07:29 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:07:29 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:07:29 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:07:29 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:07:29 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:07:29 --> Controller Class Initialized
INFO - 2024-08-09 12:07:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:07:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:07:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:07:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:07:29 --> Final output sent to browser
DEBUG - 2024-08-09 12:07:29 --> Total execution time: 0.0865
INFO - 2024-08-09 12:07:29 --> Config Class Initialized
INFO - 2024-08-09 12:07:29 --> Hooks Class Initialized
INFO - 2024-08-09 12:07:29 --> Config Class Initialized
INFO - 2024-08-09 12:07:29 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:07:29 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:29 --> Utf8 Class Initialized
DEBUG - 2024-08-09 12:07:29 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:07:29 --> Utf8 Class Initialized
INFO - 2024-08-09 12:07:29 --> URI Class Initialized
INFO - 2024-08-09 12:07:29 --> Router Class Initialized
INFO - 2024-08-09 12:07:29 --> Output Class Initialized
INFO - 2024-08-09 12:07:29 --> Security Class Initialized
DEBUG - 2024-08-09 12:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:07:29 --> Input Class Initialized
INFO - 2024-08-09 12:07:29 --> Language Class Initialized
INFO - 2024-08-09 12:07:29 --> Loader Class Initialized
INFO - 2024-08-09 12:07:29 --> Helper loaded: url_helper
INFO - 2024-08-09 12:07:29 --> Helper loaded: form_helper
INFO - 2024-08-09 12:07:29 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:07:29 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:07:29 --> Email Class Initialized
INFO - 2024-08-09 12:07:29 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:07:29 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:07:29 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:07:29 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:07:29 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:07:29 --> Controller Class Initialized
INFO - 2024-08-09 12:07:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:07:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:07:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:07:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:07:29 --> Final output sent to browser
DEBUG - 2024-08-09 12:07:29 --> Total execution time: 0.1174
INFO - 2024-08-09 12:15:53 --> Config Class Initialized
INFO - 2024-08-09 12:15:53 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:15:53 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:15:53 --> Utf8 Class Initialized
INFO - 2024-08-09 12:15:53 --> URI Class Initialized
INFO - 2024-08-09 12:15:53 --> Router Class Initialized
INFO - 2024-08-09 12:15:53 --> Output Class Initialized
INFO - 2024-08-09 12:15:53 --> Security Class Initialized
DEBUG - 2024-08-09 12:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:15:53 --> Input Class Initialized
INFO - 2024-08-09 12:15:53 --> Language Class Initialized
INFO - 2024-08-09 12:15:53 --> Loader Class Initialized
INFO - 2024-08-09 12:15:53 --> Helper loaded: url_helper
INFO - 2024-08-09 12:15:53 --> Helper loaded: form_helper
INFO - 2024-08-09 12:15:53 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:15:53 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:15:53 --> Email Class Initialized
INFO - 2024-08-09 12:15:53 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:15:53 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:15:53 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:15:53 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:15:53 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:15:53 --> Controller Class Initialized
INFO - 2024-08-09 12:15:53 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:15:53 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:15:53 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:15:53 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:15:53 --> Final output sent to browser
DEBUG - 2024-08-09 12:15:53 --> Total execution time: 0.1515
INFO - 2024-08-09 12:15:53 --> Config Class Initialized
INFO - 2024-08-09 12:15:53 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:15:53 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:15:53 --> Utf8 Class Initialized
INFO - 2024-08-09 12:15:53 --> Config Class Initialized
INFO - 2024-08-09 12:15:53 --> URI Class Initialized
INFO - 2024-08-09 12:15:53 --> Hooks Class Initialized
INFO - 2024-08-09 12:15:53 --> Router Class Initialized
DEBUG - 2024-08-09 12:15:53 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:15:53 --> Utf8 Class Initialized
INFO - 2024-08-09 12:15:53 --> Output Class Initialized
INFO - 2024-08-09 12:15:53 --> Security Class Initialized
DEBUG - 2024-08-09 12:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:15:53 --> Input Class Initialized
INFO - 2024-08-09 12:15:53 --> Language Class Initialized
INFO - 2024-08-09 12:15:53 --> Loader Class Initialized
INFO - 2024-08-09 12:15:53 --> Helper loaded: url_helper
INFO - 2024-08-09 12:15:53 --> Helper loaded: form_helper
INFO - 2024-08-09 12:15:53 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:15:53 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:15:53 --> Email Class Initialized
INFO - 2024-08-09 12:15:53 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:15:53 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:15:53 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:15:53 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:15:53 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:15:53 --> Controller Class Initialized
INFO - 2024-08-09 12:15:53 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:15:53 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:15:53 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:15:53 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:15:53 --> Final output sent to browser
DEBUG - 2024-08-09 12:15:53 --> Total execution time: 0.1288
INFO - 2024-08-09 12:15:55 --> Config Class Initialized
INFO - 2024-08-09 12:15:55 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:15:55 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:15:55 --> Utf8 Class Initialized
INFO - 2024-08-09 12:15:55 --> URI Class Initialized
INFO - 2024-08-09 12:15:55 --> Router Class Initialized
INFO - 2024-08-09 12:15:55 --> Output Class Initialized
INFO - 2024-08-09 12:15:55 --> Security Class Initialized
DEBUG - 2024-08-09 12:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:15:55 --> Input Class Initialized
INFO - 2024-08-09 12:15:55 --> Language Class Initialized
INFO - 2024-08-09 12:15:55 --> Loader Class Initialized
INFO - 2024-08-09 12:15:55 --> Helper loaded: url_helper
INFO - 2024-08-09 12:15:55 --> Helper loaded: form_helper
INFO - 2024-08-09 12:15:55 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:15:55 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:15:55 --> Email Class Initialized
INFO - 2024-08-09 12:15:55 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:15:55 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:15:55 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:15:55 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:15:55 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:15:55 --> Controller Class Initialized
INFO - 2024-08-09 12:15:55 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:15:55 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:15:55 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:15:55 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:15:55 --> Final output sent to browser
DEBUG - 2024-08-09 12:15:55 --> Total execution time: 0.0891
INFO - 2024-08-09 12:15:56 --> Config Class Initialized
INFO - 2024-08-09 12:15:56 --> Hooks Class Initialized
INFO - 2024-08-09 12:15:56 --> Config Class Initialized
INFO - 2024-08-09 12:15:56 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:15:56 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:15:56 --> Utf8 Class Initialized
DEBUG - 2024-08-09 12:15:56 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:15:56 --> Utf8 Class Initialized
INFO - 2024-08-09 12:15:56 --> URI Class Initialized
INFO - 2024-08-09 12:15:56 --> Router Class Initialized
INFO - 2024-08-09 12:15:56 --> Output Class Initialized
INFO - 2024-08-09 12:15:56 --> Security Class Initialized
DEBUG - 2024-08-09 12:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:15:56 --> Input Class Initialized
INFO - 2024-08-09 12:15:56 --> Language Class Initialized
INFO - 2024-08-09 12:15:56 --> Loader Class Initialized
INFO - 2024-08-09 12:15:56 --> Helper loaded: url_helper
INFO - 2024-08-09 12:15:56 --> Helper loaded: form_helper
INFO - 2024-08-09 12:15:56 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:15:56 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:15:56 --> Email Class Initialized
INFO - 2024-08-09 12:15:56 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:15:56 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:15:56 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:15:56 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:15:56 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:15:56 --> Controller Class Initialized
INFO - 2024-08-09 12:15:56 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:15:56 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:15:56 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:15:56 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:15:56 --> Final output sent to browser
DEBUG - 2024-08-09 12:15:56 --> Total execution time: 0.1386
INFO - 2024-08-09 12:15:58 --> Config Class Initialized
INFO - 2024-08-09 12:15:58 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:15:58 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:15:58 --> Utf8 Class Initialized
INFO - 2024-08-09 12:15:58 --> URI Class Initialized
INFO - 2024-08-09 12:15:58 --> Router Class Initialized
INFO - 2024-08-09 12:15:58 --> Output Class Initialized
INFO - 2024-08-09 12:15:58 --> Security Class Initialized
DEBUG - 2024-08-09 12:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:15:58 --> Input Class Initialized
INFO - 2024-08-09 12:15:58 --> Language Class Initialized
INFO - 2024-08-09 12:15:58 --> Loader Class Initialized
INFO - 2024-08-09 12:15:58 --> Helper loaded: url_helper
INFO - 2024-08-09 12:15:58 --> Helper loaded: form_helper
INFO - 2024-08-09 12:15:58 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:15:58 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:15:58 --> Email Class Initialized
INFO - 2024-08-09 12:15:58 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:15:58 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:15:58 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:15:58 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:15:58 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:15:58 --> Controller Class Initialized
INFO - 2024-08-09 12:15:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:15:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:15:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 12:15:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:15:58 --> Final output sent to browser
DEBUG - 2024-08-09 12:15:58 --> Total execution time: 0.1082
INFO - 2024-08-09 12:15:58 --> Config Class Initialized
INFO - 2024-08-09 12:15:58 --> Hooks Class Initialized
INFO - 2024-08-09 12:15:58 --> Config Class Initialized
INFO - 2024-08-09 12:15:58 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:15:58 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:15:58 --> Utf8 Class Initialized
DEBUG - 2024-08-09 12:15:58 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:15:58 --> Utf8 Class Initialized
INFO - 2024-08-09 12:15:58 --> URI Class Initialized
INFO - 2024-08-09 12:15:58 --> Router Class Initialized
INFO - 2024-08-09 12:15:58 --> Output Class Initialized
INFO - 2024-08-09 12:15:58 --> Security Class Initialized
DEBUG - 2024-08-09 12:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:15:58 --> Input Class Initialized
INFO - 2024-08-09 12:15:58 --> Language Class Initialized
INFO - 2024-08-09 12:15:58 --> Loader Class Initialized
INFO - 2024-08-09 12:15:58 --> Helper loaded: url_helper
INFO - 2024-08-09 12:15:58 --> Helper loaded: form_helper
INFO - 2024-08-09 12:15:58 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:15:59 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:15:59 --> Email Class Initialized
INFO - 2024-08-09 12:15:59 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:15:59 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:15:59 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:15:59 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:15:59 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:15:59 --> Controller Class Initialized
INFO - 2024-08-09 12:15:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:15:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:15:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 12:15:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:15:59 --> Final output sent to browser
DEBUG - 2024-08-09 12:15:59 --> Total execution time: 0.1251
INFO - 2024-08-09 12:16:00 --> Config Class Initialized
INFO - 2024-08-09 12:16:00 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:16:00 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:16:00 --> Utf8 Class Initialized
INFO - 2024-08-09 12:16:01 --> URI Class Initialized
INFO - 2024-08-09 12:16:01 --> Router Class Initialized
INFO - 2024-08-09 12:16:01 --> Output Class Initialized
INFO - 2024-08-09 12:16:01 --> Security Class Initialized
DEBUG - 2024-08-09 12:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:16:01 --> Input Class Initialized
INFO - 2024-08-09 12:16:01 --> Language Class Initialized
INFO - 2024-08-09 12:16:01 --> Loader Class Initialized
INFO - 2024-08-09 12:16:01 --> Helper loaded: url_helper
INFO - 2024-08-09 12:16:01 --> Helper loaded: form_helper
INFO - 2024-08-09 12:16:01 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:16:01 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:16:01 --> Email Class Initialized
INFO - 2024-08-09 12:16:01 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:16:01 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:16:01 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:16:01 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:16:01 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:16:01 --> Controller Class Initialized
INFO - 2024-08-09 12:16:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:16:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:16:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:16:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:16:01 --> Final output sent to browser
DEBUG - 2024-08-09 12:16:01 --> Total execution time: 0.1049
INFO - 2024-08-09 12:16:01 --> Config Class Initialized
INFO - 2024-08-09 12:16:01 --> Hooks Class Initialized
INFO - 2024-08-09 12:16:01 --> Config Class Initialized
INFO - 2024-08-09 12:16:01 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:16:01 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:16:01 --> Utf8 Class Initialized
DEBUG - 2024-08-09 12:16:01 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:16:01 --> Utf8 Class Initialized
INFO - 2024-08-09 12:16:01 --> URI Class Initialized
INFO - 2024-08-09 12:16:01 --> Router Class Initialized
INFO - 2024-08-09 12:16:01 --> Output Class Initialized
INFO - 2024-08-09 12:16:01 --> Security Class Initialized
DEBUG - 2024-08-09 12:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:16:01 --> Input Class Initialized
INFO - 2024-08-09 12:16:01 --> Language Class Initialized
INFO - 2024-08-09 12:16:01 --> Loader Class Initialized
INFO - 2024-08-09 12:16:01 --> Helper loaded: url_helper
INFO - 2024-08-09 12:16:01 --> Helper loaded: form_helper
INFO - 2024-08-09 12:16:01 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:16:01 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:16:01 --> Email Class Initialized
INFO - 2024-08-09 12:16:01 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:16:01 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:16:01 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:16:01 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:16:01 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:16:01 --> Controller Class Initialized
INFO - 2024-08-09 12:16:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:16:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:16:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:16:01 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:16:01 --> Final output sent to browser
DEBUG - 2024-08-09 12:16:01 --> Total execution time: 0.1477
INFO - 2024-08-09 12:16:06 --> Config Class Initialized
INFO - 2024-08-09 12:16:06 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:16:06 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:16:06 --> Utf8 Class Initialized
INFO - 2024-08-09 12:16:06 --> URI Class Initialized
INFO - 2024-08-09 12:16:06 --> Router Class Initialized
INFO - 2024-08-09 12:16:06 --> Output Class Initialized
INFO - 2024-08-09 12:16:06 --> Security Class Initialized
DEBUG - 2024-08-09 12:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:16:06 --> Input Class Initialized
INFO - 2024-08-09 12:16:06 --> Language Class Initialized
INFO - 2024-08-09 12:16:06 --> Loader Class Initialized
INFO - 2024-08-09 12:16:06 --> Helper loaded: url_helper
INFO - 2024-08-09 12:16:06 --> Helper loaded: form_helper
INFO - 2024-08-09 12:16:06 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:16:06 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:16:06 --> Email Class Initialized
INFO - 2024-08-09 12:16:06 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:16:06 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:16:06 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:16:06 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:16:06 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:16:06 --> Controller Class Initialized
INFO - 2024-08-09 12:16:06 --> Config Class Initialized
INFO - 2024-08-09 12:16:06 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:16:06 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:16:06 --> Utf8 Class Initialized
INFO - 2024-08-09 12:16:06 --> URI Class Initialized
INFO - 2024-08-09 12:16:06 --> Router Class Initialized
INFO - 2024-08-09 12:16:06 --> Output Class Initialized
INFO - 2024-08-09 12:16:06 --> Security Class Initialized
DEBUG - 2024-08-09 12:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:16:06 --> Input Class Initialized
INFO - 2024-08-09 12:16:06 --> Language Class Initialized
INFO - 2024-08-09 12:16:06 --> Loader Class Initialized
INFO - 2024-08-09 12:16:06 --> Helper loaded: url_helper
INFO - 2024-08-09 12:16:06 --> Helper loaded: form_helper
INFO - 2024-08-09 12:16:06 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:16:06 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:16:06 --> Email Class Initialized
INFO - 2024-08-09 12:16:06 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:16:06 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:16:06 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:16:06 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:16:06 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:16:06 --> Controller Class Initialized
INFO - 2024-08-09 12:16:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:16:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:16:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:16:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:16:06 --> Final output sent to browser
DEBUG - 2024-08-09 12:16:06 --> Total execution time: 0.0880
INFO - 2024-08-09 12:16:06 --> Config Class Initialized
INFO - 2024-08-09 12:16:06 --> Hooks Class Initialized
INFO - 2024-08-09 12:16:06 --> Config Class Initialized
DEBUG - 2024-08-09 12:16:06 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:16:06 --> Hooks Class Initialized
INFO - 2024-08-09 12:16:06 --> Utf8 Class Initialized
DEBUG - 2024-08-09 12:16:06 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:16:06 --> Utf8 Class Initialized
INFO - 2024-08-09 12:16:06 --> URI Class Initialized
INFO - 2024-08-09 12:16:06 --> Router Class Initialized
INFO - 2024-08-09 12:16:06 --> Output Class Initialized
INFO - 2024-08-09 12:16:06 --> Security Class Initialized
DEBUG - 2024-08-09 12:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:16:06 --> Input Class Initialized
INFO - 2024-08-09 12:16:06 --> Language Class Initialized
INFO - 2024-08-09 12:16:06 --> Loader Class Initialized
INFO - 2024-08-09 12:16:06 --> Helper loaded: url_helper
INFO - 2024-08-09 12:16:06 --> Helper loaded: form_helper
INFO - 2024-08-09 12:16:06 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:16:06 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:16:06 --> Email Class Initialized
INFO - 2024-08-09 12:16:06 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:16:06 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:16:06 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:16:06 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:16:06 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:16:06 --> Controller Class Initialized
INFO - 2024-08-09 12:16:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:16:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:16:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:16:06 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:16:06 --> Final output sent to browser
DEBUG - 2024-08-09 12:16:06 --> Total execution time: 0.1241
INFO - 2024-08-09 12:16:22 --> Config Class Initialized
INFO - 2024-08-09 12:16:22 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:16:22 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:16:22 --> Utf8 Class Initialized
INFO - 2024-08-09 12:16:22 --> URI Class Initialized
INFO - 2024-08-09 12:16:22 --> Router Class Initialized
INFO - 2024-08-09 12:16:22 --> Output Class Initialized
INFO - 2024-08-09 12:16:22 --> Security Class Initialized
DEBUG - 2024-08-09 12:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:16:22 --> Input Class Initialized
INFO - 2024-08-09 12:16:22 --> Language Class Initialized
INFO - 2024-08-09 12:16:22 --> Loader Class Initialized
INFO - 2024-08-09 12:16:22 --> Helper loaded: url_helper
INFO - 2024-08-09 12:16:22 --> Helper loaded: form_helper
INFO - 2024-08-09 12:16:22 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:16:22 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:16:22 --> Email Class Initialized
INFO - 2024-08-09 12:16:22 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:16:22 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:16:22 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:16:22 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:16:22 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:16:22 --> Controller Class Initialized
INFO - 2024-08-09 12:16:23 --> Config Class Initialized
INFO - 2024-08-09 12:16:23 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:16:23 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:16:23 --> Utf8 Class Initialized
INFO - 2024-08-09 12:16:23 --> URI Class Initialized
INFO - 2024-08-09 12:16:23 --> Router Class Initialized
INFO - 2024-08-09 12:16:23 --> Output Class Initialized
INFO - 2024-08-09 12:16:23 --> Security Class Initialized
DEBUG - 2024-08-09 12:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:16:23 --> Input Class Initialized
INFO - 2024-08-09 12:16:23 --> Language Class Initialized
INFO - 2024-08-09 12:16:23 --> Loader Class Initialized
INFO - 2024-08-09 12:16:23 --> Helper loaded: url_helper
INFO - 2024-08-09 12:16:23 --> Helper loaded: form_helper
INFO - 2024-08-09 12:16:23 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:16:23 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:16:23 --> Email Class Initialized
INFO - 2024-08-09 12:16:23 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:16:23 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:16:23 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:16:23 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:16:23 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:16:23 --> Controller Class Initialized
INFO - 2024-08-09 12:16:23 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:16:23 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:16:23 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:16:23 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:16:23 --> Final output sent to browser
DEBUG - 2024-08-09 12:16:23 --> Total execution time: 0.0947
INFO - 2024-08-09 12:16:23 --> Config Class Initialized
INFO - 2024-08-09 12:16:23 --> Hooks Class Initialized
INFO - 2024-08-09 12:16:23 --> Config Class Initialized
INFO - 2024-08-09 12:16:23 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:16:23 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:16:23 --> Utf8 Class Initialized
DEBUG - 2024-08-09 12:16:23 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:16:23 --> Utf8 Class Initialized
INFO - 2024-08-09 12:16:23 --> URI Class Initialized
INFO - 2024-08-09 12:16:23 --> Router Class Initialized
INFO - 2024-08-09 12:16:23 --> Output Class Initialized
INFO - 2024-08-09 12:16:23 --> Security Class Initialized
DEBUG - 2024-08-09 12:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:16:23 --> Input Class Initialized
INFO - 2024-08-09 12:16:23 --> Language Class Initialized
INFO - 2024-08-09 12:16:23 --> Loader Class Initialized
INFO - 2024-08-09 12:16:23 --> Helper loaded: url_helper
INFO - 2024-08-09 12:16:23 --> Helper loaded: form_helper
INFO - 2024-08-09 12:16:23 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:16:23 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:16:23 --> Email Class Initialized
INFO - 2024-08-09 12:16:23 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:16:23 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:16:23 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:16:23 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:16:23 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:16:23 --> Controller Class Initialized
INFO - 2024-08-09 12:16:23 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:16:23 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:16:23 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:16:23 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:16:23 --> Final output sent to browser
DEBUG - 2024-08-09 12:16:23 --> Total execution time: 0.1334
INFO - 2024-08-09 12:16:51 --> Config Class Initialized
INFO - 2024-08-09 12:16:51 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:16:51 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:16:51 --> Utf8 Class Initialized
INFO - 2024-08-09 12:16:51 --> URI Class Initialized
INFO - 2024-08-09 12:16:51 --> Router Class Initialized
INFO - 2024-08-09 12:16:51 --> Output Class Initialized
INFO - 2024-08-09 12:16:51 --> Security Class Initialized
DEBUG - 2024-08-09 12:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:16:51 --> Input Class Initialized
INFO - 2024-08-09 12:16:51 --> Language Class Initialized
INFO - 2024-08-09 12:16:51 --> Loader Class Initialized
INFO - 2024-08-09 12:16:51 --> Helper loaded: url_helper
INFO - 2024-08-09 12:16:51 --> Helper loaded: form_helper
INFO - 2024-08-09 12:16:51 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:16:51 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:16:51 --> Email Class Initialized
INFO - 2024-08-09 12:16:51 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:16:51 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:16:51 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:16:51 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:16:51 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:16:52 --> Controller Class Initialized
INFO - 2024-08-09 12:16:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:16:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:16:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:16:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:16:52 --> Final output sent to browser
DEBUG - 2024-08-09 12:16:52 --> Total execution time: 0.2074
INFO - 2024-08-09 12:16:52 --> Config Class Initialized
INFO - 2024-08-09 12:16:52 --> Config Class Initialized
INFO - 2024-08-09 12:16:52 --> Hooks Class Initialized
INFO - 2024-08-09 12:16:52 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:16:52 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:16:52 --> Utf8 Class Initialized
DEBUG - 2024-08-09 12:16:52 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:16:52 --> Utf8 Class Initialized
INFO - 2024-08-09 12:16:52 --> URI Class Initialized
INFO - 2024-08-09 12:16:52 --> Router Class Initialized
INFO - 2024-08-09 12:16:52 --> Output Class Initialized
INFO - 2024-08-09 12:16:52 --> Security Class Initialized
DEBUG - 2024-08-09 12:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:16:52 --> Input Class Initialized
INFO - 2024-08-09 12:16:52 --> Language Class Initialized
INFO - 2024-08-09 12:16:52 --> Loader Class Initialized
INFO - 2024-08-09 12:16:52 --> Helper loaded: url_helper
INFO - 2024-08-09 12:16:52 --> Helper loaded: form_helper
INFO - 2024-08-09 12:16:52 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:16:52 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:16:52 --> Email Class Initialized
INFO - 2024-08-09 12:16:52 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:16:52 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:16:52 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:16:52 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:16:52 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:16:52 --> Controller Class Initialized
INFO - 2024-08-09 12:16:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:16:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:16:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:16:52 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:16:52 --> Final output sent to browser
DEBUG - 2024-08-09 12:16:52 --> Total execution time: 0.1627
INFO - 2024-08-09 12:16:59 --> Config Class Initialized
INFO - 2024-08-09 12:16:59 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:16:59 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:16:59 --> Utf8 Class Initialized
INFO - 2024-08-09 12:16:59 --> URI Class Initialized
INFO - 2024-08-09 12:16:59 --> Router Class Initialized
INFO - 2024-08-09 12:16:59 --> Output Class Initialized
INFO - 2024-08-09 12:16:59 --> Security Class Initialized
DEBUG - 2024-08-09 12:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:16:59 --> Input Class Initialized
INFO - 2024-08-09 12:16:59 --> Language Class Initialized
INFO - 2024-08-09 12:16:59 --> Loader Class Initialized
INFO - 2024-08-09 12:16:59 --> Helper loaded: url_helper
INFO - 2024-08-09 12:16:59 --> Helper loaded: form_helper
INFO - 2024-08-09 12:16:59 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:16:59 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:16:59 --> Email Class Initialized
INFO - 2024-08-09 12:16:59 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:16:59 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:16:59 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:16:59 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:16:59 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:16:59 --> Controller Class Initialized
INFO - 2024-08-09 12:16:59 --> Config Class Initialized
INFO - 2024-08-09 12:16:59 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:16:59 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:16:59 --> Utf8 Class Initialized
INFO - 2024-08-09 12:16:59 --> URI Class Initialized
INFO - 2024-08-09 12:16:59 --> Router Class Initialized
INFO - 2024-08-09 12:16:59 --> Output Class Initialized
INFO - 2024-08-09 12:16:59 --> Security Class Initialized
DEBUG - 2024-08-09 12:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:16:59 --> Input Class Initialized
INFO - 2024-08-09 12:16:59 --> Language Class Initialized
INFO - 2024-08-09 12:16:59 --> Loader Class Initialized
INFO - 2024-08-09 12:16:59 --> Helper loaded: url_helper
INFO - 2024-08-09 12:16:59 --> Helper loaded: form_helper
INFO - 2024-08-09 12:16:59 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:16:59 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:16:59 --> Email Class Initialized
INFO - 2024-08-09 12:16:59 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:16:59 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:16:59 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:16:59 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:16:59 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:16:59 --> Controller Class Initialized
INFO - 2024-08-09 12:16:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:16:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:16:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:16:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:16:59 --> Final output sent to browser
DEBUG - 2024-08-09 12:16:59 --> Total execution time: 0.0892
INFO - 2024-08-09 12:17:00 --> Config Class Initialized
INFO - 2024-08-09 12:17:00 --> Hooks Class Initialized
INFO - 2024-08-09 12:17:00 --> Config Class Initialized
INFO - 2024-08-09 12:17:00 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:17:00 --> UTF-8 Support Enabled
DEBUG - 2024-08-09 12:17:00 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:17:00 --> Utf8 Class Initialized
INFO - 2024-08-09 12:17:00 --> Utf8 Class Initialized
INFO - 2024-08-09 12:17:00 --> URI Class Initialized
INFO - 2024-08-09 12:17:00 --> Router Class Initialized
INFO - 2024-08-09 12:17:00 --> Output Class Initialized
INFO - 2024-08-09 12:17:00 --> Security Class Initialized
DEBUG - 2024-08-09 12:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:17:00 --> Input Class Initialized
INFO - 2024-08-09 12:17:00 --> Language Class Initialized
INFO - 2024-08-09 12:17:00 --> Loader Class Initialized
INFO - 2024-08-09 12:17:00 --> Helper loaded: url_helper
INFO - 2024-08-09 12:17:00 --> Helper loaded: form_helper
INFO - 2024-08-09 12:17:00 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:17:00 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:17:00 --> Email Class Initialized
INFO - 2024-08-09 12:17:00 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:17:00 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:17:00 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:17:00 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:17:00 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:17:00 --> Controller Class Initialized
INFO - 2024-08-09 12:17:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:17:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:17:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:17:00 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:17:00 --> Final output sent to browser
DEBUG - 2024-08-09 12:17:00 --> Total execution time: 0.1257
INFO - 2024-08-09 12:17:08 --> Config Class Initialized
INFO - 2024-08-09 12:17:08 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:17:08 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:17:08 --> Utf8 Class Initialized
INFO - 2024-08-09 12:17:08 --> URI Class Initialized
INFO - 2024-08-09 12:17:08 --> Router Class Initialized
INFO - 2024-08-09 12:17:08 --> Output Class Initialized
INFO - 2024-08-09 12:17:08 --> Security Class Initialized
DEBUG - 2024-08-09 12:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:17:08 --> Input Class Initialized
INFO - 2024-08-09 12:17:08 --> Language Class Initialized
INFO - 2024-08-09 12:17:08 --> Loader Class Initialized
INFO - 2024-08-09 12:17:08 --> Helper loaded: url_helper
INFO - 2024-08-09 12:17:08 --> Helper loaded: form_helper
INFO - 2024-08-09 12:17:08 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:17:08 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:17:08 --> Email Class Initialized
INFO - 2024-08-09 12:17:08 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:17:08 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:17:08 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:17:08 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:17:08 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:17:08 --> Controller Class Initialized
INFO - 2024-08-09 12:17:09 --> Config Class Initialized
INFO - 2024-08-09 12:17:09 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:17:09 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:17:09 --> Utf8 Class Initialized
INFO - 2024-08-09 12:17:09 --> URI Class Initialized
INFO - 2024-08-09 12:17:09 --> Router Class Initialized
INFO - 2024-08-09 12:17:09 --> Output Class Initialized
INFO - 2024-08-09 12:17:09 --> Security Class Initialized
DEBUG - 2024-08-09 12:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:17:09 --> Input Class Initialized
INFO - 2024-08-09 12:17:09 --> Language Class Initialized
INFO - 2024-08-09 12:17:09 --> Loader Class Initialized
INFO - 2024-08-09 12:17:09 --> Helper loaded: url_helper
INFO - 2024-08-09 12:17:09 --> Helper loaded: form_helper
INFO - 2024-08-09 12:17:09 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:17:09 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:17:09 --> Email Class Initialized
INFO - 2024-08-09 12:17:09 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:17:09 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:17:09 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:17:09 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:17:09 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:17:09 --> Controller Class Initialized
INFO - 2024-08-09 12:17:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:17:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:17:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:17:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:17:09 --> Final output sent to browser
DEBUG - 2024-08-09 12:17:09 --> Total execution time: 0.1031
INFO - 2024-08-09 12:17:09 --> Config Class Initialized
INFO - 2024-08-09 12:17:09 --> Config Class Initialized
INFO - 2024-08-09 12:17:09 --> Hooks Class Initialized
INFO - 2024-08-09 12:17:09 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:17:09 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:17:09 --> Utf8 Class Initialized
DEBUG - 2024-08-09 12:17:09 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:17:09 --> Utf8 Class Initialized
INFO - 2024-08-09 12:17:09 --> URI Class Initialized
INFO - 2024-08-09 12:17:09 --> Router Class Initialized
INFO - 2024-08-09 12:17:09 --> Output Class Initialized
INFO - 2024-08-09 12:17:09 --> Security Class Initialized
DEBUG - 2024-08-09 12:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:17:09 --> Input Class Initialized
INFO - 2024-08-09 12:17:09 --> Language Class Initialized
INFO - 2024-08-09 12:17:09 --> Loader Class Initialized
INFO - 2024-08-09 12:17:09 --> Helper loaded: url_helper
INFO - 2024-08-09 12:17:09 --> Helper loaded: form_helper
INFO - 2024-08-09 12:17:09 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:17:09 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:17:09 --> Email Class Initialized
INFO - 2024-08-09 12:17:09 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:17:09 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:17:09 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:17:09 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:17:09 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:17:09 --> Controller Class Initialized
INFO - 2024-08-09 12:17:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:17:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:17:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formmodificaruser1.php
INFO - 2024-08-09 12:17:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:17:09 --> Final output sent to browser
DEBUG - 2024-08-09 12:17:09 --> Total execution time: 0.1230
INFO - 2024-08-09 12:17:16 --> Config Class Initialized
INFO - 2024-08-09 12:17:16 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:17:16 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:17:16 --> Utf8 Class Initialized
INFO - 2024-08-09 12:17:16 --> URI Class Initialized
INFO - 2024-08-09 12:17:16 --> Router Class Initialized
INFO - 2024-08-09 12:17:16 --> Output Class Initialized
INFO - 2024-08-09 12:17:16 --> Security Class Initialized
DEBUG - 2024-08-09 12:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:17:16 --> Input Class Initialized
INFO - 2024-08-09 12:17:16 --> Language Class Initialized
INFO - 2024-08-09 12:17:16 --> Loader Class Initialized
INFO - 2024-08-09 12:17:16 --> Helper loaded: url_helper
INFO - 2024-08-09 12:17:16 --> Helper loaded: form_helper
INFO - 2024-08-09 12:17:16 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:17:16 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:17:16 --> Email Class Initialized
INFO - 2024-08-09 12:17:16 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:17:16 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:17:16 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:17:16 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:17:16 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:17:16 --> Controller Class Initialized
INFO - 2024-08-09 12:17:16 --> Config Class Initialized
INFO - 2024-08-09 12:17:16 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:17:16 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:17:16 --> Utf8 Class Initialized
INFO - 2024-08-09 12:17:16 --> URI Class Initialized
INFO - 2024-08-09 12:17:16 --> Router Class Initialized
INFO - 2024-08-09 12:17:16 --> Output Class Initialized
INFO - 2024-08-09 12:17:16 --> Security Class Initialized
DEBUG - 2024-08-09 12:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:17:16 --> Input Class Initialized
INFO - 2024-08-09 12:17:16 --> Language Class Initialized
INFO - 2024-08-09 12:17:16 --> Loader Class Initialized
INFO - 2024-08-09 12:17:16 --> Helper loaded: url_helper
INFO - 2024-08-09 12:17:16 --> Helper loaded: form_helper
INFO - 2024-08-09 12:17:16 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:17:16 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:17:16 --> Email Class Initialized
INFO - 2024-08-09 12:17:16 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:17:16 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:17:16 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:17:16 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:17:16 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:17:16 --> Controller Class Initialized
INFO - 2024-08-09 12:17:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:17:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:17:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 12:17:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:17:16 --> Final output sent to browser
DEBUG - 2024-08-09 12:17:16 --> Total execution time: 0.0956
INFO - 2024-08-09 12:17:16 --> Config Class Initialized
INFO - 2024-08-09 12:17:16 --> Hooks Class Initialized
INFO - 2024-08-09 12:17:16 --> Config Class Initialized
INFO - 2024-08-09 12:17:16 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:17:16 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:17:16 --> Utf8 Class Initialized
DEBUG - 2024-08-09 12:17:16 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:17:16 --> URI Class Initialized
INFO - 2024-08-09 12:17:16 --> Utf8 Class Initialized
INFO - 2024-08-09 12:17:16 --> Router Class Initialized
INFO - 2024-08-09 12:17:16 --> Output Class Initialized
INFO - 2024-08-09 12:17:16 --> Security Class Initialized
DEBUG - 2024-08-09 12:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:17:16 --> Input Class Initialized
INFO - 2024-08-09 12:17:16 --> Language Class Initialized
INFO - 2024-08-09 12:17:16 --> Loader Class Initialized
INFO - 2024-08-09 12:17:16 --> Helper loaded: url_helper
INFO - 2024-08-09 12:17:16 --> Helper loaded: form_helper
INFO - 2024-08-09 12:17:16 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:17:16 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:17:16 --> Email Class Initialized
INFO - 2024-08-09 12:17:16 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:17:16 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:17:16 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:17:16 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:17:16 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:17:16 --> Controller Class Initialized
INFO - 2024-08-09 12:17:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:17:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:17:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 12:17:16 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:17:16 --> Final output sent to browser
DEBUG - 2024-08-09 12:17:16 --> Total execution time: 0.1173
INFO - 2024-08-09 12:19:58 --> Config Class Initialized
INFO - 2024-08-09 12:19:58 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:19:58 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:19:58 --> Utf8 Class Initialized
INFO - 2024-08-09 12:19:58 --> URI Class Initialized
INFO - 2024-08-09 12:19:58 --> Router Class Initialized
INFO - 2024-08-09 12:19:58 --> Output Class Initialized
INFO - 2024-08-09 12:19:58 --> Security Class Initialized
DEBUG - 2024-08-09 12:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:19:58 --> Input Class Initialized
INFO - 2024-08-09 12:19:58 --> Language Class Initialized
INFO - 2024-08-09 12:19:58 --> Loader Class Initialized
INFO - 2024-08-09 12:19:58 --> Helper loaded: url_helper
INFO - 2024-08-09 12:19:58 --> Helper loaded: form_helper
INFO - 2024-08-09 12:19:58 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:19:58 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:19:58 --> Email Class Initialized
INFO - 2024-08-09 12:19:58 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:19:58 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:19:58 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:19:58 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:19:58 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:19:58 --> Controller Class Initialized
INFO - 2024-08-09 12:19:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:19:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:19:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 12:19:58 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:19:58 --> Final output sent to browser
DEBUG - 2024-08-09 12:19:58 --> Total execution time: 0.1122
INFO - 2024-08-09 12:19:59 --> Config Class Initialized
INFO - 2024-08-09 12:19:59 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:19:59 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:19:59 --> Utf8 Class Initialized
INFO - 2024-08-09 12:19:59 --> URI Class Initialized
INFO - 2024-08-09 12:19:59 --> Config Class Initialized
INFO - 2024-08-09 12:19:59 --> Hooks Class Initialized
INFO - 2024-08-09 12:19:59 --> Router Class Initialized
INFO - 2024-08-09 12:19:59 --> Output Class Initialized
DEBUG - 2024-08-09 12:19:59 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:19:59 --> Utf8 Class Initialized
INFO - 2024-08-09 12:19:59 --> Security Class Initialized
DEBUG - 2024-08-09 12:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:19:59 --> Input Class Initialized
INFO - 2024-08-09 12:19:59 --> Language Class Initialized
INFO - 2024-08-09 12:19:59 --> Loader Class Initialized
INFO - 2024-08-09 12:19:59 --> Helper loaded: url_helper
INFO - 2024-08-09 12:19:59 --> Helper loaded: form_helper
INFO - 2024-08-09 12:19:59 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:19:59 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:19:59 --> Email Class Initialized
INFO - 2024-08-09 12:19:59 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:19:59 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:19:59 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:19:59 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:19:59 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:19:59 --> Controller Class Initialized
INFO - 2024-08-09 12:19:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:19:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:19:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\usuarioshabilitados1.php
INFO - 2024-08-09 12:19:59 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:19:59 --> Final output sent to browser
DEBUG - 2024-08-09 12:19:59 --> Total execution time: 0.1245
INFO - 2024-08-09 12:20:09 --> Config Class Initialized
INFO - 2024-08-09 12:20:09 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:20:09 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:20:09 --> Utf8 Class Initialized
INFO - 2024-08-09 12:20:09 --> URI Class Initialized
INFO - 2024-08-09 12:20:09 --> Router Class Initialized
INFO - 2024-08-09 12:20:09 --> Output Class Initialized
INFO - 2024-08-09 12:20:09 --> Security Class Initialized
DEBUG - 2024-08-09 12:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:20:09 --> Input Class Initialized
INFO - 2024-08-09 12:20:09 --> Language Class Initialized
INFO - 2024-08-09 12:20:09 --> Loader Class Initialized
INFO - 2024-08-09 12:20:09 --> Helper loaded: url_helper
INFO - 2024-08-09 12:20:09 --> Helper loaded: form_helper
INFO - 2024-08-09 12:20:09 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:20:09 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:20:09 --> Email Class Initialized
INFO - 2024-08-09 12:20:09 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:20:09 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:20:09 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:20:09 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:20:09 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:20:09 --> Controller Class Initialized
INFO - 2024-08-09 12:20:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:20:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:20:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formagregaruser1.php
INFO - 2024-08-09 12:20:09 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:20:09 --> Final output sent to browser
DEBUG - 2024-08-09 12:20:09 --> Total execution time: 0.1019
INFO - 2024-08-09 12:20:09 --> Config Class Initialized
INFO - 2024-08-09 12:20:09 --> Hooks Class Initialized
INFO - 2024-08-09 12:20:09 --> Config Class Initialized
INFO - 2024-08-09 12:20:09 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:20:09 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:20:09 --> Utf8 Class Initialized
INFO - 2024-08-09 12:20:09 --> URI Class Initialized
DEBUG - 2024-08-09 12:20:09 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:20:09 --> Utf8 Class Initialized
INFO - 2024-08-09 12:20:09 --> Router Class Initialized
INFO - 2024-08-09 12:20:09 --> Output Class Initialized
INFO - 2024-08-09 12:20:09 --> Security Class Initialized
DEBUG - 2024-08-09 12:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:20:09 --> Input Class Initialized
INFO - 2024-08-09 12:20:09 --> Language Class Initialized
INFO - 2024-08-09 12:20:09 --> Loader Class Initialized
INFO - 2024-08-09 12:20:09 --> Helper loaded: url_helper
INFO - 2024-08-09 12:20:10 --> Helper loaded: form_helper
INFO - 2024-08-09 12:20:10 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:20:10 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:20:10 --> Email Class Initialized
INFO - 2024-08-09 12:20:10 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:20:10 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:20:10 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:20:10 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:20:10 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:20:10 --> Controller Class Initialized
INFO - 2024-08-09 12:20:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:20:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:20:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formagregaruser1.php
INFO - 2024-08-09 12:20:10 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:20:10 --> Final output sent to browser
DEBUG - 2024-08-09 12:20:10 --> Total execution time: 0.1388
INFO - 2024-08-09 12:20:28 --> Config Class Initialized
INFO - 2024-08-09 12:20:28 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:20:28 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:20:28 --> Utf8 Class Initialized
INFO - 2024-08-09 12:20:28 --> URI Class Initialized
INFO - 2024-08-09 12:20:28 --> Router Class Initialized
INFO - 2024-08-09 12:20:28 --> Output Class Initialized
INFO - 2024-08-09 12:20:28 --> Security Class Initialized
DEBUG - 2024-08-09 12:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:20:28 --> Input Class Initialized
INFO - 2024-08-09 12:20:28 --> Language Class Initialized
INFO - 2024-08-09 12:20:28 --> Loader Class Initialized
INFO - 2024-08-09 12:20:28 --> Helper loaded: url_helper
INFO - 2024-08-09 12:20:28 --> Helper loaded: form_helper
INFO - 2024-08-09 12:20:28 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:20:29 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:20:29 --> Email Class Initialized
INFO - 2024-08-09 12:20:29 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:20:29 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:20:29 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:20:29 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:20:29 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:20:29 --> Controller Class Initialized
INFO - 2024-08-09 12:20:29 --> Config Class Initialized
INFO - 2024-08-09 12:20:29 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:20:29 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:20:29 --> Utf8 Class Initialized
INFO - 2024-08-09 12:20:29 --> URI Class Initialized
INFO - 2024-08-09 12:20:29 --> Router Class Initialized
INFO - 2024-08-09 12:20:29 --> Output Class Initialized
INFO - 2024-08-09 12:20:29 --> Security Class Initialized
DEBUG - 2024-08-09 12:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:20:29 --> Input Class Initialized
INFO - 2024-08-09 12:20:29 --> Language Class Initialized
INFO - 2024-08-09 12:20:29 --> Loader Class Initialized
INFO - 2024-08-09 12:20:29 --> Helper loaded: url_helper
INFO - 2024-08-09 12:20:29 --> Helper loaded: form_helper
INFO - 2024-08-09 12:20:29 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:20:29 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:20:29 --> Email Class Initialized
INFO - 2024-08-09 12:20:29 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:20:29 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:20:29 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:20:29 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:20:29 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:20:29 --> Controller Class Initialized
INFO - 2024-08-09 12:20:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:20:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:20:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formagregaruser1.php
INFO - 2024-08-09 12:20:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:20:29 --> Final output sent to browser
DEBUG - 2024-08-09 12:20:29 --> Total execution time: 0.0911
INFO - 2024-08-09 12:20:29 --> Config Class Initialized
INFO - 2024-08-09 12:20:29 --> Hooks Class Initialized
INFO - 2024-08-09 12:20:29 --> Config Class Initialized
INFO - 2024-08-09 12:20:29 --> Hooks Class Initialized
DEBUG - 2024-08-09 12:20:29 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:20:29 --> Utf8 Class Initialized
DEBUG - 2024-08-09 12:20:29 --> UTF-8 Support Enabled
INFO - 2024-08-09 12:20:29 --> Utf8 Class Initialized
INFO - 2024-08-09 12:20:29 --> URI Class Initialized
INFO - 2024-08-09 12:20:29 --> Router Class Initialized
INFO - 2024-08-09 12:20:29 --> Output Class Initialized
INFO - 2024-08-09 12:20:29 --> Security Class Initialized
DEBUG - 2024-08-09 12:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-09 12:20:29 --> Input Class Initialized
INFO - 2024-08-09 12:20:29 --> Language Class Initialized
INFO - 2024-08-09 12:20:29 --> Loader Class Initialized
INFO - 2024-08-09 12:20:29 --> Helper loaded: url_helper
INFO - 2024-08-09 12:20:29 --> Helper loaded: form_helper
INFO - 2024-08-09 12:20:29 --> Helper loaded: funciones_helper
INFO - 2024-08-09 12:20:29 --> Database Driver Class Initialized
DEBUG - 2024-08-09 12:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2024-08-09 12:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-09 12:20:29 --> Email Class Initialized
INFO - 2024-08-09 12:20:29 --> Model "Estudiante_model" initialized
INFO - 2024-08-09 12:20:29 --> Model "Pais_model" initialized
INFO - 2024-08-09 12:20:29 --> Model "Libro_model" initialized
INFO - 2024-08-09 12:20:29 --> Model "Crudusers_model" initialized
INFO - 2024-08-09 12:20:29 --> Model "Usuario_model" initialized
INFO - 2024-08-09 12:20:29 --> Controller Class Initialized
INFO - 2024-08-09 12:20:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/head.php
INFO - 2024-08-09 12:20:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/menuadmin.php
INFO - 2024-08-09 12:20:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\formagregaruser1.php
INFO - 2024-08-09 12:20:29 --> File loaded: C:\xampp\htdocs\tercerAnio\aquaReadPro\codeigniter\application\views\incrustaciones/vistascoloradmin/footer.php
INFO - 2024-08-09 12:20:29 --> Final output sent to browser
DEBUG - 2024-08-09 12:20:29 --> Total execution time: 0.1451
