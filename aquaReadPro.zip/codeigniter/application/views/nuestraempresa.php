<!-- Begin page content -->
<main class="flex-shrink-0">
  <div class="container">
  	
	<h1 class="mt-5">Nuestra Empresa</h1>
 	<h1 class="mt-5">Sticky footer with fixed navbar</h1>
	
    <p class="lead">Pin a footer to the bottom of the viewport in desktop browsers with this custom HTML and CSS. A fixed navbar has been added with <code class="small">padding-top: 60px;</code> on the <code class="small">main &gt; .container</code>.</p>



	<h1>Welcome to Inicio</h1>
	<h1>Ruta Base:</h1>
	<!-- aqui imprimimos la direccion URL BASE -->
	<h1><?php echo base_url(); ?></h1>
	<!-- url base (http://localhost/terceranio/server1/mvcNew/codeigniter/) -->
	<!-- url vista catalogo (http://localhost/terceranio/server1/mvcNew/codeigniter/index.php/empresa/catalogo) -->
	


    <p>Back to <a href="../examples/sticky-footer/">the default sticky footer</a> minus the navbar.</p>
  </div>
</main>
