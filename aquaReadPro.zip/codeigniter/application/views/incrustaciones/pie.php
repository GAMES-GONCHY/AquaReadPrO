<script src="<?php echo base_url(); ?>bootstrap/js/bootstrap.min.js"></script>
</body>
</html>