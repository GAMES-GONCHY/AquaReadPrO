/*
Template Name: Xeria - Responsive Bootstrap 4 Admin Dashboard
Author: CoderThemes
Version: 1.0.0
Website: https://coderthemes.com/
Contact: support@coderthemes.com
File: Tablesaw tables init js
*/

$( function(){
    $( document ).trigger( "enhance.tablesaw" );
});
